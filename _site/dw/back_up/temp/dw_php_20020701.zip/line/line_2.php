<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><img src="../images/top_logo.gif" width="146" height="84"></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name="movie" value="../images/flash/menu_m.swf">
        <param name=quality value=high>

        <embed src="../images/flash/menu_m.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed>       </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="145" height="509"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td rowspan="7" bgcolor="#8C8C8C" width="1"></td>
          <td><img src="images/title_2.gif" width="191" height="31"></td>
        </tr>
        <tr> 
          <td height="20"> 
            <div align="center"></div>
          </td>

        </tr>
        <tr>
          <td style="PADDING-LEFT: 20px" class="compa">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="2" height="30"><img src="images/title_2_1.gif" width="297" height="57"></td>
                <td height="8" width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%"></td>
                <td width="53%"><img src="images/title_2_main_title.gif" width="352" height="16"></td>
                <td height="7" width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%" height="84"></td>
                <td width="53%" style="PADDING-LEFT: 15px" class="compa">1) EXTRUSION 
                  FILM M/C (100mm)<br>
                  &nbsp;&nbsp;&nbsp;&nbsp;wide : 2,500mm, capacity : 250kg/hour<br>
                  <br>
                  2) 2-LAYER CO-EXTRUSION FILM M/C (100mm/70mm)<br>
                  &nbsp;&nbsp;&nbsp;&nbsp;wide : 2,500mm, capacity : 450kg/hour</td>
                <td width="35%"><img src="images/2_image_1.jpg" width="204" height="136"></td>
              </tr>
              <tr> 
                <td colspan="3" height="30"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td style="PADDING-LEFT: 20px" class="compa"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="2" height="30"><img src="images/title_2_2.gif" width="297" height="57"></td>
                <td height="4" width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%"></td>
                <td width="53%"><img src="images/title_2_main_title_1.gif" width="352" height="16"></td>
                <td width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%" height="84"></td>
                <td style="PADDING-LEFT: 15px" class="compa" height="76" valign="top"> 
                  <p>1) GRAVURE PRINTING M/C 9 colors-1EA<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;wide : 1,300mm<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;speed : 300m/minute</p>
                  <p>2) GRAVURE PRINTING M/C 8 colors-1EA<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;wide : 1,300mm<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;speed : 300m/minute</p>
                </td>
                <td valign="top" height="22"><img src="images/2_image_2.jpg" width="204" height="136"></td>
              </tr>
              <tr> 
                <td colspan="3" height="30"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td style="PADDING-LEFT: 20px" class="compa"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="2" height="46"><img src="images/title_2_3.gif" width="363" height="57"></td>
                <td height="1" width="35%" valign="bottom">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%"></td>
                <td width="53%"><img src="images/title_2_main_title.gif" width="352" height="16"></td>
                <td height="1" width="35%" valign="bottom">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%" height="84" rowspan="4"></td>
                <td width="53%" style="PADDING-LEFT: 15px" class="compa">1) EXTRUSION 
                  LAMINATION COATING M/C (100mm)<br>
                  &nbsp;&nbsp;&nbsp;&nbsp;wide : 1,300mm 2EA</td>
                <td width="35%"><img src="images/2_image_3.jpg" width="204" height="134"></td>
              </tr>
              <tr> 
                <td width="53%" style="PADDING-LEFT: 15px" class="compa"> 
                  <p>2) SOLVENT FREE DRY-LAMINATION M/C 1EA</p>
                </td>
                <td height="150" width="35%"><img src="images/2_image_3_2.jpg" width="204" height="126"></td>
              </tr>
              <tr> 
                <td width="53%" style="PADDING-LEFT: 15px" class="compa"> 
                  <p>3) DRY-LAMINATION M/C 1EA</p>
                </td>
                <td height="150" width="35%"><img src="images/2_image_3_3.jpg" width="204" height="129"></td>
              </tr>
              <tr> 
                <td width="53%" style="PADDING-LEFT: 15px" class="compa">4) SLITTING 
                  M/C 4EA</td>
                <td height="150" width="35%"><img src="images/2_image_3_4.jpg" width="204" height="135"></td>
              </tr>
              <tr> 
                <td colspan="3" height="30"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td style="PADDING-LEFT: 20px" class="compa">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="2" height="30"><img src="images/title_2_4.gif" width="330" height="57"></td>
                <td height="8" width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%"></td>
                <td width="53%"><img src="images/title_2_main_title.gif" width="352" height="16"></td>
                <td height="7" width="35%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="12%" height="84"></td>
                <td width="53%" style="PADDING-LEFT: 15px" class="compa" valign="top"> 
                  <p><br>
                    1) 3SIDE SEALING M/C 6EA<br>
                    2) ZIPPER &amp; STANDING POUCH M/C 3EA<br>
                    3) CENTER PRESS SEALED POUCH M/C 3EA<br>
                    4) STANDING POUCH M/C 2EA<br>
                    5) ZIPPER &amp; 2SIDE SEALING STAND-UP POUCH M/C 1EA</p>
                  </td>
                <td height="15" width="35%"><img src="images/2_image_4.jpg" width="201" height="267"></td>
              </tr>
              <tr> 
                <td colspan="3" height="30"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td height="20"></td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
