#define TRUE	1
#define FALSE	0

#define PRG_NAME	"CrazyGuestbook.cgi"
#define PRG_VERSION	"3.2.2"

#define DATA_DIR	"data"
#define DATA_EXT	"dat"
#define LASTNUM_FILE	"lastnum.conf"
#define CONFIG_FILE	"db.conf"
#define COUNT_FILE	"count.conf"

#define LIST_HEAD	"message/listhead.html"
#define LIST_TAIL	"message/listtail.html"
#define WRITE_HEAD	"message/writehead.html"
#define WRITE_TAIL	"message/writetail.html"
#define ADMIN_HEAD	"message/adminhead.html"
#define ADMIN_TAIL	"message/admintail.html"

#define HELP		"message/help.txt"

#define ICON_ADMIN	"icon/admin.gif"
#define ICON_HOME	"icon/home.gif"
#define ICON_BACK	"icon/back.gif"
#define ICON_HELP	"icon/help.gif"
#define ICON_WRITE	"icon/write.gif"
#define ICON_DELETE	"icon/delete.gif"
#define ICON_LIST	"icon/list.gif"
#define ICON_UP		"icon/up.gif"
#define ICON_DOWN	"icon/down.gif"

#define HR_LINE		"icon/line.gif"
#define HR_LINE_V	(1)
#define HR_LINE_H	(120)

#define CRYPT_SALT	"SY"

/*-------------------------------------*/

#define SENDMAIL_DIR	"/usr/lib"
#define SENDMAIL_NAME	"sendmail"
#define SENDMAIL_OPT	"-t"

#define MAIL_HEAD	"message/mailhead.txt"
#define MAIL_TAIL	"message/mailtail.txt"

#define MAIL_NAME	"Guestbook-Manager"
#define MAIL_SUBJECT	"[Guestbook] New article inserted."

/*-------------------------------------*/

#define COOKIE_EXP_DAYS	"365"

/*-------------------------------------*/

typedef struct {
  char *db;
  char *mode;
  int  Num;
  int  LastNum;
  char *password;
}DB;

typedef struct {
  char *Password;
  char *Message;

  char *HomeURL;
  char *HomeTarget;
  char *BackURL;
  char *BackTarget;
 
  char *LinkTarget;

  char *ViewMode;
  char *HTMLMode;

  char *AdminName;
  char *AdminEmail;
  char *MailToAdmin;

  char *TableWidth;
  char *ArticlesPerPage;

  char *WriteName;
  char *WriteSex;
  char *WriteBirth;
  char *WriteEmail;
  char *WriteHomeURL;
  char *WriteHomeTitle;
  char *WritePhone;
  char *WriteAddress;
  char *WriteText;
}DBConfig;

typedef struct {
  int  BrockenFlag;
  int  Year, Mon, Day, Hour, Min;
  char Addr[0xFF], Host[0xFF];
  char Name[0xFF];
  char Sex[0xFF];
  char Birth[0xFF];
  char Email[0xFF];
  char HomeTitle[0xFF];
  char HomeURL[0xFF];
  char Phone[0xFF];
  char Address[0xFF];
  char *Text;
}DBArticle;
