#include <stdio.h>
#include <stdlib.h>
#include "qDecoder.h"
#include "cgb.h"
#include "cgb_list.h"
#include "cgb_write.h"

void write_form0(DB *db, DBConfig *conf);
int sendmail(char *To, DB *db, DBConfig *conf);

void cgb_write(DB *db, DBConfig *conf){
  switch(atoi(conf->ViewMode)){
    case 0 : {
      write_form0(db, conf);
      break;
    }
  }
}

void write_form0(DB *db, DBConfig *conf){
  qSendFile(WRITE_HEAD);

  printf("<center><font size=3 face='����'><b>%s</b></font></center>\n\n", conf->Message);

  printf("<table border=0>\n");
  printf("<form method=POST action='%s?db=%s&mode=writesave'>\n", PRG_NAME, db->db);
  if(strcmp(conf->WriteName, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Name</b></font></td><td><input type=text name=Name size=20 maxlength=20></td></tr>\n");
  if(strcmp(conf->WriteSex, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Sex</b></font></td><td><select name=Sex><option selected><option>Man<option>Woman</select></td></tr>\n");
  if(strcmp(conf->WriteBirth, "false")){
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Birth</b></font></td><td><select name=Birth>");
    printf("<option selected>");  
    printf("<option>88 - 83 year");
    printf("<option>82 - 80 year");
    printf("<option>79 - 78 year");
    printf("<option>77 year");
    printf("<option>76 year");
    printf("<option>75 year");
    printf("<option>74 year");
    printf("<option>73 year");
    printf("<option>72 year");
    printf("<option>71 year");
    printf("<option>70 year");
    printf("<option>69 year");
    printf("<option>68 - 65 year");
    printf("<option>64 - 60 year");
    printf("<option>59 - 55 year");
    printf("<option>54 - 50 year");
    printf("<option>Grandfather");
    printf("</select>");
    printf("</td></tr>\n");
  }
  if(strcmp(conf->WriteEmail, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Email</b></font></td><td><input type=text name=Email size=50 maxlength=100></td></tr>\n");
  if(strcmp(conf->WriteHomeURL, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HomePage URL</b></font></td><td><input type=text name=HomeURL value='http://' size=50 maxlength=100></td></tr>\n");
  if(strcmp(conf->WriteHomeTitle, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HomePage Title</b></font></td><td><input type=text name=HomeTitle size=50 maxlength=100></td></tr>\n");
  if(strcmp(conf->WritePhone, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Phone</b></font></td><td><input type=text name=Phone size=20 maxlength=20></td></tr>\n");
  if(strcmp(conf->WriteAddress, "false"))printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Address</b></font></td><td><input type=text name=Address size=50 maxlength=100></td></tr>\n");
  if(strcmp(conf->WriteText, "false"))printf("  <tr><td colspan=2 align=center><textarea name=Text cols=60 rows=8 wrap=physical></textarea></td></tr>\n");

  printf("<tr><td align=left><input type=submit value='    Sign    '></td>\n");
  printf("<td align=right>");
  if(strcmp(conf->HomeURL, ""))printf("<a href='%s' target=%s><img src='%s' border=0></a>", conf->HomeURL, conf->HomeTarget, ICON_HOME);
  if(strcmp(conf->BackURL, ""))printf("<a href='%s' target=%s><img src='%s' border=0></a>", conf->BackURL, conf->BackTarget, ICON_BACK);
  printf("<a href='%s?db=%s'><img src='%s' border=0></a></td></tr>", PRG_NAME, db->db, ICON_LIST);

  printf("</form>\n");
  printf("</table>\n");

  qSendFile(WRITE_TAIL);
}

void cgb_savewrite(DB *db, DBConfig *conf){
  FILE *fp;
  Cgienv env;

  char buf[0xFF], *tmp;

 if(qValue("Email") != NULL){
    if(strcmp(qRemoveSpace(qValue("Email")), "") != 0){
      if(qCheckEmail(qValue("Email")) == 0)qError("E-mail address(%s) is incorrect.", qValue("Email"));
    }
  }

 if(qValue("HomeURL") != NULL){
    if(strcmp(qRemoveSpace(qValue("HomeURL")), "") != 0){
      if(qCheckURL(qValue("HomeURL")) == 0)qError("HomePage URL(%s) is incorrect.", qValue("HomeURL"));
    }
  }


  qCgienv(&env);

  db->LastNum++;

  sprintf(buf, "%s/%s/%d.%s", DATA_DIR, db->db, db->LastNum, DATA_EXT);
  fp = fopen(buf, "wt");
  if(fp == NULL)qError("Fatal error.<br>Please, check database(%s) permission.", db->db);

  fprintf(fp, "time-year=%d\n", env.year);
  fprintf(fp, "time-mon=%d\n", env.mon);
  fprintf(fp, "time-day=%d\n", env.day);
  fprintf(fp, "time-hour=%d\n", env.hour);
  fprintf(fp, "time-min=%d\n", env.min);
  fprintf(fp, "remote-addr=%s\n", env.remote_addr);
  fprintf(fp, "remote-host=%s\n", env.remote_host);

  if((qValue("Name")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Name"))))fprintf(fp, "query-name=%s\n", tmp);
  else if(!strcmp(conf->WriteName, "must")) fclose(fp), qError("'Name' field must be specified.");
  if((qValue("Sex"))  != NULL && strcmp("", tmp=qRemoveSpace(qValue("Sex"))))fprintf(fp, "query-sex=%s\n", tmp);
  else if(!strcmp(conf->WriteSex, "must")) fclose(fp), qError("'Sex' field must be specified.");
  if((qValue("Birth")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Birth"))))fprintf(fp, "query-birth=%s\n", tmp);
  else if(!strcmp(conf->WriteBirth, "must")) fclose(fp), qError("'Birth' field must be specified.");
  if((qValue("Email")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Email"))))fprintf(fp, "query-email=%s\n", tmp);
  else if(!strcmp(conf->WriteEmail, "must")) fclose(fp), qError("'E-mail' field must be specified.");
  if((qValue("HomeURL")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("HomeURL"))) &&  (strlen(qValue("HomeURL")) >= 12))fprintf(fp, "query-homeurl=%s\n", tmp);
  else if(!strcmp(conf->WriteHomeURL, "must")) fclose(fp), qError("'HomePage URL' field must be specified.");
  if((qValue("HomeTitle")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("HomeTitle"))))fprintf(fp, "query-hometitle=%s\n", tmp);
  else if(!strcmp(conf->WriteHomeTitle, "must")) fclose(fp), qError("'HomePage Title' field must be specified.");
  if((qValue("Phone")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Phone"))))fprintf(fp, "query-phone=%s\n", tmp);
  else if(!strcmp(conf->WritePhone, "must")) fclose(fp), qError("'Phone' field must be specified.");
  if((qValue("Address")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Address"))))fprintf(fp, "query-address=%s\n", tmp);
  else if(!strcmp(conf->WriteAddress, "must")) fclose(fp), qError("'Address' field must be specified.");
  if((qValue("Text")) != NULL && strcmp("", tmp=qRemoveSpace(qValue("Text")))){
    int i, lf;

    for(i = 1, lf = TRUE; *tmp; tmp++){
      if(lf == TRUE){
        fprintf(fp, "query-text%d=", i);
        i++;
        lf = FALSE;
      }
      if(*tmp == '\n') {
		lf = TRUE;
		fprintf(fp, "<br>"); //�¿��̰� �߰�
      }
      fprintf(fp, "%c", *tmp);
    }
  }
  else if(!strcmp(conf->WriteText, "must")) fclose(fp), qError("'Text' field must be specified.");

  fprintf(fp, "\n");

  fclose(fp);

  /* LastNum */
  sprintf(buf, "%s/%s/%s", DATA_DIR, db->db, LASTNUM_FILE);
  if(qSaveCounter(buf, db->LastNum) == 0)qError("Please, check your database(%s) permission.", db->db);


  if(!strcmp(conf->MailToAdmin, "true")) sendmail(conf->AdminEmail, db, conf);  

}

int sendmail(char *To, DB *db, DBConfig *conf) {
  Cgienv env;
  FILE *fp, *dp;
  char smail[0xFF];
  char From[0xff];

  if(To == NULL)      return FALSE;
  if(!strcmp(To, "")) return FALSE;

  qCgienv(&env);

  sprintf(smail, "%s/%s %s", SENDMAIL_DIR, SENDMAIL_NAME, SENDMAIL_OPT);

  /* �۽��� */
  sprintf(From, "%s <%s>", MAIL_NAME, conf->AdminEmail);

  fp = popen(smail, "wt");
  if(fp == NULL) qError("Sendmail(%s) not found.", smail);

  /* Mail Header */
  fprintf(fp, "From: %s\n",         From);
  fprintf(fp, "Reply-To: %s\n",     From);
  fprintf(fp, "X-Mailer: %s %s\n",  PRG_NAME, PRG_VERSION);
  fprintf(fp, "To: %s\n",           To);
  fprintf(fp, "Subject: %s\n",      MAIL_SUBJECT);

  /* HEADER */
  dp = fopen(MAIL_HEAD, "rt");
  if(dp != NULL) {
    int c;
    while((c = fgetc(dp)) != EOF) fprintf(fp, "%c", c);
    fclose(dp);
  }

  /* TEXT*/
  fprintf(fp, "-- [ Server Information ] ----------------------------\n");
  fprintf(fp, "SoftWare            : %s Version %s\n", PRG_NAME, PRG_VERSION);
  fprintf(fp, "Server Name         : %s\n", env.server_name);
  fprintf(fp, "Administrator Name  : %s\n", conf->AdminName);
  fprintf(fp, "Administrator Email : mailto:%s\n", conf->AdminEmail);
  fprintf(fp, "HomePage Location   : %s\n", conf->HomeURL);
  fprintf(fp, "DB Name             : %s\n", db->db);
  fprintf(fp, "DB Location         : http://%s:%s%s?db=%s\n", env.server_name, env.server_port, env.script_name, db->db);

  fprintf(fp, "\n");
  fprintf(fp, "-- [ Article Information ] -----------------------\n");

  if(qValue("Name")      != NULL) fprintf(fp, "@@ Name      : %s\n", qValue("Name"));
  if(qValue("Sex")       != NULL) fprintf(fp, "@@ Sex       : %s\n", qValue("Sex"));
  if(qValue("Birth")     != NULL) fprintf(fp, "@@ Birth     : %s\n", qValue("Birth"));
  if(qValue("Email")     != NULL) fprintf(fp, "@@ Email     : %s\n", qValue("Email"));
  if(qValue("HomeURL")   != NULL) fprintf(fp, "@@ HomeURL   : %s\n", qValue("HomeURL"));
  if(qValue("HomeTitle") != NULL) fprintf(fp, "@@ HomeTitle : %s\n", qValue("HomeTitle"));
  if(qValue("Phone")     != NULL) fprintf(fp, "@@ Phone     : %s\n", qValue("Phone"));
  if(qValue("Address")   != NULL) fprintf(fp, "@@ Address   : %s\n", qValue("Address"));
  if(qValue("Text")      != NULL) {
    fprintf(fp, "-- [ Text ] --------------------------------------\n");
    fprintf(fp, "%s\n", qValue("Text"));
    fprintf(fp, "---[ End ] ---------------------------------------\n");
  }
  /* TAILER */
  dp = fopen(MAIL_TAIL, "rt");
  if(dp != NULL) {
    int c;
    while((c = fgetc(dp)) != EOF) fprintf(fp, "%c", c);
    fclose(dp);
  }

  pclose(fp);
  return TRUE;
}
