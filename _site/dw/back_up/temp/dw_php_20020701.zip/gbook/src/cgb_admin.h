int  check_password(DB *db, DBConfig *conf);
void cgb_admin(DB *db, DBConfig *conf);
void cgb_adminsave(DB *db, DBConfig *conf);