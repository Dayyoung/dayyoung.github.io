#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "qDecoder.h"
#include "cgb.h"
#include "cgb_list.h"

int  GetArticle(char *filename, DBArticle *article);
void FreeArticle(DBArticle *article);
int  FindMode(char *HTMLMode, char *LinkTarget);
void PrintArticle0(DB *db, DBArticle *article, int num, int mode, char *target, int width);

void cgb_list(DB *db, DBConfig *conf){
  DBArticle article;
  char buf[0xFF];
  int i, mode, count;
  int lineCount;
  int upArrow = FALSE, nextArrow = FALSE;

  sprintf(buf, "%s/%s/%s", DATA_DIR, db->db, COUNT_FILE);
  count = qUpdateCounter(buf);

  mode = FindMode(conf->HTMLMode, conf->LinkTarget);

  qSendFile(LIST_HEAD);
  printf("<center><font size=3 face='����'><b>%s</b></font></center>\n\n", conf->Message);

  printf("<p>\n");
// �¿��̰� �߰�
  printf("<table border=0 width=%d><tr><td>\n", atoi(conf->TableWidth));
    if(strcmp(conf->HomeURL, "")) printf("  <a href='%s' target='%s'><img src='%s' border=0></a>\n", conf->HomeURL, conf->HomeTarget, ICON_HOME);
    if(strcmp(conf->BackURL, "")) printf("  <a href='%s' target='%s'><img src='%s' border=0></a>\n", conf->BackURL, conf->BackTarget, ICON_BACK);
    printf("  <a href='%s'><img src='%s' border=0></a>\n", HELP, ICON_HELP);
    printf("</td><td align=right>\n");
    if(upArrow   == TRUE) printf("  <a href='javascript:history.back()'><img src='%s' border=0></a>\n", ICON_UP);
    if(nextArrow == TRUE) printf("  <a href='%s?db=%s&mode=list&Num=%d'><img src='%s' border=0></a>\n", PRG_NAME, db->db, i, ICON_DOWN);
    printf("  <a href='%s?db=%s&mode=write'><img src='%s' border=0></a>\n", PRG_NAME, db->db, ICON_WRITE);
  printf("</td></tr></table>\n\n");

/* �¿��̰� �߰�*/
  printf("<table border=0 width=%d cellspacing=0>\n", atoi(conf->TableWidth) + 6);
  printf("  <tr bgcolor=black><td width=%d align=center><a href='%s?db=%s&mode=admin'><img src='%s' border=0></a></td>", HR_LINE_H, PRG_NAME, db->db, ICON_ADMIN);
  printf("<td width=%d align=right><font size=2 color=white face='arial'><b>Access : %d</b></font> </td></tr>\n", atoi(conf->TableWidth) - HR_LINE_H, count);
  printf("</table>\n\n");

  if(db->Num == 0) i = db->LastNum;
  else {
    i = db->Num;
    upArrow = TRUE;
  }  
  for(lineCount = 0, article.Text = NULL; i > 0; i--){
    sprintf(buf, "%s/%s/%d.%s", DATA_DIR, db->db, i, DATA_EXT);
    if(GetArticle(buf, &article) == FALSE) continue;
    /* found article */
    lineCount++;
    if((atoi(conf->ArticlesPerPage) > 0) && (lineCount > atoi(conf->ArticlesPerPage))){
      nextArrow = TRUE;
      break;
    }
    switch(atoi(conf->ViewMode)){
      default : {
        PrintArticle0(db, &article, i, mode, conf->LinkTarget, atoi(conf->TableWidth));
        break; 
      }
    }
  }

  FreeArticle(&article);

  printf("<table border=0 width=%d><tr><td>\n", atoi(conf->TableWidth));
    if(strcmp(conf->HomeURL, "")) printf("  <a href='%s' target='%s'><img src='%s' border=0></a>\n", conf->HomeURL, conf->HomeTarget, ICON_HOME);
    if(strcmp(conf->BackURL, "")) printf("  <a href='%s' target='%s'><img src='%s' border=0></a>\n", conf->BackURL, conf->BackTarget, ICON_BACK);
    printf("  <a href='%s'><img src='%s' border=0></a>\n", HELP, ICON_HELP);
    printf("</td><td align=right>\n");
    if(upArrow   == TRUE) printf("  <a href='javascript:history.back()'><img src='%s' border=0></a>\n", ICON_UP);
    if(nextArrow == TRUE) printf("  <a href='%s?db=%s&mode=list&Num=%d'><img src='%s' border=0></a>\n", PRG_NAME, db->db, i, ICON_DOWN);
    printf("  <a href='%s?db=%s&mode=write'><img src='%s' border=0></a>\n", PRG_NAME, db->db, ICON_WRITE);
  printf("</td></tr></table>\n\n");

  qSendFile(LIST_TAIL);
}

int GetArticle(char *filename, DBArticle *article){
  Entry *articlep;
  static int bufsize = 0;
  int  i, len, nbsplen;
  char *tmp, name[0xFF], *nbsp = " ";

  articlep = qfDecoder(filename);
  if(articlep == NULL) return FALSE;

  else article->BrockenFlag = FALSE;

  if((tmp = qfValue(articlep, "time-year")) != NULL) article->Year = atoi(tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "time-mon")) != NULL) article->Mon = atoi(tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "time-day")) != NULL) article->Day = atoi(tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "time-hour")) != NULL) article->Hour = atoi(tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "time-min")) != NULL) article->Min = atoi(tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "remote-addr")) != NULL) strcpy(article->Addr, tmp);
  else article->BrockenFlag = TRUE;
  if((tmp = qfValue(articlep, "remote-host")) != NULL) strcpy(article->Host, tmp);
  else article->BrockenFlag = TRUE;

  if((tmp = qfValue(articlep, "query-name")) != NULL) strcpy(article->Name, tmp);
  else strcpy(article->Name, "");
  if((tmp = qfValue(articlep, "query-sex")) != NULL) strcpy(article->Sex, tmp);
  else strcpy(article->Sex, "");
  if((tmp = qfValue(articlep, "query-birth")) != NULL) strcpy(article->Birth, tmp);
  else strcpy(article->Birth, "");
  if((tmp = qfValue(articlep, "query-email")) != NULL) strcpy(article->Email, tmp);
  else strcpy(article->Email, "");
  if((tmp = qfValue(articlep, "query-homeurl")) != NULL) strcpy(article->HomeURL, tmp);
  else strcpy(article->HomeURL, "");
  if((tmp = qfValue(articlep, "query-hometitle")) != NULL) strcpy(article->HomeTitle, tmp);
  else strcpy(article->HomeTitle, "");
  if((tmp = qfValue(articlep, "query-phone")) != NULL) strcpy(article->Phone, tmp);
  else strcpy(article->Phone, "");
  if((tmp = qfValue(articlep, "query-address")) != NULL) strcpy(article->Address, tmp);
  else strcpy(article->Address, "");

  /* Text */
  for(i = 1, nbsplen = strlen(nbsp), len = 1;; i++){
    sprintf(name, "query-text%d", i);
    if((tmp = qfValue(articlep, name)) == NULL)break;
    len += (strlen(tmp) + nbsplen);
  }

  if(bufsize == 0){
    bufsize = 1000 + 1;
    article->Text = (char *)malloc(sizeof(char) * bufsize);
  }
  strcpy(article->Text, "");
  if(bufsize < len){
    bufsize = len;
    article->Text = (char *)realloc(article->Text, sizeof(char) * bufsize);
  }

  for(i = 1;; i++){
    sprintf(name, "query-text%d", i);
    if((tmp = qfValue(articlep, name)) == NULL)break;
    strcat(article->Text, tmp);
    strcat(article->Text, nbsp);
  }
  qfFree(articlep);
  return TRUE;
}

void FreeArticle(DBArticle *article){
  if(article->Text != NULL) free(article->Text);
}


int FindMode(char *HTMLMode, char *LinkTarget){
  if(!strcmp(HTMLMode, "true"))return 0;
  if(!strcmp(LinkTarget, "")) return 2;
  return 3;
}

void PrintArticle0(DB *db, DBArticle *article, int num, int mode, char *target, int width){
  printf("<table border=0 width=%d><!-- Physical number %d -->\n", width, num);
  printf("  <tr><td bgcolor=f0f0f0 align=center><a href='%s?db=%s&mode=delete&Num=%d'><img src='%s' border=0></a></td>", PRG_NAME, db->db, num, ICON_DELETE);

  if(article->BrockenFlag == TRUE){
    printf("<td><font size=1 face='arial' color=green>Number %d - <font color=red>This article is brocken</font></font></td></tr>\n", num);
    return;
  }
  printf("<td><font size=1 face='arial' color=green>%2d.%2d.%2d (%2d:%2d) from '%s' of '%s'</font></td></tr>\n", article->Year, article->Mon, article->Day, article->Hour, article->Min, article->Addr, article->Host);

  if(strcmp(article->Name,      "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Name</font></td><td><font size=2 face='����'>%s</font></td></tr>\n", article->Name);
  if(strcmp(article->Sex,       "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Sex</td><td><font size=2 face='����'>%s</font></td></tr>\n", article->Sex);
  if(strcmp(article->Birth,     "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Birthday</td><td><font size=2 face='����'>%s</font></td></tr>\n", article->Birth);
  if(strcmp(article->Email,     "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>E-mail</td><td><font size=2 face='����'><a href='mailto:%s'>%s</a></font></td></tr>\n", article->Email, article->Email);
  if(strcmp(article->HomeURL,   "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>HomePage URL</td><td><font size=2 face='����'><a href='%s' target='%s'>%s</a></font></td></tr>", article->HomeURL, target, article->HomeURL);
  if(strcmp(article->HomeTitle, "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>HomePage Title</td><td><font size=2 face='����'>%s</font></td></tr>\n", article->HomeTitle);
  if(strcmp(article->Phone,     "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Phone</td><td><font size=2 face='����'>%s</font></td></tr>\n", article->Phone);
  if(strcmp(article->Address,   "")) printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Address</td><td><font size=2 face='����'>%s</font></td></tr>\n", article->Address);
  if(strcmp(article->Text,      "")){
    printf("  <tr><td bgcolor=F0F0F0 align=center><font size=2 face='arial'>Comments</td><td><font size=2 face='����'>\n");
    qPuts(mode, article->Text);
    printf("</font></td></tr>\n");
  }

  printf("  <tr><td><img src='%s' height=%d width=%d></td><td><img src='%s' height=%d width=%d></td></tr>\n", HR_LINE, HR_LINE_V, HR_LINE_H, HR_LINE, HR_LINE_V, width - HR_LINE_H);
  printf("</table>\n\n");
}
