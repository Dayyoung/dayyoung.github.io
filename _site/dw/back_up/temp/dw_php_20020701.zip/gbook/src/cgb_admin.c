#include <stdio.h>
#include <stdlib.h>
#include "qDecoder.h"
#include "cgb.h"
#include "cgb_admin.h"

char *crypt(const char *, const char *);

int  check_password(DB *db, DBConfig *conf);
void password_form(DB *db);
void admin_form(DB *db, DBConfig *conf);
void field(char *name, char *value, char *title);

int check_password(DB *db, DBConfig *conf){
  if(conf->Password == NULL) return 2;

  if(db->password == NULL) password_form(db);

  if(!strcmp(conf->Password, db->password)) return 1;
  if(!strcmp(conf->Password, crypt(db->password, CRYPT_SALT))) return 1;

  qError("The password is incorrect.");
  return 0;
}

void password_form(DB *db){
  qSendFile(ADMIN_HEAD);

  printf("<br><br>\n");

  printf("<table border=0>\n");

  printf("  <tr><td bgcolor=e6e8fa align=center><font size=4 face='arial'><B>DB Name</B></font></td><td align=center><font size=4 face='arial'>%s</font></td></tr>\n", db->db);
  printf("  <tr><td bgcolor=e6e8fa align=center><font size=4 face='arial'><B>Access Mode</B></font></td><td align=center><font size=4 face='arial'>%s</font></td></tr>\n", db->mode);
  if(strcmp(db->mode, "admin"))printf("  <tr><td bgcolor=e6e8fa align=center><font size=4 face='arial'><B>Handling Number</B></font></td><td align=center><font size=4 face='arial'>%d</font></td></tr>\n", db->Num);

  printf("<form method='post' action='%s'>\n", PRG_NAME);
    printf("  <input type='hidden' name='db' value='%s'>\n", db->db);
    printf("  <input type='hidden' name='mode' value='%s'>\n", db->mode);
    printf("  <input type='hidden' name='Num' value='%d'>\n", db->Num);

    printf("  <tr><td bgcolor=e6e8fa align=center><font size=4 face='arial'><B>Password</B></font></td><td align=center><input type='password' name='password' size=20 maxlength=8></td></tr>\n");
    printf("  <tr><td colspan=2 align=center><input type='submit' value='Check out'></td></tr>\n");
  printf("</form>\n");
  printf("</table>\n");

  printf("<br><a href='javascript:history.back()'>Cancel</a><br><br>\n");

  qSendFile(ADMIN_TAIL);
  exit(0);
}

void cgb_admin(DB *db, DBConfig *conf){
  check_password(db, conf);
  admin_form(db, conf);
  exit(0);
}

void	admin_form(DB *db, DBConfig *conf){
  char *flag;

  qSendFile(ADMIN_HEAD);

  printf("<table border=0>\n");
    printf("  <tr><td colspan=2 align=center><font size=5 face='arial'><b>'CrazyGuestbook' Admin Configuration</b></font></td></tr>\n");
    printf("  <tr><td colspan=2><hr></td></tr>\n");

    printf("<form method='post' action='%s'>\n", PRG_NAME);
    printf("  <input type='hidden' name='db' value='%s'>\n", db->db);
    printf("  <input type='hidden' name='mode' value='adminsave'>\n");

    if(db->password != NULL)printf("  <input type='hidden' name='password' value='%s'>\n", crypt(db->password, CRYPT_SALT));

    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>New Password</b></font></td><td><input type='password' name='cPassword' size=8 maxlength=8> <font size=2 face='arial'><b>Re-enter Password</b></font> <input type='password' name='cPassword2' size=8 maxlength=8></td></tr>\n");
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Title Message</b></font></td><td><input type='text' name='cMessage' value='%s'size=60 maxlength=800></td></tr>\n", conf->Message);
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HomePage URL</b></font></td><td><input type='text' name='cHomeURL' value='%s'size=40 maxlength=100> <font size=2 face='arial'><b>Target Frame</b></font> <input type='text' name='cHomeTarget' value='%s'size=10 maxlength=20></td></tr>\n", conf->HomeURL, conf->HomeTarget);
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Back URL</b></font></td><td><input type='text' name='cBackURL' value='%s'size=40 maxlength=100> <font size=2 face='arial'><b>Target Frame</b></font> <input type='text' name='cBackTarget' value='%s'size=10 maxlength=20></td></tr>\n", conf->BackURL, conf->BackTarget);

    /* LinkTarget */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Link Target</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->LinkTarget, ""))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLinkTarget' value='' %s> Current Frame , ", flag);
    if(!strcmp(conf->LinkTarget, "_top"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLinkTarget' value='_top' %s> Full Screen", flag);
    printf("</font></td></tr>\n");

    /* ViewMode */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>View Mode</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->ViewMode, "0"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cViewMode' value='0' %s> English , ", flag);
    printf("�� Korean , �� Korean2 , �� Korean3");
    printf("</font></td></tr>\n");

    /* HTMLMode */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HTML Mode</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->HTMLMode, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHTMLMode' value='true' %s> Accept HTML , ", flag);
    if(!strcmp(conf->HTMLMode, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHTMLMode' value='false' %s> Ignore HTML & Auto Link", flag);
    printf("</font></td></tr>\n");

    printf("  <tr><td colspan=2><hr></td></tr>\n");

    /* Admin Name */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Administrator Name</b></font></td><td><input type='text' name='cAdminName' value='%s' size=20 maxlength=20></td></tr>\n", conf->AdminName);
    /* Admin Email */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Administrator E-mail</b></font></td><td><input type='text' name='cAdminEmail' value='%s' size=60 maxlength=60></td></tr>\n", conf->AdminEmail);

    /* MailToAdmin */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail to Administrator</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->MailToAdmin, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToAdmin' value='true' %s> Yes, I wanna get a posting article by e-mail , ", flag);
    if(!strcmp(conf->MailToAdmin, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToAdmin' value='false' %s> No, don't do that", flag);
    printf("</font></td></tr>\n");

    printf("  <tr><td colspan=2><hr></td></tr>\n");

    /* Table Width */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Table Width</b></font></td><td><input type='text' name='cTableWidth' value='%s' size=8 maxlength=4> Pixels</td></tr>\n", conf->TableWidth);
    /* Articles Per Pages */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Articles per Page</b></font></td><td><input type='text' name='cArticlesPerPage' value='%s'size=8 maxlength=4> ( Zero means limitless )</td></tr>\n", conf->ArticlesPerPage);

    printf("  <tr><td colspan=2><hr></td></tr>\n");

    field("cWriteName", conf->WriteName, "Field Name");
    field("cWriteSex", conf->WriteSex, "Field Sex");
    field("cWriteBirth", conf->WriteBirth, "Field Birth");
    field("cWriteEmail", conf->WriteEmail, "Field Email");
    field("cWriteHomeURL", conf->WriteHomeURL, "Field HomePage URL");
    field("cWriteHomeTitle", conf->WriteHomeTitle, "Field HomePage Title");
    field("cWritePhone", conf->WritePhone, "Field Phone");
    field("cWriteAddress", conf->WriteAddress, "Field Address");
    field("cWriteText", conf->WriteText, "Field Text");

    printf("  <tr><td colspan=2><hr></td></tr>\n");

    printf("  <tr><td align=center><input type='submit' value='Save'> <input type='reset' value='Reset'></td>");
    printf("<td colspan=2 align=center><font size=3 face='arial'><a href='%s?db=%s&mode=list'>Cancel</a></font></td></tr>\n", PRG_NAME, db->db);

  printf("</form>\n");
  printf("</table>");
  
  qSendFile("message/listtail.html");
}


void field(char *name, char *value, char *title){
  char *flag;

  /* Field Text */
  printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>%s</b></font></td><td><font size=2 face='arial'>", title);
  if(!strcmp(value, "false"))flag = "checked"; else flag = "";
  printf("<input type='radio' name='%s' value='false' %s> Hidden , ", name, flag);
  if(!strcmp(value, "true"))flag = "checked"; else flag = "";
  printf("<input type='radio' name='%s' value='true' %s> Appear , ", name, flag);
  if(!strcmp(value, "must"))flag = "checked"; else flag = "";
  printf("<input type='radio' name='%s' value='must' %s> Must", name, flag);
  printf("</font></td></tr>\n");
}

void cgb_adminsave(DB *db, DBConfig *conf){
  FILE *fp;
  int flag;
  char buf[0xFF];

  flag = check_password(db, conf);  

  /*  ���� �˻� */
  if(flag == 2 && !strcmp("", qRemoveSpace(qValue("cPassword"))))qError("You must specify the password, when you configure a db at first time.");

  if(strcmp(qValue("cPassword"), qRemoveSpace(qValue("cPassword2"))))qError("Two passwords must be same.");

  if(!strcmp(qRemoveSpace(qValue("cAdminName")), ""))  qError("The field for the administrator's name must be specify.");

  if(!strcmp(qRemoveSpace(qValue("cAdminEmail")), "")) qError("The field for the administrator's e-mail must be specify.");

  if(qCheckEmail(qRemoveSpace(qValue("cAdminEmail"))) == 0) qError("Administrator's e-mail address is incorrect.");

  /* ���� */  
  sprintf(buf, "%s/%s/db.conf", DATA_DIR, db->db);
  fp = fopen(buf, "wt");
  if(fp == NULL)qError("Permission denyed, when modifying database configuration.<br>Please, check your database permission.");

  fprintf(fp, "Password=");
    if(strcmp(qValue("cPassword"), ""))fprintf(fp, "%s", crypt(qValue("cPassword"), CRYPT_SALT));
    else fprintf(fp, "%s", conf->Password);
  fprintf(fp, "\n");

  fprintf(fp, "Message=%s\n", qValue("cMessage"));
  fprintf(fp, "HomeURL=%s\n", qValue("cHomeURL"));
  fprintf(fp, "HomeTarget=%s\n", qValue("cHomeTarget"));
  fprintf(fp, "BackURL=%s\n", qValue("cBackURL"));
  fprintf(fp, "BackTarget=%s\n", qValue("cBackTarget"));
  fprintf(fp, "LinkTarget=%s\n", qValue("cLinkTarget"));
  fprintf(fp, "ViewMode=%s\n", qValue("cViewMode"));
  fprintf(fp, "HTMLMode=%s\n", qValue("cHTMLMode"));

  fprintf(fp, "AdminName=%s\n", qValue("cAdminName"));
  fprintf(fp, "AdminEmail=%s\n", qValue("cAdminEmail"));
  fprintf(fp, "MailToAdmin=%s\n", qValue("cMailToAdmin"));

  fprintf(fp, "TableWidth=%s\n", qValue("cTableWidth"));
  fprintf(fp, "ArticlesPerPage=%s\n", qValue("cArticlesPerPage"));

  fprintf(fp, "WriteName=%s\n", qValue("cWriteName"));
  fprintf(fp, "WriteSex=%s\n", qValue("cWriteSex"));
  fprintf(fp, "WriteBirth=%s\n", qValue("cWriteBirth"));
  fprintf(fp, "WriteEmail=%s\n", qValue("cWriteEmail"));
  fprintf(fp, "WriteHomeURL=%s\n", qValue("cWriteHomeURL"));
  fprintf(fp, "WriteHomeTitle=%s\n", qValue("cWriteHomeTitle"));
  fprintf(fp, "WritePhone=%s\n", qValue("cWritePhone"));
  fprintf(fp, "WriteAddress=%s\n", qValue("cWriteAddress"));
  fprintf(fp, "WriteText=%s\n", qValue("cWriteText"));

  fclose(fp);
}
