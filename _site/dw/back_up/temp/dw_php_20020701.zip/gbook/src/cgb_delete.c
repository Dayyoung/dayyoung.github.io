#include <stdio.h>
#include <stdlib.h>
#include "qDecoder.h"
#include "cgb.h"
#include "cgb_admin.h"
#include "cgb_delete.h"

void cgb_delete(DB *db, DBConfig *conf){
  int flag;
  char buf[0xFF];

  flag = check_password(db, conf);
  if(flag != 1) qError("Password is incorrect.");

  if(db->Num == 0)qError("Handling number didn't specify.");
  sprintf(buf, "%s/%s/%d.%s", DATA_DIR, db->db, db->Num, DATA_EXT);
  remove(buf);
}
