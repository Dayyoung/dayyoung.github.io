/***************************************************
** [GuestBook CGI]    'CrazyGuestbook.cgi' v3.2.2 **
**                                                **
** Programmed by 'Kim Seung-young'                **
**                                                **
** Email : nobreak@shinan.hongik.ac.kr            **
** Home  : http://shinan.hongik.ac.kr/~nobreak    **
**                                                **
**        Hongik University Shinan Campus         **
**        Hongik Shinan Network Security          **
****************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "qDecoder.h"
#include "cgb.h"
#include "cgb_list.h"
#include "cgb_write.h"
#include "cgb_delete.h"
#include "cgb_admin.h"

void GetDB(DB *db);
void GetConfig(char *filename, DBConfig *conf, DB *db);
void program_info(void);

void main(void){
  DB db;
  DBConfig conf;
  clock_t runTime;
  char buf[0xFF];

  /* Timer ���� */
  clock();

  qContentType("text/html");
  program_info();

  GetDB(&db);
  sprintf(buf, "%s/%s/%s", DATA_DIR, db.db, CONFIG_FILE);
  GetConfig(buf, &conf, &db);

  if(!strcmp(db.mode, "list")) cgb_list(&db, &conf);
  else if(!strcmp(db.mode, "write")) cgb_write(&db, &conf);
  else if(!strcmp(db.mode, "writesave")) {
    cgb_savewrite(&db, &conf);
    cgb_list(&db, &conf);
  }
  else if(!strcmp(db.mode, "admin")) cgb_admin(&db, &conf);
  else if(!strcmp(db.mode, "adminsave")){
    cgb_adminsave(&db, &conf);
    GetConfig(buf, &conf, &db);    
    cgb_list(&db, &conf);
  }
  else if(!strcmp(db.mode, "delete")) {
    cgb_delete(&db, &conf);
    db.Num = 0;
    cgb_list(&db, &conf);
  }
  else qError("Unknown mode(%s).", db.mode);

  qFree();

  /* Running Time */
  runTime = clock();  /* microsec */
  runTime /= 1000;    /* milisec */
  printf("\n<!-- Running time %.2f second(s) -->\n", (float)((float)runTime / (float)1000));
}

void GetDB(DB *db){
  char buf[0xFF];

  /* db */
  if((db->db = qValue("db")) == NULL) qError("You must specify the database name.");
  if(!strcmp(db->db , "")) qError("You must specify the database name.");
  if(qStr09AZaz(db->db) == 0) qError("The access to the database(%s) is canceled.<br>Only regular expression is allowed for the database name.", db->db);
  sprintf(buf, "%s/%s", DATA_DIR, db->db);
  if(qCheckFile(buf) == 0) qError("There is no database named '%s'.", db->db);

  /* mode */
  if((db->mode = qValue("mode")) == NULL) db->mode = "list";

  /* LastNum */
  sprintf(buf, "%s/%s/%s", DATA_DIR, db->db, LASTNUM_FILE);
  db->LastNum = qReadCounter(buf);
  if(db->LastNum < 0) qError("There is a fatal error in database(%s)<br>You should better call the administrator.", db->db);

  /* Num */
  if(qValue("Num") != NULL) db->Num = atoi(qValue("Num"));
  else db->Num = 0;

  /* password */
  db->password = qValue("password");
}

void GetConfig(char *filename, DBConfig *conf, DB *db){
  Entry *confp;
  int error = FALSE;

  confp = qfDecoder(filename);

  conf->Password   = qfValue(confp, "Password");
  conf->Message    = qfValue(confp, "Message");
  conf->HomeURL    = qfValue(confp, "HomeURL");
  conf->HomeTarget = qfValue(confp, "HomeTarget");
  conf->BackURL    = qfValue(confp, "BackURL");
  conf->BackTarget = qfValue(confp, "BackTarget");

  conf->LinkTarget = qfValue(confp, "LinkTarget");

  conf->ViewMode   = qfValue(confp, "ViewMode");
  conf->HTMLMode   = qfValue(confp, "HTMLMode");

  conf->AdminName   = qfValue(confp, "AdminName");
  conf->AdminEmail  = qfValue(confp, "AdminEmail");
  conf->MailToAdmin = qfValue(confp, "MailToAdmin");

  conf->TableWidth = qfValue(confp, "TableWidth");
  conf->ArticlesPerPage = qfValue(confp, "ArticlesPerPage");

  conf->WriteName      = qfValue(confp, "WriteName");
  conf->WriteSex       = qfValue(confp, "WriteSex");
  conf->WriteBirth     = qfValue(confp, "WriteBirth");
  conf->WriteEmail     = qfValue(confp, "WriteEmail");
  conf->WriteHomeURL   = qfValue(confp, "WriteHomeURL");
  conf->WriteHomeTitle = qfValue(confp, "WriteHomeTitle");
  conf->WritePhone     = qfValue(confp, "WritePhone");
  conf->WriteAddress   = qfValue(confp, "WriteAddress");
  conf->WriteText      = qfValue(confp, "WriteText");

  if(conf->Password == NULL) error = TRUE;

  if(conf->Message ==  NULL)   conf->Message = "This text will be appeared at top of the articles";
  if(conf->HomeURL == NULL)    conf->HomeURL = "http://Your HomePage URL";
  if(conf->HomeTarget == NULL) conf->HomeTarget = "";
  if(conf->BackURL == NULL)    conf->BackURL = "http://Previous Page URL";
  if(conf->BackTarget == NULL) conf->BackTarget = "";
  if(conf->LinkTarget == NULL) conf->LinkTarget = "_top";
  if(conf->ViewMode == NULL)   conf->ViewMode = "0";
  if(conf->HTMLMode == NULL)   conf->HTMLMode = "false";

  if(conf->AdminName   == NULL) conf->AdminName = "";
  if(conf->AdminEmail  == NULL) conf->AdminEmail = "";
  if(conf->MailToAdmin == NULL) conf->MailToAdmin = "true";
  
  if(conf->TableWidth == NULL) conf->TableWidth = "600";
  if(conf->ArticlesPerPage == NULL) conf->ArticlesPerPage = "15";

  if(conf->WriteName == NULL)  conf->WriteName = "must";
  if(conf->WriteSex == NULL)   conf->WriteSex = "false";
  if(conf->WriteBirth == NULL) conf->WriteBirth = "false";
  if(conf->WriteEmail == NULL) conf->WriteEmail = "true";
  if(conf->WriteHomeURL == NULL) conf->WriteHomeURL = "true";
  if(conf->WriteHomeTitle == NULL) conf->WriteHomeTitle = "false";
  if(conf->WritePhone == NULL)   conf->WritePhone = "false";
  if(conf->WriteAddress == NULL) conf->WriteAddress = "false";
  if(conf->WriteText == NULL)    conf->WriteText = "must";

  if(error == TRUE && strcmp(db->mode, "admin") && strcmp(db->mode, "adminsave")) {
    qError("Welcome to the CrazyWorld.<br>This is your first contact, so you must set some configurations.<br>Click <a href='%s?db=%s&mode=admin'>Admin</a>.", PRG_NAME, db->db);
  }
}

void program_info(void) {
  printf("<!----------------------------------------------------------->\n");
  printf("<!-- CrazyGuestbook CGI 'CrazyGuestbook.cgi Version %-5s' -->\n", PRG_VERSION);
  printf("<!--                                                       -->\n");
  printf("<!--                      Programmed by 'Seung-young, Kim' -->\n");
  printf("<!--                                                       -->\n");
  printf("<!--                      http://cgi.hongik.ac.kr          -->\n");
  printf("<!--                                                       -->\n");
  printf("<!--            Hongik University Shinan Campus            -->\n");
  printf("<!--            Hongik Shinan Network Security             -->\n");
  printf("<!--                                                       -->\n");
  printf("<!----------------------------------------------------------->\n");
  printf("\n");
}
