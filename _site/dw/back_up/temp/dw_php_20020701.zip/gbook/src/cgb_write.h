void cgb_write(DB *db, DBConfig *conf);
void cgb_savewrite(DB *db, DBConfig *conf);
