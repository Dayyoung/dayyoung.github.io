<?php

    include("../inc/common.inc.php");          
    include("../inc/func.inc.php");                        
    $dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
    mysql_select_db($db_name, $dbconn) or die('��� ���� ����');      

    $scale = 15;
    
    if( $this_page=="") {
        $this_page = 1;
    }
    #echo $mode;
    if($mode=="" || $mode=="list"){				
      
      $mode = "list";
      $qry1="select count(*) from $db " ;				
      
      $rst1=mysql_query($qry1, $dbconn) or die('qry1:'.mysql_error());
      
      $total_rows=mysql_result($rst1, 0 ,0);
      #echo $total_rows;
      $total_page=ceil($total_rows/$scale);      
      
      #### limit �� �������� - ��ü �������� ���� ������� �������� ���� fetch
      if(ceil($total_page/2) > $this_page){		// �Ϲ�...
          $order="m_v_id asc, m_r_id asc";
          $start=($this_page-1)*$scale;
          $t_scale=$scale;
        }else{
          $ef="rev";
          $order="v_id asc, r_id asc";						// ������������ ã��
          $start=$total_rows - $this_page*$scale;
          $t_scale=$scale;
          if($start<0){
            $t_scale=$scale + $start;
            $start =0;
            
          }
          
      }
      
      $qry2="select *, date_format(reg_date, '%Y.%m.%d') as date from $db order by $order limit $start, $t_scale";		
      
      $rst2=mysql_query($qry2, $dbconn) or die('qry2:'.mysql_error());
      $ttl2=mysql_num_rows($rst2);
      
      $add_str="Total: <b>$total_rows</b>&nbsp;&nbsp;&nbsp;Page: <b>$this_page / $total_page</b>";
     
     #####################################
     ####   �˻��� 
     }else if($mode=="search"){			
      
      $where_str=getSafeSearchArgs();		// �Խù��� ���� ��� ����.
      #$where_str = "";
      $t_value=ereg_replace("_","\_", $value);
      $t_value=ereg_replace("%","\%", $t_value);
      $arr_value=split(" ",$t_value);
      
      for($i=0; $i<count($arr_value); $i++){
        if($i==0) $where_str.=" and ($key like '%$arr_value[$i]%'";
          else $where_str.=" or $key like '%$arr_value[$i]%'";
      }
      $where_str.=")";
     
     ####### quick search
     if($quick_mode=="Y"){
              $order="m_v_id asc, m_r_id asc";
              $start=($this_page-1)*$scale;
              $t_scale=$scale;
     
     ####### �Ϲݰ˻� 
       }else{
       
  	    if(($this_page>1 && $SEARCH[KEY]==$key && $SEARCH[VALUE]==$value)){	// �˻� 2������ �̻󿡼��� �����س� ��Ű���. 
  	       $total_rows=$SEARCH[COUNT];
   	      }else{								// ī��Ʈ ������ �ٽ� ������ �ʴ´�.
     	       $qry1="select count(*) from $db $where_str" ;				
     	       #echo $qry1;
     	       $rst1=mysql_query($qry1, $dbconn) or die('qry1:'.mysql_error());
      	       $total_rows=mysql_result($rst1, 0 ,0);
    	    }
     
            $total_page=ceil($total_rows/$scale);
        
            /*if($this_page == 1){		//  �˻��Ǽ��� ��Ű�� ���� 2���������� ����
               setcookie("SEARCH[COUNT]", $total_rows);
               setcookie("SEARCH[KEY]", $key);
               setcookie("SEARCH[VALUE]", $value);
      
      	    }*/
      
            ############ ��� �˻� order
           if($ef != "rev"){		// �Ϲ�... - ��ü �������� ������ ���� ���������� �տ��� ���������� �ڿ��� ���� ã��.
              $order="m_v_id asc, m_r_id asc";
              $start=($this_page-1)*$scale;
              $t_scale=$scale;
            }else{						// ������������ ã��
              $order="v_id asc, r_id asc";	
              $start=$total_rows - $this_page*$scale;
              $t_scale=$scale;
              if($start<0){
                 $t_scale=$scale + $start;
                 $start =0;
              }
          }
        if($total_rows<$scale) $t_scale=$total_rows;
      }
      
      $qry2="select *, date_format(reg_date, '%Y.%m.%d') as date from $db $where_str order by $order limit $start, $t_scale";		
      $rst2=mysql_query($qry2, $dbconn) or die('qry2:'.mysql_error());
      $ttl2=mysql_num_rows($rst2);
      if($quick_mode=="Y") $add_str="Quick Search �Դϴ�. �� �˻� �Ǽ��� ������� �ʽ��ϴ�."; 
        else $add_str="�˻� ���  Total: <b>$total_rows</b>&nbsp;&nbsp;&nbsp;Page: <b>$this_page / $total_page</b>";
    }
    
    
?>
<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="160" valign="top" background="../images/top_back.gif">&nbsp;</td>
    <td width="625" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name="movie" value="../images/flash/menu_m.swf">
        <param name=quality value=high>

        <embed src="../images/flash/menu_m.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed>       </object></td>
    <td background="../images/top_back.gif" width="21%"></td>
  </tr>
  <tr>
    <td width="160" valign="top">&nbsp;</td>
    <td background="../images/gra_back.gif" width="1" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top" width="624"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td width="600" height="80"> 
            <div align="center">
            <?
            	if ($db == "tblNews") {
             		echo("<img src='images/news_title.gif' width='544' height='51'><br>");
             	} else if ($db == "tblBoard") {
              		echo("<img src='images/board_title.gif' width='544' height='51'><br>");
              	} else if ($db == "tblPds") {
              		echo("<img src='images/data_title.gif' width='544' height='51'>");
              	}
			?>
              </div>
          </td>
        </tr>
        <tr> 
          <td height="70" width="600"> 
            <table width="502" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr> 
                <td colspan="5" height="30" width="502"> 
                  <form name='search_mode' method='post' action='<?php echo "$PHP_SELF?db=$db"; ?>' onSubmit="return sendIt(this)">
                  <table width="400" border="0" cellspacing="0" cellpadding="0" align="right">
                  	<input type='hidden' name='mode' value='search'>
                    <tr> 
                      <td width="269"> 
                        <div align="right"> 
                          <select name='key' style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����">
                            <option selected value="title">�� ��</option>
                            <option value="contents">�� ��</option>
                            <option value="name">�۾���</option>
                          </select>
                        </div>
                      </td>
                      <td width="81"> 
                        <div align="right"> 
                          <input type="text" name="value"  style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="10" onKeyDown="if (event.keyCode == 13) {Check(this.form)};">
                        </div>
                      </td>
                      <td width="50"> 
                        <div align="center"><input type="image" src="images/bu_find.gif" width="42" height="17" border='0'></div>
                      </td>
                    </tr>
                  </table>
                  </form>
                </td>
              </tr>
              <tr> 
                <td colspan="5" height="1" bgcolor="#5E5E5E" width="502"></td>
              </tr>
              <tr> 
                <td height="20" width="35" bgcolor="#EBEBEB"> 
                  <div align="center"><font face="Arial, Helvetica, sans-serif"><b>No</b></font></div>
                </td>
                <td height="20" bgcolor="#EBEBEB" width="262"> 
                  <div align="center"><font face="Arial, Helvetica, sans-serif"><b>Tilte</b></font></div>
                </td>
                <td height="20" width="70" bgcolor="#EBEBEB"> 
                  <div align="center"><font face="Arial, Helvetica, sans-serif"><b>Write</b></font></div>
                </td>
                <td height="20" width="91" bgcolor="#EBEBEB"> 
                  <div align="center"><font face="Arial, Helvetica, sans-serif"><b>Date</b></font></div>
                </td>
                <td height="20" width="44" bgcolor="#EBEBEB"> 
                  <div align="center"><font face="Arial, Helvetica, sans-serif"><b>Read</b></font></div>
                </td>
              </tr>
              <tr> 
                <td height="3" width="35" bgcolor="#EBEBEB"> 
                  <div align="center"><img src="images/point.gif" width="30" height="3"></div>
                </td>
                <td height="3" bgcolor="#EBEBEB" width="262"> 
                  <div align="center"><img src="images/point.gif" width="120" height="3"></div>
                </td>
                <td height="3" width="70" bgcolor="#EBEBEB"> 
                  <div align="center"><img src="images/point.gif" width="50" height="3"></div>
                </td>
                <td height="3" width="91" bgcolor="#EBEBEB"> 
                  <div align="center"><img src="images/point.gif" width="50" height="3"></div>
                </td>
                <td height="3" width="44" bgcolor="#EBEBEB"> 
                  <div align="center"><img src="images/point.gif" width="30" height="3"></div>
                </td>
              </tr>
              <tr> 
                <td colspan="5" height="1" bgcolor="#5E5E5E" width="502"></td>
              </tr>
              <script language="JavaScript">
<!--
    function goadmin(theURL){
        window.open(theURL,"","toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=550");
    }
    function admin_insert(theURL){
        window.open(theURL,"","toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=550");
    }    
//-->
</script>
	<?
	if ($total_rows > 0 ) {               
		$page_str=printPage();
		if($ef=="rev"){                   
			for($i=$ttl2-1; $i>=0; $i--){
				mysql_data_seek($rst2, $i);
				$row2=mysql_fetch_array($rst2);
				//$title=shortLongString($row2[title],$TITLE_LENGTH-$row2[depth]); 
				$title=str_replace('"', "&quot;", str_replace("'","&#039;",$row2[title]));
				$depth=$row2[depth]*5;
				if($depth==0) $top_id=$row2[v_id];
				else $top_id="";
	
				echo ("     
					<tr> 
						<td width='35' height='28'> 
							<div align='center'>$top_id</div>
						</td>
						<td height='28' width='262'>
				");
	
				if($depth) {
					for($k=0; $k<=$depth; $k++){
						echo "&nbsp;";
					}
					echo "<img src='images/qna_re.gif' width='12' height='11'>";
				} 
				echo "<a href='read.php?db=$db&id=$row2[id]&key=&value=&mode=list&this_page=$this_page&s_start=&quick_mode='>";
				echo $title;
				echo "</a>";
				
				echo ("       
	
						</td>
						<td width='70' height='28'> 
							<div align='center'>$row2[name]</div>
						</td>
						<td width='90' height='28'> 
							<div align='center'>$row2[date]</div>
						</td>
						<td width='45' height='28'> 
							<div align='center'>$row2[hit]</div>
						</td>
					</tr>
					<tr> 
						<td colspan='5' height='1' bgcolor='#B6B5B5'></td>
					</tr>
				");	
			} # END FOR
		} else {
			for($i=0; $i<$ttl2; $i++){
				mysql_data_seek($rst2, $i);
				$row2=mysql_fetch_array($rst2);
				if($depth==0) $top_id=$row2[v_id];
				else $top_id="";				
				//$title=shortLongString($row2[title],$TITLE_LENGTH-$row2[depth]); 
				$title=str_replace('"', "&quot;", str_replace("'","&#039;",$row2[title]));		
				echo ("     
	
					<tr> 
						<td width='35' height='28'> 
							<div align='center'>$top_id</div>
						</td>
						<td height='28' width='262'>
				");
	
				if($depth) {
					for($k=0; $k<=$depth; $k++){
						echo "&nbsp;";
					}
					echo "<img src='images/qna_re.gif' width='12' height='11'>";
				} 
				echo "<a href='read.php?db=$db&id=$row2[id]&key=&value=&mode=list&this_page=$this_page&s_start=&quick_mode='>";
				echo $title;
				echo "</a>";
				echo ("       	
						</td>
						<td width='70' height='28'> 
							<div align='center'>$row2[name]</div>
						</td>
						<td width='90' height='28'> 
							<div align='center'>$row2[date]</div>
						</td>
						<td width='45' height='28'> 
							<div align='center'>$row2[hit]</div>
						</td>
					</tr>
					<tr> 
						<td colspan='5' height='1' bgcolor='#B6B5B5'></td>
					</tr>
				");	
			}
		}
	} else {
		echo("		
			<tr> 
				<td colspan='5' width='502' height='28'> 
					<div align='center'>�ڷᰡ �����ϴ�.</div>
				</td>	
			</tr>
		");
	}             
	
	?>                    
              <tr> 
                <td colspan='5' height='1' bgcolor='#B6B5B5' width="502"></td>
              </tr>

              <tr> 
                <td colspan="5" height="1" bgcolor="#B6B5B5" width="502"></td>
              </tr>
              <tr> 
                <td colspan="5" height="30" width="502"> 

                  <div align="center"><? echo $page_str;?></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td height="60" width="600"> 
          	<?
          		if($db == "tblNews" || $db == "tblPds" ) {
          			echo("
            <div align='center'><a href='pass.php?db=$db&act=new'><img src='images/bu_write.gif' width='67' height='20' border='0'></a></div>
            ");
            	} else {
          			echo("
            <div align='center'><a href='write.php?db=$db&act=new'><img src='images/bu_write.gif' width='67' height='20' border='0'></a></div>
            ");
				}            		
			?>
          </td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="21%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="160"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="625" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="160"></td>
    <td width="625" colspan="2" height="50"> 
      <div align="center">
                <p>&nbsp;</p>
</div>
    </td>
  </tr>
</table>
</body>
</html>
