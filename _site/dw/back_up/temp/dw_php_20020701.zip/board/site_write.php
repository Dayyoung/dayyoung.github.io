<?php
	include("../inc/common.inc.php");
	include("../inc/db.inc.php"); 
    $dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
    mysql_select_db($db_name, $dbconn) or die('��� ���� ����');  
    
    if ( $act == "edit" ) {
		$qry="select *, date_format(reg_date, '%Y.%m.%d') as date from $db where id = $id " ;                          
		$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
		$count_row = @mysql_num_rows($rst);
		$row = mysql_fetch_array($rst);    
		$s_id = $row[id];
		$s_v_id = $row[v_id];
		$s_r_id = $row[r_id];
        $s_contents = $row[contents];		
		$s_name = $row[name];
		$s_title = $row[title];
		$s_file = $row[attach_file_name];
		$s_size = $row[attach_file_size];
		$s_email = $row[email];
    } else if ( $act == "reply" ) {
		$qry="select *, date_format(reg_date, '%Y.%m.%d') as date from $db where id = $id " ;                          
		$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
		$count_row = @mysql_num_rows($rst);
		$row = mysql_fetch_array($rst);    
		$s_id = $row[id];
 		$s_home_url = $row[home_url];
   		if($row1[html]=="Y") $html_nl="<br>";
  			$name=$row[name];
  
  		$s_title=ereg_replace("^", "RE:",$row[title]);
  		$s_contents=ereg_replace("\r\n", "\n", $row[contents]);
  		$div = "--------------------------------------------\n";
  		$s_contents=ereg_replace("^", " \n $html_nl$div $html_nl:: $name wrote :: $html_nl\n ",$s_contents);
  
  		if($row[html]=="Y") $html_y="checked";
    		else $html_n="checked";
    
		  $s_v_id=$row[v_id];
		  $s_r_id=$row[r_id];
		  $s_depth=$row[depth];   
    }
         
?>
<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
function sendIt(){
	var sf=document.write;
	if( sf.db.value == "tblUrl" ) {
		if(!sf.home_url.value){
			alert('URL�� �Է��� �ֽʽÿ�.');
			sf.home_url.focus();
			return;
		}  
	} else {
		if(!sf.title.value){
			alert('������ �Է��� �ֽʽÿ�.');
			sf.title.focus();
			return;
		}  
		
	}
	sf.submit();
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name="movie" value="../images/flash/menu_m.swf">
        <param name=quality value=high>

        <embed src="../images/flash/menu_m.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed>       </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/site_main_image.gif" width="145" height="523"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td width="600"> 
          <? if($db == "tblUrl") {
          	echo("<img src='images/site_title_1.gif' width='148' height='53'>");
        } else {
            echo("<img src='images/site_title_2.gif' width='148' height='53'>");
           }
           	?>          
          </td>
        </tr>
        <tr> 
          <td height="70" width="600"> 
        	<form name="write" method="post" action="./action.php">
        	<input type="hidden" name='act' value='<? echo $act; ?>'>
			<input type='hidden' name='db' value='<? echo $db; ?>'>
			<input type='hidden' name='key' value='<? echo $key; ?>'>
			<input type='hidden' name='value' value='<? echo $value; ?>'>
			<input type='hidden' name='this_page' value='<? echo $this_page; ?>'>                             	
			<input type='hidden' name='id' value='<? echo $s_id; ?>'>
			<input type='hidden' name='v_id' value='<? echo $s_v_id; ?>'>
			<input type='hidden' name='r_id' value='<? echo $s_r_id; ?>'>									
			<input type='hidden' name='delete_file' value='<? echo $s_file; ?>'>
			<input type='hidden' name='delete_file_size' value='<? echo $s_size; ?>'>   
			<input type='hidden' name='depth' value='<? echo $s_depth; ?>'>              
            <table width="500" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> </td>
                <td rowspan="5" width="15" height="20"></td>
                <td width="360" height="20"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> <div align="right"><img src="images/title.gif" width="68" height="18"></div></td>
                <? if($db == "tblUrl") { ?>
                <td width="360" height="30"> <input type="text" name="home_url" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="55" value=<? echo $s_home_url;?>> 
                <? } else { ?>
                <td width="360" height="30"> <input type="text" name="title" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="55" value=<? echo $s_title;?>> 
                <? } ?>
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> <div align="right"><img src="images/mass.gif" width="68" height="18"></div></td>
                <td rowspan="2" height="150" width="360"> <textarea name="contents" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" cols="57" rows="10"><? echo $s_contents;?></textarea> 
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="120"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> <div align="right"></div></td>
                <td width="360" height="20"></td>
              </tr>
            </table>
            </form>
          </td>
        </tr>
        <tr> 
          <td height="60" width="600"> 
            <div align="center"><a href="javascript:sendIt('new')"><img src="images/bu_write.gif" width="67" height="20" border="0"></a><font color="#FFFFFF">.....</font><a href="site.php?db=<? echo $db; ?>&mode=<? echo $mode; ?>&key=<? echo $key; ?>&value=<? echo $value; ?>&this_page=<? echo $this_page; ?>&s_start=<? echo $s_start; ?>&quick_mode=<? echo $quick_mode; ?>"><img src="images/bu_can.gif" width="67" height="20" border="0"></a></div>
          </td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
