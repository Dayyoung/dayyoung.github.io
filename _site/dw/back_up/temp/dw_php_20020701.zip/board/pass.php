<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}

  function sendIt(tf){
    if(!tf.password.value){
	  alert("�н����带 �Է��� �ּ���.");
	  tf.password.focus();
	  return false;
	 }else{
	  return true;
	}
	if(!tf.user_id.value) {
		alert("ID�� �Է��� �ֽʽÿ�.");
		tf.user_id.focus();
		return false;
	} else {
		return true;
	}
  }
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="740">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name="movie" value="../images/flash/menu_m.swf">
        <param name=quality value=high>

        <embed src="../images/flash/menu_m.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed>       </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="145" height="523"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
    <? if($db == "tblUrl" || $db == "tblBox" || $db == "tblNews" || $db == "tblPds" ){     	
    	echo("<form name='write' method='post' action='./action_url.php'>");
    } else {
    	echo("<form name='write' method='post' action='./action.php'>");
    }
    ?>
			<input type="hidden" name='act' value='<? echo $act; ?>'>
			<input type='hidden' name='db' value='<? echo $db; ?>'>
			<input type='hidden' name='key' value='<? echo $key; ?>'>
			<input type='hidden' name='value' value='<? echo $value; ?>'>
			<input type='hidden' name='this_page' value='<? echo $this_page; ?>'> 
	      	<input type='hidden' name='id' value='<? echo $id; ?>'>
	      	<input type='hidden' name='v_id' value='<? echo $v_id; ?>'>
	      	<input type='hidden' name='r_id' value='<? echo $r_id; ?>'>	    
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td width="600" height="80"><div align="center"><img src="images/admin_title.gif" width="544" height="52"></div></td>
        </tr>
        <tr> 
          <td height="187" width="600"><table width="300" border="0" align="center" cellpadding="0" cellspacing="0">
              <!--<tr> 
                <td height="30"><div align="right"><strong>I D</strong></div></td>
                <td></td>
                <td><input type="text" name="user_id" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="15" maxlength="12"></td>
              </tr>-->
              <tr> 
                <td width="100" height="3"><div align="right"><img src="images/point.gif" width="80" height="3"></div></td>
                <td width="18" height="3"></td>
                <td width="182" height="3"></td>
              </tr>
              <tr> 
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td height="30"><div align="right"><strong>Pass</strong></div></td>
                <td></td>
                <td><input type="password" name="password" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="15" maxlength="12"></td>
              </tr>
              <tr> 
                <td height="3"><div align="right"><img src="images/point.gif" width="80" height="3"></div></td>
                <td height="3"></td>
                <td height="3"></td>
              </tr>
            </table> </td>
        </tr>
        <tr> 
          <td height="60" width="600"> 
            <div align="center"><input type="image"   src="images/bu_ok.gif" width="67" height="20" border="0"></div>
          </td>
        </tr>
      </table>
      </form>        
    </td>
    <td rowspan="3" width="50%" height="620"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146" height="47"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2" height="47"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
