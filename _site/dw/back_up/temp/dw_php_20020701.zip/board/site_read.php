<?php
	#echo $start;
	include("../inc/common.inc.php");

	$dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
	mysql_select_db($db_name, $dbconn) or die('��� ���� ����');
  
	$qry="select *, date_format(reg_date, '%Y.%m.%d') as date from $db where id = $id " ;                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$count_row = @mysql_num_rows($rst);
	$row = mysql_fetch_array($rst)

?>
<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
 function sendIt(act){
    var sf=document.write;
    if ( act == "list" ) {
    	sf.action="site.php";
    } else {
    	sf.action="pass.php"; 		
 	}
 	sf.act.value = act;
    sf.submit();
 }
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<form name="write" method="post">
	<input type="hidden" name='act' value=''>
	<input type='hidden' name='db' value='<? echo $db; ?>'>
	<input type='hidden' name='key' value='<? echo $key; ?>'>
	<input type='hidden' name='value' value='<? echo $value; ?>'>
	<input type='hidden' name='this_page' value='<? echo $this_page; ?>'> 
	<input type='hidden' name='id' value='<? echo $row[id]; ?>'>
	<input type='hidden' name='v_id' value='<? echo $row[v_id]; ?>'>
	<input type='hidden' name='r_id' value='<? echo $row[r_id]; ?>'>																												
</form>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="../images/flash/menu_m.swf">
        <param name=quality value=high>
        <embed src="../images/flash/menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/site_main_image.gif" width="145" height="523"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td width="600" height="80"> 
          <? if($db == "tblUrl") {
          	echo("<img src='images/site_title_1.gif' width='148' height='53'>");
        } else {
            echo("<img src='images/site_title_2.gif' width='148' height='53'>");
           }
           	?>            
          
          
          <br> 
          </td>
        </tr>
        <tr> 
          <td height="70" width="600"> 
            <table width="500" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> </td>
                <td rowspan="5" width="15" height="20"></td>
                <td width="360" height="20"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> <div align="right"><img src="images/title.gif" width="68" height="18"></div></td>
                <td width="360" height="30"> <? echo $row[title]; ?></td>
              </tr>
              <tr> 
                <td width="125" height="30" valign="top" bgcolor="#E9E9E9"> <div align="right"> 
                    <img src="images/mass.gif" width="68" height="18"></div></td>
                <td width="360" rowspan="2" class="compa"><? 
                            $contents = ereg_replace("&gt;", ">", $row[contents]);		// 0.9.0���� ���ϻ���� ����. -- 0.9.1 �������� ��۽� ">" �� �ƴ϶� "--------" �� ǥ��
                            $contents = htmlspecialchars($contents);
                            $contents=nl2br($contents);                                            
                            
                            echo $contents; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> <div align="right"></div></td>
                <td width="360" height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td height="60" width="600"> 
            <div align="center"><a href="javascript:sendIt('edit')"><img src="images/bu_modi.gif" width="67" height="20" border="0"></a><font color="#FFFFFF">.....</font><a href="javascript:sendIt('delete')"><img src="images/bu_del.gif" width="67" height="20" border="0"></a><font color="#FFFFFF">.....</font><a href="site.php?db=<? echo $db; ?>&this_page=<? echo $this_page; ?>&key=<? echo $key; ?>&value=<? echo $value;?>"><img src="images/bu_list.gif" width="67" height="20" border="0"></a></div>
          </td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
