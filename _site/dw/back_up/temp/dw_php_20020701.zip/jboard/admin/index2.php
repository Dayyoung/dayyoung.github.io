<?php
/*
	������ �ε���(?) ������
*/

/* ��ġ�� �Խ����ΰ�? */
if(!file_exists("./login/admin.gdbm")) {
	Header("Location:./install.php");
	exit;
}

/* ���� ��Ʈ�� ȭ�� */
include ("./include/control.inc");

/* �����Ǿ� �ִ� �Խ��� ���ϱ� */
$d_list = get_directory("../data");

/* ������ ���� */
$dbm = dbmopen("./login/admin.gdbm", "r");
$admin[url] = dbmfetch($dbm, "url");
$admin[email] = dbmfetch($dbm, "admin_email");
dbmclose($dbm);
?>
<html>
<head>
<title>jboard :: ������������</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<style type="text/css">
<!--
td {  font-size: 9pt; border: #CCCCCC none}
.b {  border: 1px #999999 solid; background-color: #E1E1E1; font-size: 9pt}
.del {  background-color: #F5F5F5; border: #333333; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; color: #FF0000; font-size: 9pt}
.fil {  border-color: #FFFFFF #FFFFFF #000000; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px}
-->
</style>
<script>
<!--
function chk_del(code)
{
	if(confirm('���� ���� �Ͻðڽ��ϱ�?\n\n���� : �Խ����� ��絥����(���ε�Ȱ� ����)�� ���� �˴ϴ�.!!')) {
		document.del_form.code.value=code;
		document.del_form.submit();
	} else {
		return false;
	}
}

function open_win(URL)
{
	window.open(URL, 'manage_win', 'width=720, height=500, scrollbars=yes');
}

function open_win2(URL)
{
	window.open(URL, 'manage_win','');
}

function new_board()
{
	var F = document.new_form;

	if(!F.board_code.value) {
		alert('�����Ϸ��� �Խ��� �ڵ带 �Է��� �ּ���');
		F.board_code.focus();
		return false;
	} else {
		var url = './admin_new.php?code=' + F.board_code.value;
		open_win(url);
	}
}

function disp_url(val)
{
	tr_url.style.display = 'inline';
	url_info.innerHTML = val;
}

function chk_pw()
{
	var F = document.pw_form;
	if(!F.pw1.value) {
		alert('�����Ͻ� ��й�ȣ�� �Է��� �ּ���');
		F.pw1.focus();
		return false;
	}
	if(!F.pw2.value) {
		alert('�ѹ��� �Է��� �ּ���');
		F.pw2.focus();
		return false;
	}
	if(F.pw1.value != F.pw2.value) {
		alert('��й�ȣ�� ��ġ���� �ʽ��ϴ�. Ȯ���� �ٽ� �Է��� �ּ���!');
		F.pw2.value='';
		F.pw2.focus();
		return false;
	}
	F.submit();
}

function chk_email()
{
	var F = document.email_form;

	if(!F.email.value) {
		alert('�̸����ּҸ� �Է��� �ּ���');
		return false;
	}
	F.submit();
}

function chk_url()
{
	var F = document.url_form;

	if(!F.url.value) {
		alert('�Խ��� �ּҸ� �Է��� �ּ���');
		return false;
	}
	F.submit();
}
-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000">
  <table width="750" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#000000" align="center">
          <tr bgcolor="#D6D6EB"> 
            <td colspan="7" height="25"> 
              <div align="center"><b>jboard ���� ������</b> <font color="red" style="cursor:help" onClick="window.open('http://www.jungbo.net/jbnm/','help_window','width=650, height=445')"><B>[����]</B></font></div>
            </td>
          </tr>
          <tr bgcolor="#FFFFFF"> 
            <td width="98" height="35"> 
              <div align="center">�Խ��Ǹ�(DB��)</div>
            </td>
            <td width="50" height="29"> 
              <div align="center">�Խù�</div>
            </td>
            <td width="125" height="29"> 
              <div align="center">��뷮(��ü/���ε�)</div>
            </td>
            <td height="29" width="*"> 
              <div align="center">�Խ��� ���� ����</div>
            </td>
            <td width="90">
              <div align="center">�Խ����ּ�</div>
            </td>
            <td width="49" height="29" bgcolor="#F3F3F3"> 
              <div align="center"><font color="#FF0000"><b>����</b></font></div>
            </td>
          </tr>
<?php
if(!count($d_list)) {
	echo "
          <tr bgcolor=\"#FFFFFF\">
            <td colspan=\"7\" align=\"center\">
              <BR><h3>������ �Խ����� �����ϴ�.</h4>
            </td>
          </tr>";
}
for($i = 0 ; $i < count($d_list) ; $i++) {
	$q = $i + 1;
	$base_path = "../data/$d_list[$i]";
	$dbm = dbmopen("$base_path/data.gdbm", "r");
	$config = dbmfetch($dbm, "config");
	$config = explode("|", $config);
	dbmclose($dbm);
	$idx = @file("$base_path/idx");
	$usage_article = exec("du -sH $base_path");
	$usage_article = explode("\t", $usage_article);
	$usage_binary = exec("du -sH $base_path/binary");
	$usage_binary = explode("\t", $usage_binary);
	$usage[article] = $usage_article[0];
	$usage[binary] = $usage_binary[0];
	$all = count(explode("|", $idx[0])) - 2;
	$all = ($all <= 0) ? 0 : $all;
	$url = "<a href='http://�������� �Խ����ּ�/?code=$d_list[$i]'>test</a>";
	if(!$admin[url]) {
		$admin[url] = "http://�����ǰԽ����ּ�";
	}

	echo "
          <tr bgcolor=\"#FFFFFF\"> 
            <td height=\"31\" >&nbsp;<a href=\"../?code=$d_list[$i]\" target=\"_new\">$d_list[$i] ($config[0])</a></td>
            <td align=\"right\">$all ��&nbsp;</td>
            <td align=\"right\">$usage[article] / $usage[binary]&nbsp;</td>
            <td width=\"250\" align=\"center\">
              <input type='button' value='�Խù�����' onClick=\"open_win2('./contents/?code=$d_list[$i]')\" class=\"b\">
              <input type='button' value='������' onClick=\"open_win('./admin_gonggi.php?code=$d_list[$i]')\" class=\"b\">
              <input type='button' value='��������' onClick=\"open_win('./admin_modify.php?code=$d_list[$i]')\" class=\"b\">
            </td>
            <td>
              <div align=\"center\"><input type=\"button\" value=\"Ȯ���ϱ�\" class=\"b\" onClick=\"disp_url('$admin[url]/?code=$d_list[$i]');\"></div>
            </td>
            <td bgcolor=\"#F3F3F3\"> 
              <div align=\"center\"> 
                <input type='button' value='����' onClick=\"chk_del('$d_list[$i]')\" class=\"del\">
              </div>
            </td>
          </tr>";
}
?>
        </table>
        <br>
        <hr width="100%" size="1" noshade align="center">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="65" align="center">
          <!-- ===== �Խ��ǻ����� ===== -->
          <form method="post" action="" name="new_form">
          <tr> 
            <td width="376" height="22"> 
              <div align="left">
                <b><font color="#999999">��</font> <font color="#000066">�Խ��� ���� 
                <input type="text" name="board_code" size="12" class="fil">
                <input type="button" value="����" class="b" onClick="new_board();">
                </font></b>
              </div>
            </td>
            <td width="120" height="22"> 
              <div>
                <b><font color="#999999">��</font><font color="#000066" style="cursor:hand" onClick="open_win('./admin_ban.php');"> ��ϰź��� ����</font></b>
              </div>
            </td>
          </tr>
          <tr><td colspan="2" height="2"></td></tr>
          </form>
          <!-- ===== ������ ��� ���� �� ===== -->
          <form method="post" action="admin_act.php" name="pw_form" onSubmit="return chk_pw();">
          <input type="hidden" name="mode" value="modify_pw">
          <tr> 
            <td colspan="2">
              <b><font color="#999999">��</font> <font color="#000066">������ ��й�ȣ ����</font> </b>: ����ȣ 
              <input type="password" name="pw1" size="8" class="fil">
              ���Է� 
              <input type="password" name="pw2" size="8" class="fil">
              <input type="button" value="����" class="b" onClick="chk_pw();">
            </td>
          </tr>
          <tr><td colspan="2" height="2"></td></tr>
          </form>
          <!-- ===== ������ �̸��� ���� ===== -->
          <form method="post" action="admin_act.php" name="email_form" onSubmit="return chk_email();">
          <input type="hidden" name="mode" value="modify_email">
          <tr> 
            <td colspan="2">
              <b><font color="#999999">��</font> <font color="#000066">������ �̸��Ϻ���</font> </b>: 
              <input type="text" name="email" size="25" class="fil" value="<?=$admin[email]?>">
              <input type="button" value="����" class="b" onClick="chk_email();">
            </td>
          </tr>
          <tr><td colspan="2" height="2"></td></tr>
          </form>
          <form method="post" action="admin_act.php" name="url_form">
          <input type="hidden" name="mode" value="modify_url">
          <tr> 
            <td>
              <b><font color="#999999">��</font> <font color="#000066">�Խ����ּ�</font> </b>: 
              <input type="text" name="url" size="40" class="fil" value="<?=$admin[url]?>">
              <input type="button" value="����" class="b" onClick="chk_url();">
            </td>
            <td width="120" height="22"> 
              <div>
                <b><font color="#999999">��</font><font color="#000066" style="cursor:hand" onClick="this.document.location.href='./admin_login_process.php'"> �α׾ƿ�</font></b>
              </div>
            </td>
          </tr>
          <tr><td colspan="2" height="2"></td></tr>
          </form>
          <tr> 
            <td colspan="2">
              <hr width="100%" size="1" noshade align="center">
            </td>
          </tr>
          <tr> 
            <td id="tr_url" colspan="2" style="font-size:12pt; color:blue; display:none"><BR>
              <B><span id='url_info'></span></B>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
<!-- �Խ��� ���� �� -->
<form method="post" action="./admin_act.php" name="del_form">
<input type="hidden" name="mode" value="del">
<input type="hidden" name="code" value="">
</form>
<!-- �Խ��� ���� �� -->
</body>
</html>
<!-- ##### copyright (c) 2002 by jungbo.net all rights reserved #####-->