<?php
/*

	�۸�Ϻ��� ��� ȭ��

*/


//
// ���� Access üũ
//
if($HTTP_GET_VARS[p] != "detail") include ("./include/direct.inc");


//
// ���� ������ üŷ.
//
if(!$HTTP_GET_VARS[page]) $HTTP_GET_VARS[page] = 1;


//
// ���ø� ����
//
//$tpl = & new Template("./template"); // php 4.0.0 ���� ���� ���鼭 �ٲ��
$tpl = new Template("./template");
$tpl -> define (
	array(
		all => "list.tpl",
	)
);


//
// ����Ʈ ��� ����!!!
//
Main();




/*------------------------------------------------------------
	# ����Ʈ ���� �Լ� ����
*/
//
// �����Լ�
//
function Main() // void
{
	global $HTTP_GET_VARS, $tpl, $config;

	/* �ش� �Խ����� �ε��� �̾ƿ��� */
	$idx = get_idx();

	/* �̾ƿ� �ε��� ������ ������ ������ ������ �����Ѵ� */
	$info = get_info($idx);

	/* �Խù�, ������ ����, Ÿ��Ʋ��... */
	if($HTTP_GET_VARS[mode] == "srch") {
		$tpl_str_info = "��ü ".$info[total_article]."���� �Խù��� �˻��Ǿ����ϴ� - ���� ".$info[current_page]."/".$info[total_page]."������";
	} else {
		$tpl_str_info = "��ü ".$info[total_article]."���� �Խù����ֽ��ϴ�.  - ���� ".$info[current_page]."/".$info[total_page]."������";
	}

	/* ������ ���� */
	$page_nav = get_page_nav($info);

	/* ���ø� ���� */
	if($HTTP_GET_VARS[p] != "list") {
		$board_title = "";
	}
	$write = "<a href=\"./?p=new&code=$HTTP_GET_VARS[code]\">[����]</a>";
	$tpl -> assign(
		array(
			INFO => $tpl_str_info,
			CODE => $HTTP_GET_VARS[code],
			PAGE_NAV => $page_nav,
			BOARD_TITLE => "jboard : �Խù�����($HTTP_GET_VARS[code])",
			WRITE => $write,
		)
	);

	/* �Խ��Ǻ� �������� ��� */
	if($HTTP_GET_VARS[page] == 1) prt_gonggi();

	/* ���� ���������� $config[9]��ŭ ������ ��� */
	prt_list($info, $idx);

	/* ���ø� assign �� ��� */
	$tpl -> parse(ALL, "all");
	$tpl -> FastPrint();
}


//
// �������� ��� 
//
function prt_gonggi()
{
	global $HTTP_GET_VARS, $tpl, $config, $db_file;
	$dbm = dbm_open($db_file[data], "r");
	if(dbmexists($dbm, "G_num")) {
		$G_num = dbm_fetch($dbm, "G_num");
		for($i = $G_num ; $i >= 0 ; $i--) {
			$unique = "G_".$i;
			if(dbmexists($dbm, $unique)) {
				$data = explode("|", dbm_fetch($dbm, $unique));
				$subject = detail_link($data);
				$name = email_link($data);
				$reg_date = explode(" ", $data[9]);
				$tpl -> assign(
					array(
						HIT => $data[10],
						DATE => $reg_date[0],
						NUMBER => "��",
						SUBJECT => "<B>$subject</B>",
						NAME => $name,
						NOTICE => "[N]",
					)
				);
				$tpl -> parse(GONGGI, ".gonggi");
			}
		}
	}
}


//
// ����Ʈ ���
//
function prt_list($info, $idx) // void
{
	global $HTTP_GET_VARS, $tpl, $config, $db_file;

	$dbm = dbm_open($db_file[data], "r");

	for($i = $info[s_point] ; $i < $info[e_point] ; $i++) {
		$article = $idx[$i];
		$data = explode("|", dbm_fetch($dbm, $article));
		for($j = 0 ; $j < count($data) ; $j++) {
			$data[$j] = str_replace("rhkdvk", "|", $data[$j]);
		}
		$tpl_subject = detail_link($data);
		$tpl_name = email_link($data);
		$reg_date = explode(" ", $data[9]);
		if($HTTP_GET_VARS[id] == $data[0]) {
			$number = "��";
		} else {
			$number = $data[1];
		}
		if($HTTP_GET_VARS[p] == "detail") $G_mode = "sublist";
		$attache = get_attache($data[12], $G_mode);
		$tpl -> assign(
			array(
				NUMBER => $number,
				SUBJECT => $tpl_subject,
				NAME => $tpl_name,
				DATE => $reg_date[0],
				HIT => $data[10],
				ATTACHE => $attache,
				ID => $data[0],
			)
		);
		$tpl -> parse(CONTENTS, ".contents");
	}

	dbm_close($dbm);
}


//
// �̸��ϸ�ũ ����
//
function email_link($data) // string
{
	$GwangPa = new StringSize();
	$data[3] = $GwangPa -> cut($data[3], 75);

	if($data[5]) {
		$value = "<a href=\"mailto:$data[5]\">$data[3]</a>";
	} else {
		$value = $data[3];
	}

	return $value;
}


//
// �󼼺��� ��ũ ����
//
function detail_link($data) // string
{
	global $HTTP_GET_VARS;

	if($data[11] >= 1) {
		$temp = "";
		$gp = "";
		for($a = 0 ; $a < $data[11] ; $a++) {
			$blank .= "&nbsp;&nbsp;";
			$gp .= "1";
		}
		$gpp = $gp."-Re: ".$data[2];
		$GwangPa = new StringSize();
		$temp2 = $GwangPa -> cut($gpp, 275);
		$temp2 = explode("-", $temp2);
		$str = $temp2[1];
	} else {
		$GwangPa = new StringSize();
		$temp = $GwangPa -> cut($data[2], 275);
		$str = $temp;
	}
	if($HTTP_GET_VARS[what] || $HTTP_GET_VARS[request]) {
		$val = $blank."<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$data[0]&page=$HTTP_GET_VARS[page]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">$str</a>";
	} else {
		$val = $blank."<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$data[0]&page=$HTTP_GET_VARS[page]\">$str</a>";
	}

	return $val;
}


//
// ������ ����
//
function get_info($idx) // array
{
	global $HTTP_GET_VARS, $config;

	$info[total_article] = count($idx);
	$info[total_page] = ceil($info[total_article] / $config[9]);
	if($info[total_page] <= 0) $info[total_page] = 1;
	$info[s_point] = ($HTTP_GET_VARS[page] - 1) * $config[9];
	$info[e_point] = $HTTP_GET_VARS[page] * $config[9];
	if($info[e_point] > $info[total_article]) $info[e_point] = $info[total_article];
	$info[current_page] = $HTTP_GET_VARS[page];

	return $info;
}


//
// ������ ����
//
function get_page_nav($info) // string
{
	global $HTTP_GET_VARS, $config;

	// Get Total Article
	$total = $info[total_article];

	// Setting Variable
	$page_last = $info[total_page];
	$page_prev = $info[current_page] - 1;
	if($page_prev < 1) { $page_prev = 1; }

	$page_next = $info[current_page] + 1;
	if($page_next > $page_last) { $page_next = $page_last; }

	$page_min_center = ceil($config[10] / 2);
	$page_term = $page_min_center - 1;
	$page_max_center = $page_last - $page_min_center;
	
	// First,Previous Page Link
	if($info[current_page] != 1) {
		if($HTTP_GET_VARS[mode] == "srch") {
			$plink[first]  = "<a href=\"./?p=list&page=1&code=$HTTP_GET_VARS[code]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[��ó��]</a>";
		} else {
			$plink[first]  = "<a href=\"./?p=list&page=1&code=$HTTP_GET_VARS[code]\">[��ó��]</a>";
		}

		if($HTTP_GET_VARS[mode] == "srch") {
			$plink[prev]  = "<a href=\"./?p=list&page=$page_prev&code=$HTTP_GET_VARS[code]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[����]</a>";
		} else {
			$plink[prev]  = "<a href=\"./?p=list&page=$page_prev&code=$HTTP_GET_VARS[code]\">[����]</a>";
		}
	} else {
		$plink[first] = "[��ó��]";
		$plink[prev] = "[����]";
	}
	
	// Last,Next Page Link
	if($info[current_page] != $page_last) {
		if($HTTP_GET_VARS[mode] == "srch") {
			$plink[last]  = "<a href=\"./?p=list&page=$page_last&code=$HTTP_GET_VARS[code]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[������]</a>";
		} else {
			$plink[last]  = "<a href=\"./?p=list&page=$page_last&code=$HTTP_GET_VARS[code]\">[������]</a>";
		}

		if($HTTP_GET_VARS[mode] == "srch") {
			$plink[next]  = "<a href=\"./?p=list&page=$page_next&code=$HTTP_GET_VARS[code]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[����]</a>";
		} else {
			$plink[next]  = "<a href=\"./?p=list&page=$page_next&code=$HTTP_GET_VARS[code]\">[����]</a>";
		}
	} else {
		$plink[last] = "[������]";
		$plink[next] = "[����]";
	}
	
	// Page Link(About $pp)
	$p = "";
	if($page_last <= $config[10]) {
		$page_start = 1;
		$page_end = $page_last;
	} else {
		if($info[current_page] <= $page_min_center) {
			$page_start = 1;
			$page_end = $config[10];
		} elseif($info[current_page] > $page_max_center) {
			$page_start = $page_last - $config[10] + 1;
			$page_end = $page_last;
		} else {
			$page_start = $info[current_page] - $page_term;
			$page_end = $info[current_page] + $page_term;
		}
	}

	for($i = $page_start ; $i <= $page_end ; $i++) {
		if($i == $info[current_page]) {
			$p .= " $i ";
		} else {
			if($HTTP_GET_VARS[mode] == "srch") {
				$p .= " <a href=\"./?p=list&page=$i&code=$HTTP_GET_VARS[code]&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[$i]</a>";
			} else {
				$p .= " <a href=\"./?p=list&page=$i&code=$HTTP_GET_VARS[code]\">[$i]</a>";
			}
		}
	}

	if($HTTP_GET_VARS[what] || $HTTP_GET_VARS[request]) {
		$plink[all]  = "<a href=\"./?p=list&code=$HTTP_GET_VARS[code]\">[��ü�۸��]<a>";
	}

	$page_nav  = "$plink[first] $plink[prev]$p $plink[next] $plink[last] $plink[all]";

    return $page_nav;
}


//
// ���ڿ� �ڸ���
//
class StringSize
{
    /* ������ �⺻ ��Ʈ : ����ü, 9pt */
    var $SPECIAL = 6;   /* ASCII ������ Ư������(ASCII �ڵ� 1~32) */
    var $MCHAR = 12;    /* �ѱ� ���� */
    var $BASE = 32;     /* ASCII �ڵ� ���Ѱ� */
    var $END =  127;    /* ASCII �ڵ� ���Ѱ� */
    var $ASCII = Array(
            4,4,4,6,6,10,8,4,5,5,6,6,4,6,4,6,6,6,6,6,6,6,6,6,6,6,
            4,4,8,6,8,6,12,8,8,9,8,8,7,9,8,3,6,8,7,11,9,9,8,9,8,8,
            8,8,8,10,8,8,8,6,11,6,6,6,4,7,7,7,7,7,3,7,7,3,3,6,3,11,
            7,7,7,7,4,7,3,7,6,10,7,7,7,6,6,6,9,6
    );
    function cut($str,$width){
        $str = strip_tags($str);
        $str = preg_replace("/ {2,}/"," ",$str);
        $str = preg_replace("/^ | $/","",$str);
        $len = strlen($str);
        if ($width < $len * $this->MCHAR){
            for($i=0;$i<$len;$i=$i+$charLen){
                $code = ord($str[$i]);
                if ($code <= $this->END){
                    $charSize   = $this->getAscSize($code);
                    $charLen    = 1;
                }
                else{
                    $charSize   = $this->MCHAR;
                    $charLen    = 2;
                }
                if ($charSize < $width) $width -= $charSize;
                else            break;
            }
            return substr($str,0,$i);
        }
        return $str;
    }
    function getAscSize($code){
        if ($code < $this->BASE)    return $this->SPECIAL;
        else{
            $idx = $code - $this->BASE;
            return $this->ASCII[$idx];
        }
    }
}
?>