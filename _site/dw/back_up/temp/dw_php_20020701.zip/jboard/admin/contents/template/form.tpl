<html>
<head>
<title>jboard :: �Խù�����</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<style type="text/css">
<!--
td {  font-family: "����"; font-size: 9pt}
a:link,a:visited{text-decoration:none}
a:hover {text-decoration:underline}
INPUT,SELECT,TEXTAREA { border:1 solid #999999; background-color: #FFFFFF; color: #333333; }
-->
</style>
<script>
<!--
//
// �Է³��� üũ
//
function chk_form()
{
	var f = document.gwangpa_form;

	if(!f.subject.value.length) {
		alert('������ �Է��� �ּ���');
		f.subject.focus();
		return false;
	}
	if(!f.name.value.length) {
		alert('�̸��� �Է��� �ּ���');
		f.name.focus();
		return false;
	}
	if(!f.passwd.value.length) {
		alert('��й�ȣ�� �Է��� �ּ���');
		f.passwd.focus();
		return false;
	}
	if(!f.comment.value.length) {
		alert('������ �Է��� �ּ���');
		f.comment.focus();
		return false;
	}
	
	f.submit();
}


//
// OnLoad ��Ŀ�� �̵�
//
function move_focus()
{
	document.gwangpa_form.subject.focus();
}
-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#333333" link="#333333" vlink="#333333" alink="#333333" topmargin="10" marginwidth="0" marginheight="0" onLoad="move_focus();">
<table width="550" border="0" cellspacing="0" cellpadding="0">
  <tr height="10">
    <td>
      <table width="550" border="0" cellspacing="0" cellpadding="0" align="right">
      <form method="post" action="./?p=act&code={CODE}" enctype="multipart/form-data" name="gwangpa_form">
      <input type="hidden" name="mode" value="{MODE}">
      <input type="hidden" name="id" value="{ID}">
      <input type="hidden" name="depth" value="{DEPTH}">
      <input type="hidden" name="page" value="{PAGE}">
        <tr>
          <td colspan="5" height="35">
            <div align="center">
              <b>{BOARD_TITLE}</b>
            </div>
          </td>
        </tr>
        <tr bgcolor="#999999">
          <td>
            <table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">���� : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <input type="text" name="subject" size="40" value="{SUBJECT}">
                </td>
                <td bgcolor="#FFFFFF">
                  * ������ �Է��ϼ���.
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">�۾��� : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <input type="text" name="name" size="12" value="{NAME}">
                </td>
                <td bgcolor="#FFFFFF">
                  * �̸��� �Է��ϼ���.
                </td>
              <!-- BEGIN DYNAMIC BLOCK: hpw -->
              <input type="hidden" name="passwd" value="nothing">
              <!-- END DYNAMIC BLOCK: hpw -->
              </tr>
              <!-- BEGIN DYNAMIC BLOCK: pw -->
              <tr> 
                <td bgcolor="#E4E4E4">
                  <div align="right">��й�ȣ : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <input type="password" name="passwd" size="12">
                </td>
                <td bgcolor="#FFFFFF">
                  * ��й�ȣ�� �Է��ϼ���
                </td>
              </tr>
              <!-- END DYNAMIC BLOCK: pw -->
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">Ȩ������ : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <input type="text" name="url" size="35" value="{URL}">
                </td>
                <td bgcolor="#FFFFFF">
                  * Ȩ������ �ּҸ� �Է��ϼ���.
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">�̸��� : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <input type="text" name="email" size="35" value="{EMAIL}">
                </td>
                <td bgcolor="#FFFFFF">
                  * �̸��� �ּҸ� �Է��ϼ���.
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">HTML : </div>
                </td>
                <td bgcolor="#FFFFFF"> 
                  <select name="html">
                  <option value=''>HTML ��뿩��</option>
                  <option value='n'>������</option>
                  <option value='br'>���(�ٹٲ����)</option>
                  <option value='y'>���(�ٹٲ޹���)</option>
                  </select>
                </td>
                <td bgcolor="#FFFFFF">
                  HTML ��뿩�θ� �����ϼ���
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E4E4E4" valign="top"> 
                  <div align="right">���� : </div>
                </td>
                <td bgcolor="#FFFFFF" colspan="2">
                  <textarea name="comment" cols="63" rows="15">{COMMENT}</textarea>
                </td>
              </tr>
              <!-- BEGIN DYNAMIC BLOCK: fileup -->
              <tr> 
                <td bgcolor="#E4E4E4"> 
                  <div align="right">{FIELD} : </div>
                </td>
                <td bgcolor="#FFFFFF" colspan="2"> 
                  <input type="file" name="{UPNAME}" size="50">
                </td>
              </tr>
              <!-- END DYNAMIC BLOCK: fileup -->
              <tr bgcolor="#FFFFFF"> 
                <td valign="top" colspan="3">
                  <div align="center">
                    <input type="button" value="Ȯ��" onClick="chk_form();">
                    <input type="button" value="���(�ڷ�)" onClick="history.go(-1)">
                  </div>
                </td>
              </tr>
            </form>
            </table>
          </td>
        </tr>
        <tr><td height="30"></td></tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
