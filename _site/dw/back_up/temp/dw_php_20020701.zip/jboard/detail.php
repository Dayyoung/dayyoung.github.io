<?php
/*

	�󼼺��� ��� ȭ��

*/


//
// ���� Access üũ
//
include ("./include/direct.inc");


//
// ���� ������, üũ
//
$dbm = dbm_open($db_file[data], "r");
if($HTTP_GET_VARS[multiview] != "yes") {
	if(!dbmexists($dbm, $HTTP_GET_VARS[id])) err("�������� �ʴ� �۹�ȣ ���̵� �Դϴ�\\n");
}
dbm_close($dbm);
$Q = substr($HTTP_GET_VARS[id], 0, 1);


//
// �ۺ��� ��� ����
//
Detail_Main();
//echo urldecode($REQUEST_URI);


/*------------------------------------------------------------
    # �ۺ��� ���� �Լ� ����
*/
//
// �����Լ�
//
function Detail_Main() // void
{
	global $HTTP_POST_VARS, $HTTP_GET_VARS, $tpl, $db_file, $HTTP_COOKIE_VARS, $sep, $config, $Q;

	if($HTTP_GET_VARS[multiview] != "yes") {
		$m_cnt = 1;
	} else {
		$m_cnt = count($HTTP_GET_VARS[mview]);
	}

	for($m_i = 0 ; $m_i < $m_cnt ; $m_i++) { // ������ ������ ��찡 �����Ƿ� Loop
		$id = ($HTTP_GET_VARS[multiview] == "yes") ? $HTTP_GET_VARS[mview][$m_i] : $HTTP_GET_VARS[id];
		$dbm = @dbmopen($db_file[data], "w");
		$data = dbm_fetch($dbm, $id);
		$data = explode("|", $data);
		$data[10]++; // ��ȸ�� ����
		$new_data = implode("|", $data);
		dbm_replace($dbm, $id, $new_data);
		dbm_close($dbm);
	
		$data[3] = str_replace("rhkdvk", "|", $data[3]);
		$data[5] = str_replace("rhkdvk", "|", $data[5]);
		$data[6] = str_replace("rhkdvk", "|", $data[6]);
		$tpl_email = d_email_link($data);
		$tpl_url = url_link($data);
		$tpl_comment = $data[7];
		$tpl_comment = str_replace("rhkdvk", "|", $tpl_comment);
		$tpl_comment = texthtml($tpl_comment, $data[13]);
		$tpl_subject = str_replace("rhkdvk", "|", $data[2]);
		$nav = get_nav($data[11], $id, "img");
		if($config[4] != "open") {
			$nav[write] = ""; $nav[reply] = ""; $nav[modify] = ""; $nav[del] = "";
		}
		if($Q == "G") {
			$nav[write] = ""; $nav[reply] = ""; $nav[modify] = ""; $nav[del] = ""; $nav[prev] = ""; $nav[next] = "";
		}
	
		// ������ �����ϰ�� Ÿ��Ʋ�� �ѹ��� ����ϵ��� �Ѵ�
		if($HTTP_GET_VARS[multiview] == "yes") {
			if($m_i == 0) {
				$tpl -> assign(array(B_TITLE => $config[14]));
			}
		} else { // �ƴѰ�쿡�� Ÿ��Ʋ�� ���
			$tpl -> assign(array(B_TITLE => $config[14]));
		}

		/* ÷��ȭ�� ��Ʈ�ѷ�(?) */
		/*
		if($data[11] == 0 && $data[12]) {
			$tpl -> parse(SHOW_HIDE_ATTACHE, "show_hide_attache");
		}
		*/

		/* ÷��ȭ�� */
		$tmp = explode("?", $data[12]);
		$up_cnt = count($tmp) - 1;
		for($i = 1 ; $i <= $up_cnt ; $i++) {
			$seq = "÷��ȭ��$i";
			$attache = get_attache($tmp[($i - 1)]);
			$body_img .= $attache[1];
			$tpl -> assign(
				array(
					FILE_SEQ => $seq,
					FILE_UP => $attache[0],
				)
			);
			$tpl -> parse(UPLOAD, ".upload");
		}

		/** ������ ���� ��� */
		if($config[21]) {
			$p_date = $data[9]." / ".$data[8];
		} else {
			$p_date = $data[9];
		}

		// ���ø� ���� �� ���
		$tpl -> assign(
			array(
				TITLE => $tpl_title,
				SUBJECT => $tpl_subject,
				NAME => $data[3],
				EMAIL => $tpl_email,
				URL => $tpl_url,
				COMMENT => $body_img."<BR>".$tpl_comment,
				DATE => $p_date,
				LINK_LIST => $nav[lst],
				LINK_MODIFY => $nav[modify],
				LINK_DEL => $nav[del],
				LINK_PREV => $nav[prev],
				LINK_NEXT => $nav[next],
				LINK_REPLY => $nav[reply],
				LINK_WRITE => $nav[write],
				L_ATTACHE => "Attache_".$m_i,
				L_COMMENT => "Comment_".$m_i,
				B_WIDTH => $config[15],
				ALIGN => $config[20],
			)
		);

		/* �ǰ߱� */
		if($config[11] == 1 && $Q != "G" && $config[4] != "closed") { // �ǰ߱��� ������ ��� ���� ������ ��ɶ����� IF���� �����
			$form_name = "comment_form_$m_i"; // �����ۺ����������� �ڹٽ�ũ�� ��ü ������
			if($HTTP_GET_VARS[multiview] != "yes" || ($HTTP_GET_VARS[multiview] == "yes" && $config[13] == 1)) { // ������ ������ ��� �ǰ߱��Է��� ��¾���
				/* ������ */
				$tpl -> assign(
					array(
						FORM_NAME => $form_name,
						C_CODE => $HTTP_GET_VARS[code],
						C_ID => $id,
						COMMENT_NAME => $HTTP_COOKIE_VARS[jungbo_board_name],
					)
				);
				$tpl -> parse(COMMENT_FORM, "comment_form");
			}
	
			/* ���� ��� */
			$c_dbm = dbm_open($db_file[comment], "r");
			$tmp = dbm_fetch($c_dbm, $id);
			dbm_close($c_dbm);
			$tmp = explode("\n", $tmp);
			$cnt = count($tmp) - 1;
			for($i = 0 ; $i < $cnt ; $i++) {
				$del_url = "./?p=comment_del&code=$HTTP_GET_VARS[code]&id=$id&seq=$i";
				$data = explode($sep, $tmp[$i]);
				$tpl -> assign (
					array(
						COMMENT_BODY => $data[1],
						COMMENT_NAME => $data[0],
						COMMENT_DEL => "<img src=\"./img/i-pack/$config[18]/c_del.gif\" border=\"0\" align=\"absmiddle\" style=\"cursor:hand\" onClick=\"window.open('$del_url', 'c_del_win','width=280, height=180');\" alt=\"�ǰ߱ۻ����ϱ�\">",
					)
				);
				$tpl -> parse(COMMENT_BODY, ".comment_body");
			}
		}

		/* �ۺ���� ������ ������ */
		if($config[12] == 2 && $HTTP_GET_VARS[multiview] != "yes") {
			/** �ε��� GDBM ȭ �۾����� ���� �ּ�ó�� ��
			$fp = fopen("$db_file[idx]", "r");
			$G = fgets($fp, filesize("$db_file[idx]"));
			fclose($fp);
			*/
			$dbm = dbmopen($db_file[data], "r");
			$G = dbmfetch($dbm, "idx");
			dbmclose($dbm);
			$G = explode("|", $G);
			$G_2 = array_flip($G);
			$tmp = $G_2[$HTTP_GET_VARS[id]];
			$prev_id = $G[($tmp - 1)];
			$next_id = $G[($tmp + 1)];
			$dbm = dbmopen($db_file[data], "r");
			/* ������ */
			if($prev_id) {
				$p_data = explode("|", dbmfetch($dbm, $prev_id));
				$p_str = "<a href=\"./?code=$HTTP_GET_VARS[code]&p=detail&id=$prev_id\">$p_data[2]</a>";
			} else {
				$p_str = "���̻� ���� �����ϴ�";
			}
			/* ������ */
			if($next_id) {
				$n_data = explode("|", dbmfetch($dbm, $next_id));
				$n_str = "<a href=\"./?code=$HTTP_GET_VARS[code]&p=detail&id=$next_id\">$n_data[2]</a>";
			} else {
				$n_str = "���̻� ���� �����ϴ�";
			}
			$tpl -> assign (
				array(
					PREV_ARTICLE => $p_str,
					NEXT_ARTICLE => $n_str,
				)
			);
			$tpl -> parse(PRENEXT, ".prenext");
		}

		/* ���ø� ���� */
		$tpl -> parse(BODY, ".body");
		$tpl -> clear_dynamic("comment_body");
		$tpl -> clear_dynamic("upload");
	}

	/* �����ۺ��� ����� ��ũ(����, ����Ʈ) */
	if($HTTP_GET_VARS[multiview] == "yes") {
		$link = "<a href=\"./?p=new&code=$HTTP_GET_VARS[code]\">[����]</a> <a href=\"./?p=list&code=$HTTP_GET_VARS[code]\">[���]</a>";
		$tpl -> assign(
			array(
				LINK => $link,
			)
		);
	}

	/* ���ø� ��� */
	$tpl -> parse(ALL, "all");
	$tpl -> FastPrint();
}


//
// ������ �׺���̼�
//
function get_nav($depth, $id, $mode="") // string, array
{
	global $HTTP_POST_VARS, $HTTP_GET_VARS, $config, $Q;

	$idx = get_idx();
	if(isset($idx)) { $s = implode("|", $idx); }
	$key = array_search_lib($id, $idx);
	$p_id = $idx[($key - 1)]; // ������ ID
	$n_id = $idx[($key + 1)]; // ������ ID
	$key2 = ($key) ? $key : 1;
	$c_pg = ceil(($key + 1) / $config[9]);
	$p_pg = ceil(($key + 1 - 1) / $config[9]);
	$n_pg = ceil(($key + 1 + 1) / $config[9]);
	$depth++;

	// �۸��
	if($HTTP_GET_VARS[mode] == "srch") {
		if($mode == "link") {
			$val[lst] = "./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]";
		} elseif($mode == "img") {
			$val[lst] = "<a href=\"./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\"><img src=\"./img/i-pack/$config[18]/list.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
		} else {
			$val[lst] = "<a href=\"./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[�˻����]</a>";
		}
	} else {
		if($mode == "link") {
			$val[lst] = "./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg";
		} elseif($mode == "img") {
			$val[lst] = "<a href=\"./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg\"><img src=\"./img/i-pack/$config[18]/list.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
		} else {
			$val[lst] = "<a href=\"./?p=list&code=$HTTP_GET_VARS[code]&page=$c_pg\">[���]</a>";
		}
	}

	// ����
	if($mode == "link") {
		$val[write] = "./?p=new&code=$HTTP_GET_VARS[code]";
	} elseif($mode == "img") {
		$val[write] = "<a href=\"./?p=new&code=$HTTP_GET_VARS[code]\"><img src=\"./img/i-pack/$config[18]/write.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
	} else {
		$val[write] = "<a href=\"./?p=new&code=$HTTP_GET_VARS[code]\">[����]</a>";
	}
	
	// ���
	if($mode == "link") {
		$val[reply] = "./?p=reply&code=$HTTP_GET_VARS[code]&id=$id&depth=$depth&page=$HTTP_GET_VARS[page]";
	} elseif($mode == "img") {
		$val[reply] = "<a href=\"./?p=reply&code=$HTTP_GET_VARS[code]&id=$id&depth=$depth&page=$HTTP_GET_VARS[page]\"><img src=\"./img/i-pack/$config[18]/reply.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
	} else {
		$val[reply] = "<a href=\"./?p=reply&code=$HTTP_GET_VARS[code]&id=$id&depth=$depth&page=$HTTP_GET_VARS[page]\">[���]</a>";
	}

	// ����
	if($mode == "link") {
		$val[modify] = "./?p=modify&code=$HTTP_GET_VARS[code]&id=$id";
	} elseif($mode == "img") {
		$val[modify] = "<a href=\"./?p=modify&code=$HTTP_GET_VARS[code]&id=$id\"><img src=\"./img/i-pack/$config[18]/mod.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
	} else {
		$val[modify] = "<a href=\"./?p=modify&code=$HTTP_GET_VARS[code]&id=$id\">[����]</a>";
	}

	// ����
	if($mode == "link") {
		$val[del] = "./?p=del&code=$HTTP_GET_VARS[code]&id=$id";
	} elseif($mode == "img") {
		$val[del] = "<a href=\"./?p=del&code=$HTTP_GET_VARS[code]&id=$id\"><img src=\"./img/i-pack/$config[18]/del.gif\" border=\"0\" align=\"absmiddle\"></a>&nbsp;";
	} else {
		$val[del] = "<a href=\"./?p=del&code=$HTTP_GET_VARS[code]&id=$id\">[����]</a>";
	}

	// ������
	if(!$p_id) {
		if($mode == "link") {
			$val[prev] = "#";
		} else {
			$val[prev] = "<img src=\"./img/i-pack/$config[18]/prev.gif\" align=\"absmiddle\" border=\"0\">&nbsp;";
		}
	} else {
		if($HTTP_GET_VARS[mode] == "srch") {
			if($mode == "link") {
				$val[prev] = "./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]";
			} elseif($mode == "img") {
				$val[prev] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\"><img src=\"./img/i-pack/$config[18]/prev.gif\" align=\"absmiddle\" border=\"0\"></a>&nbsp;";
			} else {
				$val[prev] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[����]</a>";
			}
		} else {
			if($mode == "link") {
				$val[prev] = "./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg";
			} elseif($mode == "img") {
				$val[prev] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg\"><img src=\"./img/i-pack/$config[18]/prev.gif\" align=\"absmiddle\" border=\"0\"></a>&nbsp;";
			} else {
				$val[prev] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$p_id&page=$p_pg\">[����]</a>";
			}
		}
	}

	// ������
	if(!$n_id) {
		if($mode == "link") {
			$val[next] = "#";
		} else {
			$val[next] = "<img src=\"./img/i-pack/$config[18]/next.gif\" align=\"absmiddle\" border=\"0\">&nbsp;";
		}
	} else {
		if($HTTP_GET_VARS[mode] == "srch") {
			if($mode == "link") {
				$val[next] = "./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]";
			} elseif($mode == "img") {
				$val[next] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\"><img src=\"./img/i-pack/$config[18]/next.gif\" align=\"absmiddle\" border=\"0\"></a>&nbsp;";
			} else {
				$val[next] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg&mode=srch&what=$HTTP_GET_VARS[what]&request=$HTTP_GET_VARS[request]\">[����]</a>";
			}
		} else {
			if($mode == "link") {
				$val[next] = "./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg";
			} elseif($mode == "img") {
				$val[next] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg\"><img src=\"./img/i-pack/$config[18]/next.gif\" align=\"absmiddle\" border=\"0\"></a>&nbsp;";
			} else {
				$val[next] = "<a href=\"./?p=detail&code=$HTTP_GET_VARS[code]&id=$n_id&page=$n_pg\">[����]</a>";
			}
		}
	}

	$rtl = $val;
	return $rtl;
}


//
// URL ��ũ ����
//
function url_link($data)
{
	if($data[6]) {
		$str = "<a href=\"$data[6]\">$data[6]</a>";
	} else {
		$str = "None";
	}

	return $str;
}


//
// �̸��� ��ũ ����
//
function d_email_link($data)
{
	if($data[5]) {
		//$str = "<a href=\"mailto:$data[5]\">&lt;$data[5]&gt;</a>";
		$target = str_replace("@", "_NOSPAM_", $data[5]);
		$str = "<a href=\"mailto:$data[5]\" onMouseOut=\"window.status=''; return true;\" onMouseOver=\"window.status='Send mail �����'; return true\">[ E-mail ]</a><iframe name=\"dummy\" width=\"0\" height=\"0\" frameborder=\"0\"></iframe>";
	} else {
		$str = "";
	}

	return $str;
}


//
// �۸�Ͻ� ����Ʈ ���� ���
//
if($config[12] == 1 && $HTTP_GET_VARS[multiview] != "yes") {
	include ("./list.php");
}
?>
