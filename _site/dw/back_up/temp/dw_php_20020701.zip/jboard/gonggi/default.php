<html>
<head>
<title>jboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<style type="text/css">
<!--
td {  font-size: 9pt}
-->
</style>
</head>
<script>
<!--
function size()
{
	window.resizeTo(415, 430);
}
-->
</script>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="size();">
<table width="389" border="0" cellspacing="0" cellpadding="0" background="./img/gonggi/default/bg.gif" height="352">
  <tr> 
    <td height="38" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" background="./img/gonggi/default/top.gif">
        <tr> 
          <td width="40"></td>
          <td height="38" valign="middle">
            <nobr style='width:330; overflow:hidden' title='<?=$data[2]?>'><?=$data[2]?></nobr>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="289" valign="middle"> 
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" height="85%">
        <tr>
          <td height="*" valign="top" style="word-break:break-all">
            <BR>
<?=$tpl_comment?>
          </td>
        </tr>
        <tr>
          <td height="25" valign="bottom">
            <div align="right"><font color='#666666' style="font-size:8pt"><?=$data[9]?> / <?=$data[3]?></font></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td valign="top"><img src="./img/gonggi/default/bottom.gif"></td>
  </tr>
</table>
<BR>
<table width="389" border="0" cellspacing="5" cellpadding="0">
  <tr>
    <td>
      <div align="center"><input type="button" value="â�ݱ�" onClick="window.close();"></div>
    </td>
  </tr>
</table>
</body>
</html>