<script>
<!--
/* ÷��ȭ���� ���� ��� ÷��ȭ�� TR�� ����� ���̰� �� �ִ� �Լ� */
function show_hide(obj)
{
	var status = obj.style.display;

	if(status == "none") {
		obj.style.display = "inline";
	} else {
		obj.style.display = "none";
	}
}

/* �ǰ߱� ��Ͻ� üũ */
function chk_comment_form(form_name)
{

	var form = form_name;

	if(!form.c_name.value.length) {
		alert('�ǰ߱� �̸��� �Է��� �ּ���!');
		form.c_name.focus();
		return false;
	}
	if(!form.c_comment.value.length) {
		alert('�ǰ߱� ������ �Է��� �ּ���!');
		form.c_comment.focus();
		return false;
	}
	if(!form.c_passwd.value.length) {
		alert('�ǰ߱� ��й�ȣ�� �Է��� �ּ���!!');
		form.c_passwd.focus();
		return false;
	}
	form.submit();
}

/* �ǰ߱� ���� Submit */
function chk_submit(form_name)
{
	var Code = event.keyCode;
	if(Code == 13) {
		chk_comment_form(form_name);
	} else {
		return false;
	}
}
-->
</script>
<link rel=stylesheet type='text/css' href='img/sgi_chocolate/color.css'>
<DIV align="{ALIGN}">
<table width="{B_WIDTH}" border=0 cellspacing=0 cellpadding=0>
  <tr>
    <td align=right colspan=5><img src='img/sgi_chocolate/dummy.gif' width=1 height=15></td>
  </tr>
  <tr>
    <td colspan="5" height="35" align="center">
      <BR><H4>{B_TITLE}</h4>
    </td>
  </tr>
  <!-- BEGIN DYNAMIC BLOCK: body -->
  <tr>
    <td align=left width=16><img src='img/sgi_chocolate/title_l.gif'></td>
    <td width=50% background='img/sgi_chocolate/title_bg.gif' align=left class=base><img src='img/sgi_chocolate/title_bg.gif'></td>
    <td class=base>
      <table border=0 cellspacing=0 cellpadding=0 background='img/sgi_chocolate/title_read_bg.gif'>
        <tr valign=top>
          <td align=left><img src='img/sgi_chocolate/title_read_l.gif'></td>
          <td align=center><img src='img/sgi_chocolate/dummy.gif' width=1 height=12><br>
            <nobr>{SUBJECT}</nobr>
          </td>
          <td align=right><img src='img/sgi_chocolate/title_read_r.gif'></td>
        </tr>
      </table>
    </td>
    <td width=50% background='img/sgi_chocolate/title_bg.gif' align=right class=base><img src='img/sgi_chocolate/title_bg.gif'></td>
    <td align=right width=16><img src='img/sgi_chocolate/title_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 class=base>
      <table border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>����</td>
          <td align=center width=30><img src='img/sgi_chocolate/vLine.gif'></td>
          <td align=left width='*'>{NAME} {EMAIL}</td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 class=base>
      <table border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>Ȩ������</td>
          <td align=center width=30><img src='img/sgi_chocolate/vLine.gif'></td>
          <td align=left width='*'>{URL}</td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 class=base>
      <table border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100 valign="top">÷������</td>
          <td align=center width=30><img src='img/sgi_chocolate/vLine.gif'></td>
          <td align=left width='*'>
            <table width="100%" cellpadding="1" cellspacing="0" border="0">
              <!-- BEGIN DYNAMIC BLOCK: upload -->
              <tr>
                <td>{FILE_UP}</td>
              </tr>
              <!-- END DYNAMIC BLOCK: upload -->
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 align=center class=base>
      <table width=98% border=0 cellspacing=1 cellpadding=10 class=boxLn>
        <tr>
          <td align=left class=boxCl>
            {COMMENT}
            <BR><BR>
            <div style="word-break:break-all; font-size:8pt" align="right">{DATE}</div>
          </td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <!-- BEGIN DYNAMIC BLOCK: comment_form -->
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 align=center class=base>
      <table width=98% border=0 cellspacing=1 cellpadding=3 class=boxLn>
        <tr>
          <td class=boxCl align=center>
            <table width=100% border=0 cellspacing=0 cellpadding=0>
              <form method="post" action="./?p=act&code={C_CODE}" name="{FORM_NAME}">
              <input type="hidden" name="mode" value="comment">
              <input type="hidden" name="code" value="{C_CODE}">
              <input type="hidden" name="id" value="{C_ID}">
              <tr>
                <td width=75>�̸�</td>
                <td width='*'>�ǰ߱�</td>
                <td width=110>��й�ȣ</td>
              </tr>
              <tr>
                <td><input type=text name=c_name value='{COMMENT_NAME}' size=8 class=flat2></td>
                <td><input type=text name=c_comment value='' size=30 class=flat2 style='width:98%'></td>
                <td>
                  <input type=password name=c_passwd size=8 class=flat2 onKeyPress='chk_submit(this.form)'>
                  <input type=button value=��� onClick='chk_comment_form(this.form)' class=flat2 style='height:18'>
                </td>
              </tr>
              </form>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <!-- END DYNAMIC BLOCK: comment_form -->
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 align=center class=base>
      <table width="98%" cellpadding="3" cellspacing="1" border="0" boxLn>
        <tr>
          <td>
            <!-- �ǰ߱� ��� -->
            <table width="100%" border="0" cellspacing="0" cellpadding="1" align="center">
              <!-- BEGIN DYNAMIC BLOCK: comment_body -->
              <tr>
                <td width="80" style="word-break:break-all"><b>{COMMENT_NAME}</b></td>
                <td style="word-break:break-all">{COMMENT_BODY}</td>
                <td width="20"><div align="right">{COMMENT_DEL}</div></td>
              </tr>
              <!-- END DYNAMIC BLOCK: comment_body -->
            </table>
            <!-- �ǰ߱� ��� �� -->
          </td>
        </tr>
      </table>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <!-- ������ ������ -->
  <!-- BEGIN DYNAMIC BLOCK: prenext -->
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 class=base>
      <table border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=50>������</td>
          <td align=center width=30><img src='img/sgi_chocolate/vLine.gif'></td>
          <td align=left width='*'>{PREV_ARTICLE}</a></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td colspan=3 class=base>
      <table border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=50>������</td>
          <td align=center width=30><img src='img/sgi_chocolate/vLine.gif'></td>
          <td align=left width='*'>{NEXT_ARTICLE}</td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_chocolate/line_bg.gif'><img src='img/sgi_chocolate/line_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/line_r.gif'></td>
  </tr>
  <!-- END DYNAMIC BLOCK: prenext -->
  <!-- ������ ������ -->
  <tr>
    <td align=left background='img/sgi_chocolate/list_l.gif'><img src='img/sgi_chocolate/list_l.gif'></td>
    <td align=center colspan=3 class=base>
      {LINK_LIST}{LINK_MODIFY}{LINK_DEL}{LINK_PREV}{LINK_NEXT}{LINK_REPLY}{LINK_WRITE}
    </td>
    <td align=right background='img/sgi_chocolate/list_r.gif'><img src='img/sgi_chocolate/list_r.gif'></td>
  </tr>
  <tr>
    <td align=left><img src='img/sgi_chocolate/tail_l.gif'></td>
    <td colspan=3 background='img/sgi_chocolate/tail_bg.gif'></td>
    <td align=right><img src='img/sgi_chocolate/tail_r.gif'></td>
  </tr>
  <tr><td height="30"></td></tr>
  <!-- END DYNAMIC BLOCK: body -->
</table>
</DIV>