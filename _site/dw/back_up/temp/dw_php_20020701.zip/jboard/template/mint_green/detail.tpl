<script>
<!--
/* ÷��ȭ���� ���� ��� ÷��ȭ�� TR�� ����� ���̰� �� �ִ� �Լ� */
function show_hide(obj)
{
	var status = obj.style.display;

	if(status == "none") {
		obj.style.display = "inline";
	} else {
		obj.style.display = "none";
	}
}

/* �ǰ߱� ��Ͻ� üũ */
function chk_comment_form(form_name)
{

	var form = form_name;

	if(!form.c_name.value.length) {
		alert('�ǰ߱� �̸��� �Է��� �ּ���!');
		form.c_name.focus();
		return false;
	}
	if(!form.c_comment.value.length) {
		alert('�ǰ߱� ������ �Է��� �ּ���!');
		form.c_comment.focus();
		return false;
	}
	if(!form.c_passwd.value.length) {
		alert('�ǰ߱� ��й�ȣ�� �Է��� �ּ���!!');
		form.c_passwd.focus();
		return false;
	}
	form.submit();
}

/* �ǰ߱� ���� Submit */
function chk_submit(form_name)
{
	var Code = event.keyCode;
	if(Code == 13) {
		chk_comment_form(form_name);
	} else {
		return false;
	}
}
-->
</script>

<DIV align="{ALIGN}">
<table width="{B_WIDTH}" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" colspan="2"><BR><H4>{B_TITLE}</h4></td>
  </tr>
  <tr>
    <td>
      <!-- BEGIN DYNAMIC BLOCK: body -->
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="24">
        <tr> 
          <td align="left" valign="middle"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#000000" height="24">
        <tr>
          <td bgcolor="#FFFFFF" align="center" valign="middle">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="24" background="img/mint_green/top_bg.gif">
              <tr align="center"> 
                <td width="29" valign="middle"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#000000">
        <tr>
          <td bgcolor="#FFFFFF" align="center" valign="middle"> 
            <table width="100%" border="0" cellspacing="1" cellpadding="0">
              <tr> 
                <td width="133" align="left" background="img/mint_green/linebg_03.gif">
                  <font size="2">&nbsp;&nbsp;&nbsp;&nbsp<img src="img/mint_green/arrow.gif" width="8" height="9" align="absmiddle"> �� �� </font>
                </td>
                <td valign="middle" colspan="2" background="img/mint_green/linebg_04.gif" height="21">
                  <font size="2">{NAME} {EMAIL}</font>
                </td>
              </tr>
              <tr> 
                <td width="133" align="left" background="img/mint_green/linebg_03.gif">
                  <font size="2">&nbsp&nbsp&nbsp&nbsp<img src="img/mint_green/arrow.gif" width="8" height="9" align="absmiddle"> �� �� </font>
                </td>
                <td valign="middle" colspan="2" height="21" background="img/mint_green/linebg_04.gif">
                  <font size="2">{SUBJECT}</font>
                </td>
              </tr>
              <tr>
                <td width="133" align="left" background="img/mint_green/linebg_03.gif">
                  <font size="2">&nbsp&nbsp&nbsp&nbsp<img src="img/mint_green/arrow.gif" width="8" height="9" align="absmiddle"> Ȩ������ </font>
                </td>
                <td valign="middle" colspan="2" background="img/mint_green/linebg_04.gif" height="21">
                  <font size="2">{URL}</font>
                </td>
              </tr>
              <!-- BEGIN DYNAMIC BLOCK: upload -->
              <tr> 
                <td width="133" align="left" background="img/mint_green/linebg_03.gif">
                  <font size="2">&nbsp&nbsp<img src="img/mint_green/disk.gif" width="14" height="14" align="absmiddle"> {FILE_SEQ} </font>
                </td>
                <td valign="middle" colspan="2" background="img/mint_green/linebg_04.gif" height="21">
                  {FILE_UP}
                </td>
              </tr>
              <!-- END DYNAMIC BLOCK: upload -->
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="D1D1D1">
              <tr> 
                <td bgcolor="#FFFFFF" height="45">
                  <table width="100%" border="0" cellspacing="10" cellpadding="3">
                    <tr>
                      <td> 
{COMMENT}
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="3">
              <tr>
                <td>
                  <!-- BEGIN DYNAMIC BLOCK: comment_form -->
                  <table width="500" border="0" cellspacing="0" cellpadding="1" bgcolor="#CCCCCC" align="right">
                    <form method="post" action="./?p=act&code={C_CODE}" name="{FORM_NAME}">
                    <input type="hidden" name="mode" value="comment">
                    <input type="hidden" name="code" value="{C_CODE}">
                    <input type="hidden" name="id" value="{C_ID}">  
                    <tr>
                      <td> 
                        <table border="0" cellpadding="3" cellspacing="0" width="100%">
                          <tr bgcolor="#F7F7F7" valign="bottom"> 
                            <td width="16"></td>
                            <td width="72"> 
                              <div align="left">�̸�</div>
                            </td>
                            <td> 
                              <div align="left">����</div>
                            </td>
                            <td width="140"> 
                              <div align="left">��й�ȣ</div>
                            </td>
                          </tr>
                          <tr bgcolor="#F7F7F7"> 
                            <td width="16"></td>
                            <td width="72"> 
                              <div align="left">
                                <input type="text" name="c_name" value="{COMMENT_NAME}" size="8" class="box">
                              </div>
                            </td>
                            <td> 
                              <div align="left">
                                <input type="text" name="c_comment" value="" class="box" style="width:100%">
                              </div>
                            </td>
                            <td width="140"> 
                              <div align="left"> 
                                <input type="password" name="c_passwd" size="8" class="box" onKeyPress="chk_submit(this.form)"> 
                                <input type="button" value="���" onClick="chk_comment_form(this.form)" class="box">
                              </div>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                    </form>
                  </table>
                  <!-- END DYNAMIC BLOCK: comment_form -->
                </td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="3">
              <!-- BEGIN DYNAMIC BLOCK: comment_body -->
              <tr>
                <td width="80" style="word-break:break-all"><b>{COMMENT_NAME}</b></td>
                <td style="word-break:break-all">{COMMENT_BODY}</td>
                <td width="20"><div align="right">{COMMENT_DEL}</div></td>
              </tr>
              <!-- END DYNAMIC BLOCK: comment_body -->
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="51" bgcolor="E6F3BD">
              <tr> 
                <td></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="32" background="img/mint_green/bot_bg.gif">
              <tr> 
                <td align="center" valign="bottom"> 
                  <table width="530" border="0" cellspacing="0" cellpadding="0">
                    <tr align="center"> 
                      <td align="left">{LINK_LIST}</td>
                      <td width="60">{LINK_MODIFY}</td>
                      <td width="60">{LINK_DEL}</td>
                      <td align="right" width="120">{LINK_PREV}</td>
                      <td width="70">{LINK_NEXT}</td>
                      <td align="right">{LINK_REPLY} {LINK_WRITE}</td>
                    </tr>
                  </table>
                  <img src="img/mint_green/dummy.gif" width="500" height="5"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <!-- END DYNAMIC BLOCK: body -->
    </td>
  </tr>
</table>
<BR>
<!-- BEGIN DYNAMIC BLOCK: prenext -->
<table border=0 width={B_WIDTH} cellspacing=0 cellpadding=0>
  <tr> 
    <td colspan=8 bgcolor="#464646" height="1"></td>
  </tr>
  <tr align=center height=22>
    <td width=50>����</td>
    <td align=left style='word-break:break-all;'>
      <img src=img/web/blank.gif height=3>&nbsp; &nbsp;{PREV_ARTICLE}
    </td>
  </tr>
</table>
<table border=0 width={B_WIDTH} cellspacing=0 cellpadding=0>
  <tr>
    <td colspan=8  bgcolor="#464646" height="1"></td>
  </tr>
  <tr align=center height=22>
    <td width=50>����</td>
    <td align=left style='word-break:break-all;'>
      <img src=img/web/blank.gif height=3>&nbsp; &nbsp;{NEXT_ARTICLE}
    </td>
  </tr>
</table>
<table border=0 cellpadding cellspacing=0 width={B_WIDTH}>
  <tr><td colspan=10 bgcolor="#464646" height="1"></td></tr>
</table>
<!-- END DYNAMIC BLOCK: prenext -->
</DIV>
