<script language=javascript>
<!--
var process = false;
//
// �Է³��� üũ
//
function chk_form()
{
	if(process) {
		alert('ó�����Դϴ�!!');
		return false;
	} else {
		var f = document.gwangpa_form;

		if(!f.subject.value.length) {
			alert('������ �Է��� �ּ���');
			f.subject.focus();
			return false;
		}
		if(!f.name.value.length) {
			alert('�̸��� �Է��� �ּ���');
			f.name.focus();
			return false;
		}
		if(!f.passwd.value.length) {
			alert('��й�ȣ�� �Է��� �ּ���');
			f.passwd.focus();
			return false;
		}
		if(!f.comment.value.length) {
			alert('������ �Է��� �ּ���');
			f.comment.focus();
			return false;
		}
		process = true;	
		f.submit();
	}
}


//
// OnLoad ��Ŀ�� �̵�
//
function move_focus()
{
	document.gwangpa_form.subject.focus();
}

function useHTML(){
  sFRM = document.gwangpa_form.html
  sIMG = document.uHtml

	if ( sFRM.value == 'y' ) {
	  sFRM.value = '';
	  sIMG.src = 'img/sgi_sky/useHTML.gif';
	} else {
	  sFRM.value = 'y';
	  sIMG.src = 'img/sgi_sky/useHTML_chk.gif';
	}
}
-->
</script>
<link rel=stylesheet type='text/css' href='img/sgi_sky/color.css'>
<DIV ALIGN="{ALIGN}">
<table width="{B_WIDTH}" border=0 cellspacing=0 cellpadding=0>
  <form method="post" action="./?p=act&code={CODE}" enctype="multipart/form-data" name="gwangpa_form">
  <input type="hidden" name="mode" value="{MODE}">
  <input type="hidden" name="id" value="{ID}">
  <input type="hidden" name="depth" value="{DEPTH}">
  <input type="hidden" name="page" value="{PAGE}">
  <tr valign=top>
    <td align=right colspan=5><img src='img/sgi_sky/dummy.gif' width=1 height=15></td>
  </tr>
  <tr>
    <td align=left width=16><img src='img/sgi_sky/title_l.gif'></td>
    <td width=50% background='img/sgi_sky/title_bg.gif' align=left class=base><img src='img/sgi_sky/title_bg.gif'></td>
	<td class=base>
      <table border=0 cellspacing=0 cellpadding=0 background='img/sgi_sky/title_write_bg.gif'>
        <tr valign=top>
          <td align=left><img src='img/sgi_sky/title_write_l.gif'></td>
          <td align=center><img src='img/sgi_sky/dummy.gif' width=200 height=1>��</td>
          <td align=right><img src='img/sgi_sky/title_write_r.gif'></td>
        </tr>
      </table>
    </td>
    <td width="50%" background='img/sgi_sky/title_bg.gif' align=right class=base><img src='img/sgi_sky/title_bg.gif'></td>
    <td align=right width=16><img src='img/sgi_sky/title_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>����</td>
          <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
          <td align=left width='*'><input type=text size=40 name=subject class=flat style='width:85%' value="{SUBJECT}"></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>����</td>
          <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
          <td align=left width='*'><input type=text size=40 name=name class=flat style='width:85%' value="{NAME}"></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>����</td>
          <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
          <td align=left width='*'><input type=text size=40 name=email class=flat style='width:85%' value="{EMAIL}"></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>Ȩ������</td>
          <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
          <td align=left width='*'><input type=text size=40 name=url class=flat style='width:85%' value="{URL}"></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
        <td align=right width=100>��й�ȣ</td>
        <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
        <td align=left width='*'><input type=password size=40 name=passwd class=flat style='width:95%'></td>
        <td align=left width=100>
          <select name="html">
          <option value=''>HTML ��뿩��</option>
          <option value='n'>������</option>
          <option value='br'>���(�ٹٲ����)</option>
          <option value='y'>���(�ٹٲ޹���)</option>
          </select>
          <!-- <img src='img/sgi_sky/useHTML_chk.gif' name=uHtml border=0 onClick="useHTML()" style="cursor: hand"><br> -->
        </td>
      </tr>
    </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 align=center class=base>
      <textarea name=comment rows=15 cols=60 class=flat style='width:98%'>{COMMENT}</textarea>
	</td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <!-- BEGIN DYNAMIC BLOCK: fileup -->
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right width=100>���Ͽø���</td>
          <td align=center width=30><img src='img/sgi_sky/vLine.gif'></td>
          <td align=left width='*'><input type=file size=48 name="{UPNAME}" class=flat style='width:85%'></td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <!-- END DYNAMIC BLOCK: fileup -->
  <!-- BEGIN DYNAMIC BLOCK: sizeinfo -->
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
    <td colspan=3 class=base>
      <table width=100% border=0 cellspacing=0 cellpadding=0>
        <tr>
          <td align=right>�ִ� {SIZE}Bytes</td>
        </tr>
      </table>
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/line_l.gif'></td>
    <td align=left colspan=3 background='img/sgi_sky/line_bg.gif'><img src='img/sgi_sky/line_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/line_r.gif'></td>
  </tr>
  <!-- END DYNAMIC BLOCK: sizeinfo -->
  <tr>
    <td align=left background='img/sgi_sky/list_l.gif'><img src='img/sgi_sky/list_l.gif'></td>
	<td align=center colspan=3 class=base>
      <img src="./img/i-pack/{I_PACK}/save.gif" style="cursor:hand" onClick="chk_form();">
      <img src="./img/i-pack/{I_PACK}/cancel.gif" style="cursor:hand" onClick="history.go(-1);">
    </td>
    <td align=right background='img/sgi_sky/list_r.gif'><img src='img/sgi_sky/list_r.gif'></td>
  </tr>
  <tr valign=top>
    <td align=left><img src='img/sgi_sky/tail_l.gif'></td>
    <td colspan=3 background='img/sgi_sky/tail_bg.gif'></td>
    <td align=right><img src='img/sgi_sky/tail_r.gif'></td>
  </tr>
</form>
</table>
</DIV>