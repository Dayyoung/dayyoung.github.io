<!-- �ڹٽ�ũ��Ʈ�� �״�� ���� �� �ּ��� -->
<!-- �����Ͱ� ���ؼ� �˻����� �߰� ���� �ּ��� -->
<!--
    * �������� ó�� �ϴ� �κ��� �ΰ��� ���
      ! �Խ��� �ɼǻ� ����� �Ǿ�� �� ��, ����� ���� �ʾƾ� �Ҷ�.
      ! �ݺ��� �Ǵ� �κ�(�ݺ��� �Ǵ� �κ��� 1���� �ʿ�)
-->
<!-- ��ó��, ������ �̹��� �߰����ּ��� -->
<script>
<!--
var all = 'none';

/*
	�˻��� �˻��� �Է� Ȯ�� ��ũ��
*/
function search()
{
	var ff = document.search_form;

	if(ff.request.value.length <= 0) {
		alert('�˻�� �Է��ϼ���');
		ff.request.focus();
		return false;
	} else {
		ff.submit();
	}
}

/*
	������ ���� ��ɽ� üũ ���� Ȯ�� ��ũ��
*/
function chk_multiview()
{
	var chkchk;
	var F = document.mview_form;

	for(i = 0 ; i < F.elements.length ; i++) {
		if(F.elements[i].type == 'checkbox') {
			if(F.elements[i].checked) {
				chkchk = "ok";
			}
		}
	}

	if(chkchk == "ok") {
		F.submit();
	} else {
		alert('������ ���⸦ �� ���� ������ �ּ���!!');
		return false;
	}
}

/*
	������ ������ ���� üũ
*/
function all_chk()
{
	var F = document.mview_form;

	if(all == 'none') {
		all = 'all';
		control = true;
	} else {
		all = 'none';
		control = false;
	}

	for(i = 0 ; i < F.elements.length ; i++) {
		if(F.elements[i].type == 'checkbox') {
			F.elements[i].checked = control;
		}
	}
}
-->
</script>
<DIV ALIGN="{ALIGN}">
<table width="{B_WIDTH}" border="0" cellspacing="0" cellpadding="0" height="88">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="20">
<!-- ����κ��� �߰� �Ͽ����ϴ�. �Խ��� ������ ����ؾ� �Ұ� ���Ƽ� -->
        <tr>
          <td align="center" colspan="2"><BR><H4>{B_TITLE}</h4></td>
        </tr>
<!-- ����κ��� �߰� �Ͽ����ϴ�. �Խ��� ������ ����ؾ� �Ұ� ���Ƽ� -->
        <tr>
          <td width="50%">{ADMIN}</td>
          <td width="50%" align="right">{INFO}</td>
        </tr>
        <tr><td colspan="2" height="3"></td></tr>
      </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="27" background="img/simple_orange/top-bg.gif">
          <tr> 
            <td width="9"> 
              <div align="left"><img src="img/simple_orange/top-left.gif" width="9" height="27"></div>
            </td>
            <td width="18">
            <div align="center"><span id="all_select" style="cursor:hand" onClick="all_chk();" title="��ü ����"><img src="img/simple_orange/check.gif" width="12" height="13"></span></div>
            </td>
            <td width="35"> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">��ȣ</font></div>
            </td>
            <td> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">����</font></div>
            </td>
            <td width="60"> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">�̸�</font></div>
            </td>
            <td width="36"> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">����</font></div>
            </td>
            <td width="70"> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">��¥</font></div>
            </td>
            <td width="36"> 
              <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#00000">��ȸ</font></div>
            </td>
            <td width="7">
              <div align="right"><img src="img/simple_orange/top-right.gif"></div>
            </td>
          </tr>
        </table>
	    <table widht="100%"><tr><td height="1"></td></tr></table>
        <table width="100%" border="0" cellspacing="1" cellpadding="0" bgcolor="#333333">
          <tr>
            <td height="85"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <!-- ������ ���⸦ ���� ���Դϴ�. ���±׿� ������ ��� �׷��� ���� �ؾ� �մϴ� -->
                <!-- ������ ���� �� ����� ��� ���ξ� �մϴ�. contents ���̳��ͺ����� ���� �ָ� �˴ϴ� -->
                <form method="get" action="./?p=detail&code={CODE}" name="mview_form">
                  <input type="hidden" name="multiview" value="yes">
                  <input type="hidden" name="p" value="detail">
                  <input type="hidden" name="code" value="{CODE}">
                  <!-- BEGIN DYNAMIC BLOCK: gonggi -->
                  <tr height="23"> 
                    <td width="26" colspan="2" bgcolor="#F4F8FF" > 
                      <div align="center">{NUMBER}</div>
                    </td>
                    <td width="36" bgcolor="#F4F8FF"> 
                      <div align="center">{NOTICE}</div>
                    </td>
                    <td bgcolor="#F4F8FF"> 
                      <div align="left">{SUBJECT}</div>
                    </td>
                    <td width="60" bgcolor="#F4F8FF" > 
                      <div align="center">{NAME}</div>
                    </td>
                    <td width="36" bgcolor="#F4F8FF" > 
                      <div align="center"></div>
                    </td>
                    <td width="70" bgcolor="#F4F8FF" > 
                      <div align="center">{DATE}</div>
                    </td>
                    <td width="36" bgcolor="#F4F8FF" > 
                      <div align="center">{HIT}</div>
                    </td>
                  </tr>
                  <!-- END DYNAMIC BLOCK: gonggi -->
                  <tr> 
                    <td colspan="8" height="1" bgcolor="#F3F3F3"></td>
                  </tr>
                  <!-- BEGIN DYNAMIC BLOCK: contents -->
                  <tr> 
                    <td width="9" bgcolor="#FFFFFF" > 
                      <div align="center"></div>
                    </td>
                    <td width="18" bgcolor="#FFFFFF" > 
                      <input type="checkbox" name="mview[]" value="{ID}" style="border:0">
                    </td>
                    <td width="35" bgcolor="#FFFFFF" > 
                      <div align="center">{NUMBER}</div>
                    </td>
                    <td bgcolor="#FFFFFF" > 
                      <div align="left">&nbsp;&nbsp;{SUBJECT}</div>
                    </td>
                    <td width="60" bgcolor="#FFFFFF" > 
                      <div align="center">{NAME}</div>
                    <td width="36" bgcolor="#FFFFFF" > 
                      <div align="center">{ATTACHE}</div>
                    </td>
                    <td width="70" bgcolor="#FFFFFF" > 
                      <div align="center">{DATE}</div>
                    </td>
                    <td width="36" bgcolor="#FFFFFF" > 
                      <div align="center">{HIT}</div>
                    </td>
                  </tr>
                                 <tr> 
                    <td colspan=11 height=1>
                      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="1" background="img/simple_orange/line.gif">
                        <tr>
                          <td height="1"></td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- END DYNAMIC BLOCK: contents -->
                </form>
              </table>
              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="img/simple_orange/down-bg.gif" height="43">
                <tr> 
                  <td width="10"><img src="img/simple_orange/down-left.gif"></td>
                  <td width="109">{LINK_MVIEW}</td>
                  <td><!-- --></td>
                  <td> 
                    <div align="right">{LINK_WRITE}</div>
                  </td>
                  <td width="10" height="43"> 
                    <div align="right"><img src="img/simple_orange/down-right.gif"></div>
                  </td>
                </tr>
              </table>
              </td>
          </tr>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <form method="get" action="./" name="form">
          <input type="hidden" name="p" value="list">
          <input type="hidden" name="code" value="{CODE}">
          <input type="hidden" name="mode" value="srch">
     	  <tr><td height="10" colspan="3"></td></tr>
          <tr height="28">
            <td>
              <div align="left">{PAGE_NAV}</div>
            </td>
            <td align="right">
              <select name="what">
                <option value="subject"selected>����</option>
                <option value="name">�̸�</option>
                <option value="comment">����</option>
              </select>
              <input type="text" name="request">
              <input type="submit" value="�˻�" style="height:18">
            </td>
          </tr>
          </form>
        </table>
    </td>
  </tr>
</table>
