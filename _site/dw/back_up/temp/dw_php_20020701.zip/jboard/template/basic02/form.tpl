<script>
<!--
var process = false;
//
// �Է³��� üũ
//
function chk_form()
{
	if(process) {
		alert('ó�����Դϴ�!!');
		return false;
	} else {
		var f = document.gwangpa_form;

		if(!f.subject.value.length) {
			alert('������ �Է��� �ּ���');
			f.subject.focus();
			return false;
		}
		if(!f.name.value.length) {
			alert('�̸��� �Է��� �ּ���');
			f.name.focus();
			return false;
		}
		if(!f.passwd.value.length) {
			alert('��й�ȣ�� �Է��� �ּ���');
			f.passwd.focus();
			return false;
		}
		if(!f.comment.value.length) {
			alert('������ �Է��� �ּ���');
			f.comment.focus();
			return false;
		}
		process = true;	
		f.submit();
	}
}


//
// OnLoad ��Ŀ�� �̵�
//
function move_focus()
{
	document.gwangpa_form.subject.focus();
}
-->
</script>
<DIV ALIGN="{ALIGN}">
<table width="{B_WIDTH}" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><BR><H4>{B_TITLE}</h4></td>
  </tr>
  <form method="post" action="./?p=act&code={CODE}" enctype="multipart/form-data" name="gwangpa_form">
  <input type="hidden" name="mode" value="{MODE}">
  <input type="hidden" name="id" value="{ID}">
  <input type="hidden" name="depth" value="{DEPTH}">
  <input type="hidden" name="page" value="{PAGE}">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="4" bgcolor="#336699">
        <tr> 
          <td><img src="color/blank.gif" width="1" height="3"></td>
        </tr>
      </table>
      <br>
      <table width="90%" border="0" cellspacing="1" cellpadding="0" align="center">
        <tr> 
          <td align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/sub.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="text" name="subject" size="40" value="{SUBJECT}">
          </td>
        </tr>
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/name.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="text" name="name" size="12" value="{NAME}">
          </td>
        </tr>
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/mail.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="text" name="email" size="35" value="{EMAIL}">
          </td>
        </tr>
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/homepage.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="text" name="url" size="35" value="{URL}">
          </td>
        </tr>
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/passwd.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="password" name="passwd" size="12">
            &nbsp;&nbsp;&nbsp;
            <select name="html">
            <option value=''>HTML ��뿩��</option>
            <option value='n'>������</option>
            <option value='br'>���(�ٹٲ����)</option>
            <option value='y'>���(�ٹٲ޹���)</option>
            </select>
            <!-- <input type="checkbox" name="html" value="y" style="border:0" {CHK_HTML}> HTML ��� -->
          </td>
        </tr>
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/comment.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <textarea name="comment" cols="60" rows="15">{COMMENT}</textarea>
          </td>
        </tr>
        <!-- �Խ��� ������ ����÷�κκ��� 1�� �̻��̹Ƿ� ���̳������� ó�� -->
        <!-- BEGIN DYNAMIC BLOCK: fileup -->
        <tr> 
          <td  align=center width="76" bgcolor="#E2ECF5"><img src="img/basic02/fileup.gif" width="61" height="19"></td>
          <td width="3">&nbsp;</td>
          <td width="403"> 
            <input type="file" name="{UPNAME}" size="48">
          </td>
        </tr>
        <!-- END DYNAMIC BLOCK: fileup -->
        <!-- BEGIN DYNAMIC BLOCK: sizeinfo -->
        <tr> 
          <td colspan="3" width="482"> 
            <div align="right">�ִ� {SIZE}Bytes</div>
          </td>
        </tr>
        <!-- END DYNAMIC BLOCK: sizeinfo -->
        <tr> 
          <td colspan="3" height="50"> 
            <div align="center"> 
              <img src="./img/i-pack/{I_PACK}/save.gif" style="cursor:hand" onClick="chk_form();">
              <img src="./img/i-pack/{I_PACK}/cancel.gif" style="cursor:hand" onClick="history.go(-1);">
            </div>
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="4" bgcolor="#336699">
        <tr> 
          <td><img src="color/blank.gif" width="1" height="3"></td>
        </tr>
      </table>
    </td>
  </form>
  </tr>
</table>
</DIV>