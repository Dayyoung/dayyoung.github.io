<script>
<!--
var all = 'none';

/*
	�˻��� �˻��� �Է� Ȯ�� ��ũ��
*/
function search()
{
	var ff = document.search_form;

	if(ff.request.value.length <= 0) {
		alert('�˻�� �Է��ϼ���');
		ff.request.focus();
		return false;
	} else {
		ff.submit();
	}
}

/*
	������ ���� ��ɽ� üũ ���� Ȯ�� ��ũ��
*/
function chk_multiview()
{
	var chkchk;
	var F = document.mview_form;

	for(i = 0 ; i < F.elements.length ; i++) {
		if(F.elements[i].type == 'checkbox') {
			if(F.elements[i].checked) {
				chkchk = "ok";
			}
		}
	}

	if(chkchk == "ok") {
		F.submit();
	} else {
		alert('������ ���⸦ �� ���� ������ �ּ���!!');
		return false;
	}
}

/*
	������ ������ ���� üũ
*/
function all_chk()
{
	var F = document.mview_form;

	if(all == 'none') {
		all = 'all';
		control = true;
	} else {
		all = 'none';
		control = false;
	}

	for(i = 0 ; i < F.elements.length ; i++) {
		if(F.elements[i].type == 'checkbox') {
			F.elements[i].checked = control;
		}
	}
}
-->
</script>

<DIV ALIGN="{ALIGN}">
<table width="{B_WIDTH}" border="0" cellspacing="0" cellpadding="0" height="88">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="20">
        <!-- ����κ��� �߰� �Ͽ����ϴ�. �Խ��� ������ ����ؾ� �Ұ� ���Ƽ� -->
        <tr>
          <td align="center" colspan="2"><BR><H4>{B_TITLE}</h4></td>
        </tr>
        <!-- ����κ��� �߰� �Ͽ����ϴ�. �Խ��� ������ ����ؾ� �Ұ� ���Ƽ� -->
        <tr>
          <td width="50%">{ADMIN}</td>
          <td width="50%" align="right">{INFO}</td>
        </tr>
        <tr><td colspan="2" height="3"></td></tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="23" background="img/basic02/topbg.gif">
        <tr> 
          <td width="26"> 
            <div align="center"><span id="all_select" style="cursor:hand" onClick="all_chk();" title="��ü ����"><img src="img/basic02/check.gif"></span></div>
          </td>
          <td width="35"> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">��ȣ</font></div>
          </td>
          <td> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">����</font></div>
          </td>
          <td width="60"> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">�̸�</font></div>
          </td>
          <td width="36"> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">����</font></div>
          </td>
          <td width="70"> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">��¥</font></div>
          </td>
          <td width="36"> 
            <div align="center"><img src="img/web/blank.gif" width="1" height="13"><font color="#FFFFFF">��ȸ</font></div>
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <!-- ������ ���⸦ ���� ���Դϴ�. ���±׿� ������ ��� �׷��� ���� �ؾ� �մϴ� -->
        <!-- ������ ���� �� ����� ��� ���ξ� �մϴ�. contents ���̳��ͺ����� ���� �ָ� �˴ϴ� -->
        <form method="get" action="./?p=detail&code={CODE}" name="mview_form">
        <input type="hidden" name="multiview" value="yes">
        <input type="hidden" name="p" value="detail">
        <input type="hidden" name="code" value="{CODE}">
        <!-- BEGIN DYNAMIC BLOCK: gonggi -->
        <tr height="23" bgcolor="#F4F8FF">
          <td width="26" >
            <div align="center">{NUMBER}</div>
          </td>
          <td width="36">
            <div align="center">{NOTICE}</div>
          </td>
          <td> 
            <div align="left" title="{S_TITLE}">{SUBJECT}</div>
          </td>
          <td width="60" > 
            <div align="center">{NAME}</div>
          </td>
          <td width="36" > 
            <div align="center"></div>
          </td>
          <td width="70" > 
            <div align="center">{DATE}</div>
          </td>
          <td width="36" > 
            <div align="center">{HIT}</div>
          </td>
        </tr>
        <!-- END DYNAMIC BLOCK: gonggi -->
        <tr><td colspan="7" height="1" bgcolor="#F3F3F3"></td></tr>
        <!-- BEGIN DYNAMIC BLOCK: contents -->
        <tr onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#EEECFF'"> 
          <td width="26" > 
            <div align="center"> 
              <input type="checkbox" name="mview[]" value="{ID}" style="border:0">
            </div>
          </td>
          <td width="35" > 
            <div align="center">{NUMBER}</div>
          </td>
          <td > 
            <div align="left" title="{S_TITLE}">&nbsp;&nbsp;{SUBJECT}</div>
          </td>
          <td width="60" > 
            <div align="center">{NAME}</div>
          <td width="36" > 
            <div align="center">{ATTACHE}</div>
          </td>
          <td width="70" > 
            <div align="center">{DATE}</div>
          </td>
          <td width="36" > 
            <div align="center">{HIT}</div>
          </td>
        </tr>
	    <tr><td colspan=10 height=1 bgcolor="#e1e1e1"><img src=img/basic02/blank.gif height=1></td></tr>
        <!-- END DYNAMIC BLOCK: contents -->
        </form>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="2" bgcolor="#336699">
        <tr> 
          <td><img src="color/blank.gif" width="1" height="1"></td>
        </tr>
      </table>
      <br>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="58">{LINK_MVIEW}</td>
          <td> 
            <div align="center">{PAGE_NAV}</div>
          </td>
          <td width="50"> 
            <div align="right">{LINK_WRITE}</div>
          </td>
        </tr>
        <tr height="28">
        <form method="get" action="./" name="form">
        <input type="hidden" name="p" value="list">
        <input type="hidden" name="code" value="{CODE}">
        <input type="hidden" name="mode" value="srch">
          <td colspan="3"> 
            <p align="center"> 
              <select name="what">
                <option value="subject" selected>����</option>
                <option value="name">�̸�</option>
                <option value="comment">����</option>
              </select>
              <input type="text" name="request">
              <input type="submit" value="�˻�" style="height:18">
            </p>
          </td>
        </form>
        </tr>
      </table>
    </td>
  </tr>
</table>
</DIV>