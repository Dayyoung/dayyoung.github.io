<script>
<!--
//
// ������ �ε��� ��Ŀ�� �̵�
//
function move_focus()
{
	document.del_form.passwd.focus();
}


//
// �� ���۽� �Է»��� üũ
//
function chk_form()
{
	var f = document.del_form;

	if(!f.passwd.value.length) {
		alert('��й�ȣ�� �Է��ϼ���!!!');
		f.passwd.focus();
		return false;
	} else {
		f.submit();
	}
}
-->
</script>
<DIV ALIGN="{ALIGN}">
<table width="{B_WIDTH}" border="0" cellspacing="0" cellpadding="0">
<!-- ���� ���� form �±� �ȿ� ������� �մϴ� -->
<!-- form �±׿� �����±״� �״�� ���� �Ͽ� �ּ��� -->
<form method="post" action="./?p=act&code={CODE}" name="del_form">
<input type="hidden" name="mode" value="del">
<input type="hidden" name="id" value="{ID}">
  <tr>
    <td height="297">
      <table width="427" border="0" cellspacing="0" cellpadding="0" height="146" background="img/basic02/del-bg.gif" align="center">
        <tr> 
          <td> 
            <table width="400" border="0" cellspacing="0" cellpadding="0" align="center" height="140">
              <tr> 
                <td height="39" colspan="4"> 
                  <div align="left"><img src="img/basic02/del-icon.gif" width="126" height="39" border="0"></div>
                </td>
              </tr>
              <tr> 
                <td height="16" colspan="4" align="center">���� �����Ϸ� �մϴ�. ��й�ȣ�� �Է��Ͽ� �ֽʽÿ�.</td>
              </tr>
              <tr> 
                <td height="13" colspan="4"> 
                  <div align="center"> 
                    <input type="password" name="passwd" size="16">
                  </div>
                </td>
              </tr>
              <tr> 
                <td height="14" width="130"></td>
                <td height="14" width="72"> 
                  <div align="center"><a href="javascript:history.go(-1)"><img src="img/i-pack/{ICON_PACK}/list.gif" border="0"></a></div>
                </td>
                <td height="14" width="63"> 
                  <div align="center"><img src="img/i-pack/{ICON_PACK}/del.gif" border=0 style="cursor:hand" value="����" onClick="chk_form();"></div>
                </td>
                <td height="14" width="135"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</form>
</table>
</DIV>