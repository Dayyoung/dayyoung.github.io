<?php
	include("./inc/common.inc.php");
	include("./inc/db.inc.php");  

	$dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
	mysql_select_db($db_name, $dbconn) or die('��� ���� ����');
  
	$qry="select count(*) from tblNews " ;                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$total_rows=mysql_result($rst, 0 ,0);
	$start_rows=ceil($total_rows - 2 );  
	if ($start_rows < 0 ) {
		$start_rows = 0;
	}
	$qry="select *, date_format(reg_date, '%Y.%m.%d') as reg_date  from tblNews LIMIT $start_rows,$total_rows" ;
	                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$count_row = @mysql_num_rows($rst);
 
	
?>
<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<script language="JavaScript">
<!-- //��â����
	function openWinp01(url)
	  	{ var winopts = "width=520,height=480,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no, marginwidth=0, marginheight=0";
			   window.open(url, 'thewindow', winopts); }
-->
</script>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="images/top_back.gif"><a href="/"><img src="images/top_e_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="images/flash/e_menu_m.swf">
        <param name=quality value=high>
        <embed src="images/flash/e_menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="images/top_back_e.gif" width="50%"></td>
  </tr>
  <tr> 
    <td width="146"><img src="images/main/side_e_1.gif" width="146" height="202"></td>
    <td width="635" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="202">
        <param name=movie value="images/flash/main_e.swf">
        <param name=quality value=high>
        <embed src="images/flash/main_e.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="202">
        </embed> 
      </object></td>
    <td rowspan="7" width="50%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="146" rowspan="4"></td>
    <td rowspan="4" background="images/gra_back.gif" width="11" valign="top"><img src="images/gra_back.gif" width="11" height="8"> 
    </td>
    <td width="624" height="20"></td>
  </tr>
  <tr> 
    <td width="624" height="20"> 
      <table width="607" border="0" cellspacing="0" cellpadding="0" align="right">
        <tr> 
          <td width="8" rowspan="3"><img src="images/main/news_side_1.gif" width="8" height="145"></td>
          <td bgcolor="#ACACAA" height="1"></td>
          <td width="8" rowspan="3"> 
            <div align="right"><img src="images/main/news_side_2.gif" width="8" height="145"></div>
          </td>
        </tr>
        <tr> 
          <td height="143"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td rowspan="2" valign="top"> 
                  <div align="center"><img src="images/main/news_title.gif" width="95" height="66"></div>
                </td>
                <td width="454" height="35">Daewon Industry is the leader opening 
                  the future of package industry through customer satisfaction. 
                  Since its foundation in 1971, Daewon Industry has pursued customer 
                  satisfaction with high quality and differentiated products.</td>
              </tr>
              <tr> 
                <td width="454"> 
                  <table width="454" border="0" cellspacing="0" cellpadding="0" align="center">
                    <tr> 
                      <td colspan="3"><img src="images/main/point_line.gif" width="454" height="1"></td>
                    </tr>
<?
	if($count_row!=0){
		for($i=$count_row-1; $i>=0; $i--){
			mysql_data_seek($rst, $i);
			$row=mysql_fetch_array($rst);
		#while($row = mysql_fetch_array($rst)) {
			echo("                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='images/main/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td width='325'><a href='./board/read.php?db=tblNews&id=$row[id]'>$row[title]</a></td>
                      <td width='100'> 
                        <div align='right'>[ $row[reg_date] ]</div>
                      </td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='images/main/point_line.gif' width='454' height='1'></td>
                    </tr>
	    	
			");
		
		}	//while�� �ݱ�    
	}	//if�� �ݱ�
	else{
		echo("	
                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='images/main/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td colspan='2' width='325'><div align='center'>No more data</div></td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='images/main/point_line.gif' width='454' height='1'></td>
                    </tr>

		");
	}        		

?>         
                    <tr> 
                      <td colspan="3"><img src="images/main/point_line.gif" width="454" height="1"></td>
                    </tr>
                    <tr> 
                      <td colspan="3" height="20"> 
                        <div align="right">�� <a href='./board/list.php?db=tblNews'>More</a> -</div>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#ACACAA" height="1"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td width="624" height="20"></td>
  </tr>
  <tr> 
    <td width="624" height="20" align="right"> 
      <table width="607" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td><a href="javascript:openWinp01('popup/popup_main_ebo1.html')""><img src="images/e_main_bo1.jpg" width="151" height="120" border="0"></a></td>
          <td><a href="javascript:openWinp01('popup/popup_main_ebo2.html')""><img src="images/e_main_bo2.jpg" width="151" height="120" border="0"></a></td>
          <td><a href="javascript:openWinp01('popup/popup_main_ebo3.html')""><img src="images/e_main_bo3.jpg" width="151" height="120" border="0"></a></td>
          <td><a href="javascript:openWinp01('popup/popup_main_ebo4.html')""><img src="images/e_main_bo4.jpg" width="154" height="120" border="0"></a></td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50">
      <div align="center"><img src="images/copy_add_e.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
