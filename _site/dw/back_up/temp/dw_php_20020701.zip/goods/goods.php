<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<script language="JavaScript">
<!-- //��â����
	function openWinp01(url)
	  	{ var winopts = "width=520,height=480,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no, marginwidth=0, marginheight=0";
			   window.open(url, 'thewindow', winopts); }
-->
</script>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><img src="../images/top_logo.gif" width="146" height="84"></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="../images/flash/menu_m.swf">
        <param name=quality value=high>
        <embed src="../images/flash/menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="145" height="535"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td colspan="2"><img src="images/goods_1_1.gif" width="226" height="51"></td>
        </tr>
        <tr> 
          <td height="25" width="50" background="images/back_line.gif"></td>
          <td height="25" width="550"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_1_1.gif" width="143" height="17"></td>
              </tr>
              <tr> 
                <td width="4%"></td>
                <td width="59%" class="compa" valign="top">����� ���ϴ� ���� ������ǰ�� ���忡 
                  ���̸�, ����, ���� ��սÿ��� ������ ������ ����<br>
                  ( ���� : PET / NY / CPP. ��)</td>
                <td width="37%" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_01.htm')"><img src="images/image_pouch_1.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="4%" height="20"></td>
                <td width="59%" height="20"></td>
                <td width="37%" height="20" align="center"><a href="javascript:openWinp01('../popup/popup_goods_01.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_1_2.gif" width="143" height="17"></td>
              </tr>
              <tr> 
                <td width="4%"></td>
                <td width="59%" class="compa" valign="top">������ ������ �״�� �纸���� �����ϵ��� 
                  �������ʿ� Zipper�� ������ ������ ����</td>
                <td width="37%" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_02.htm')"><img src="images/image_pouch_2.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="4%" height="20"></td>
                <td width="59%" height="20"></td>
                <td width="37%" height="20" align="center"><a href="javascript:openWinp01('../popup/popup_goods_02.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
              <tr> 
                <td colspan="3"><img src="images/goods_1_1_3.gif" width="143" height="17"></td>
              </tr>
              <tr> 
                <td width="4%"></td>
                <td width="59%" class="compa" valign="top">������ �������� �ظ��� ���� ���·� 
                  ���� ���Ƿ� ���� ���� ���빰�� ���� �� ������ ��ǰ�� ������ ������ ������ ����</td>
                <td width="37%" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_03.htm')"><img src="images/image_pouch_3.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="4%" height="20"></td>
                <td width="59%" height="20"></td>
                <td width="37%" height="20" align="center"><a href="javascript:openWinp01('../popup/popup_goods_03.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_1_4.gif" width="270" height="17"></td>
              </tr>
              <tr> 
                <td width="4%"></td>
                <td width="59%" class="compa" valign="top">Ŀ���� ��⸦ �ܺη� �����ϸ鼭�� 
                  ���⸦ ������ ���ִ� ��긦 ������ ������ ����</td>
                <td width="37%" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_04.htm')"><img src="images/image_pouch_4.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="4%" height="20"></td>
                <td width="59%" height="20"></td>
                <td width="37%" height="20" align="center"><a href="javascript:openWinp01('../popup/popup_goods_04.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_1_5.gif" width="115" height="17"></td>
              </tr>
              <tr> 
                <td width="4%"></td>
                <td width="59%" class="compa" valign="top">������ ����ƽ�̳� ������� ���빰�� 
                  ������ �� �ֵ��� ���� ������ �������� �ַ� �������� ���� ���Ǹ� �������� �����ϵ��� ������� �����Ǵ� ��찡 
                  ����.</td>
                <td width="37%" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_05.htm')"><img src="images/image_pouch_5.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="4%" height="25"></td>
                <td width="59%" height="25"></td>
                <td width="37%" height="25" align="center"><a href="javascript:openWinp01('../popup/popup_goods_05.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td height="25" colspan="2"><img src="images/goods_1_2.gif" width="248" height="51"> 
            <a name="2"></a> </td>
        </tr>
        <tr> 
          <td width="50" background="images/back_line.gif"></td>
          <td width="550">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_2_1.gif" width="227" height="17"></td>
              </tr>
              <tr> 
                <td width="26"></td>
                <td class="compa" valign="top" width="315">��ܰ� �ϴ��� �ΰ����� �ʸ��� ���� 
                  �����·� ��ǰ�Ͽ���ǰ�� ����� ���ÿ� �� �ʸ��� ���� �����ϴ� ���� �ʸ����� �ַ� ���� ��ǰ ���忡 �̿�ȴ�.</td>
                <td width="209" class="compa"> 
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_06.htm')"><img src="images/image_roll_1.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="26" height="20"></td>
                <td width="315" height="20"></td>
                <td width="209" height="20" align="center"><a href="javascript:openWinp01('../popup/popup_goods_06.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
              <tr> 
                <td colspan="3" height="25"><img src="images/goods_1_2_2.gif" width="350" height="17"></td>
              </tr>
              <tr> 
                <td width="26"></td>
                <td width="315" class="compa" valign="top">�ڵ� �����⸦ ������ ��ü�� ������� 
                  �������� �ʸ��� ���� ��ǰ</td>
                <td width="209" class="compa"> 
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_07.htm')"><img src="images/image_roll_2.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="26" height="25"></td>
                <td width="315" height="25"></td>
                <td width="209" height="25" align="center"><a href="javascript:openWinp01('../popup/popup_goods_07.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td colspan="2"><img src="images/goods_1_3.gif" width="268" height="51"><a name="3"></a></td>
        </tr>
        <tr> 
          <td width="50"></td>
          <td width="550"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="25"></td>
                <td width="328" class="compa" valign="top">��ȭ����ȭ�� ��� ����� LLDPE�� 
                  ����� �پ��� ������ ũ���� LLDPE������ ��ü ���� ��� �� �Ǹ�</td>
                <td width="197" class="compa">
                  <div align="right"><a href="javascript:openWinp01('../popup/popup_goods_08.htm')"><img src="images/image_lldpe_1.jpg" width="204" height="132" border="0"></a></div>
                </td>
              </tr>
              <tr> 
                <td width="25" height="25"></td>
                <td width="328" height="25"></td>
                <td width="197" height="25" align="center"><a href="javascript:openWinp01('../popup/popup_goods_08.htm')"><img src="images/button_larger.gif" width="77" height="25" border="0"></a></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
