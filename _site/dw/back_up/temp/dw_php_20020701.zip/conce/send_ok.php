<?php 

//$contents = str_replace("\"", "<br>", $contents);
$contents = stripslashes($contents);

$to = "dwmak@daewon-ind.co.kr" ; 
$sub= "��㹮��" ; 
$mail_body = (" 
�̸� : $sender_name
�ּ� : $sender_addr
ȸ��� : $sender_comp
��ȭ��ȣ : $phone1-$phone2-$phone3
FAX : $fax1-$fax2-$fax3
<H4>��㳻��</H4>
$contents
"); 


$mailheaders .= "Return-Path: $sender_email\r\n"; 
$mailheaders .= "From: $sender_name<$sender_email>\r\n"; 
$mailheaders .= "X-Mailer: webmail\r\n"; 

$boundary = "----".uniqid("part"); 


$mailheaders .= "MIME-Version: 1.0\r\n"; 
$mailheaders .= "Content-Type: Multipart/alternative; boundary = " .$boundary ."\r\n"; 


$bodytext .= "--$boundary\r\n"; 
$bodytext .= "Content-Type: text/html; charset=euc_kr" ."\r\n"; 
$bodytext .= "Content-Transfer-Encoding:base64" ."\r\n\r\n"; 
$bodytext .= base64_encode(nl2br($mail_body))."\r\n"; 
$bodytext .= "--$boundary--\r\n"; 
$result = mail("$to", "$sub", "$bodytext", "$mailheaders"); 

?> 
<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="../images/flash/menu_m.swf">
        <param name=quality value=high>
        <embed src="../images/flash/menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="145" height="523"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td colspan="2"><img src="images/title_2.gif" width="194" height="54"></td>
        </tr>
        <tr> 
          <td height="139" valign="top" width="49" background="images/title_2_back.gif" rowspan="3"><img src="images/title_2_back.gif" width="49" height="6"></td>
          <td height="25" width="551">&nbsp;</td>
        </tr>
        <tr>
          <td height="257"><div align="center"><img src="images/send_image.gif" width="487" height="177"></div></td>
        </tr>
        <tr> 
          <td height="30" width="551"></td>
        </tr>
        <tr> 
          <td height="1" valign="top" width="49"></td>
          <td height="1" width="551" bgcolor="#8E8E8E"></td>
        </tr>
        <tr> 
          <td height="40" valign="top" width="49"></td>
          <td height="60" width="551"> <div align="center"><a href="../index.php"><img src="../board/images/bu_ok.gif" width="67" height="20" border="0"></a></div></td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>

