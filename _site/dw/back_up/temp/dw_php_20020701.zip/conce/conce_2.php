<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�

function chk_number(obj) { 
	if( obj.value.length > 0 )
	{
		if(isNaN(obj.value)) {
			alert('�� �׸񿡴� ���ڸ� �Է°����մϴ�.');
			obj.value = "";
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}

} 
function checkSpace(strCheck) {
	for ( var i=0 ; i<strCheck.length ; i++ ) {
        if ( strCheck.charAt(i) == " " ) {
            return false;
        }
    }
    return true;
}
function checkEmail() {
    var strEmail = document.form_email.sender_email.value;
    var strEmails = strEmail.split("@");
    var temp = "";

    if ( !checkSpace(strEmail) ) {
         return false;
    }
    if ( strEmails.length != 2 ) {
             return false;
    }
    if ( strEmails[0].length == 0 || strEmails[1].length == 0 ) {
    	 return false;
    }
    for (i=0 ; i<strEmails[1].length ; i++ ) {
	if ( strEmails[1].charAt(i)==".") {
            temp += ".";
        }
    }
    if (temp == "") {
        return false;
    }
    
    for (iii=0 ; iii<strEmails[1].length ; iii++ ) {
	if ( strEmails[1].charAt(iii)==".") {
            temp_2= iii;
        }
    }        
    if ( temp_2 == 0 ) {
    	 return false;
    }
    return true;
}

function send_mail()
{
	var form = document.form_email;	
	if(form.sender_email.value=="")
	{
		alert("�����ּҸ� �Է����ֽʽÿ�!");
		form.sender_email.value="";
		form.sender_email.focus();
		return ;
	}     
	var iii = form.sender_email.value;
	if ( iii.indexOf('@') == -1 || iii.indexOf('.') == -1 ) 
	{
		alert('�����ּҰ� ���������Դϴ�. �ٽ� �Է����ֽʽÿ�!');
		form.sender_email.value="";
		form.sender_email.focus();
		return ;
	}

	if ( !checkEmail() ) {
		alert('�����ּҰ� ���������Դϴ�. �ٽ� �Է����ֽʽÿ�!');
		form.sender_email.value="";
		form.sender_email.focus();
		return;
	}  
	    

	if (form.sender_name.value == "" ) {
		alert("�̸��� �Է��Ͽ� �ֽʽÿ�");
		form.sender_name.focus();
		return ;
	}

	var flag = chk_number(form.phone1);
	if ( !flag ) return ;
	var flag = chk_number(form.phone2);
	if ( !flag ) return ;
	var flag = chk_number(form.phone3);
	if ( !flag ) return ;

	var flag = chk_number(form.fax1);
	if ( !flag ) return ;
	var flag = chk_number(form.fax2);
	if ( !flag ) return ;
	var flag = chk_number(form.fax3);
	if ( !flag ) return ;
	form.submit();

}

var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);
	
function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="../images/flash/menu_m.swf">
        <param name=quality value=high>
        <embed src="../images/flash/menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="145" height="523"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td colspan="2"><img src="images/title_2.gif" width="194" height="54"></td>
        </tr>
        <tr> 
          <td height="139" valign="top" width="49" background="images/title_2_back.gif" rowspan="2"><img src="images/title_2_back.gif" width="49" height="6"></td>
          <td height="50" width="551"><img src="images/2_1.gif" width="515" height="22"></td>
        </tr>
        <tr>
          <td height="70" width="551">
          	<!-- start form -->
          	<form name="form_email" action="send_ok.php" method="post">
            <table width="500" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> </td>
                <td rowspan="10" width="15" height="20"></td>
                <td width="360" height="20"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_name.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="sender_name" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="15" maxlength="12">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_add.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="sender_addr" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="55">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_com.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="sender_comp" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="55">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_tel.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="phone1" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                  - 
                  <input type="text" name="phone2" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                  -
                  <input type="text" name="phone3" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_fax.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="fax1" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                  - 
                  <input type="text" name="fax2" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                  - 
                  <input type="text" name="fax3" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="3">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_email.gif" width="78" height="21"></div>
                </td>
                <td width="360" height="30">
                  <input type="text" name="sender_email" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="55">
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="30"> 
                  <div align="right"><img src="images/2_st.gif" width="78" height="21"></div>
                </td>
                <td rowspan="2" height="150" width="360">
                  <textarea name="contents" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" cols="57" rows="10"></textarea>
                </td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="120"></td>
              </tr>
              <tr> 
                <td bgcolor="#E9E9E9" width="125" height="20"> 
                  <div align="right"></div>
                </td>
                <td width="360" height="20"></td>
              </tr>
            </table>            
            </form>
            <!-- end form -->
          </td>
        </tr>
        <tr> 
          <td height="1" valign="top" width="49"></td>
          <td height="1" width="551" bgcolor="#8E8E8E"></td>
        </tr>
        <tr> 
          <td height="40" valign="top" width="49"></td>
          <td height="60" width="551"> 
            <div align="center"><a href="javascript:send_mail()"><img src="images/bu_send.gif" width="67" height="28" border="0"></a><font color="#FFFFFF">......</font><img src="images/bu_can.gif" width="67" height="28"></div>
          </td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
