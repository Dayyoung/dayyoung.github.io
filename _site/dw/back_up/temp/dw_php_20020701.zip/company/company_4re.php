<html>
<head>
<title>(��) �������� ���Ű� ȯ���մϴ�. ::--------------------------------------------------</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">
</head>
<SCRIPT language=javascript>
<!-- //��� ����ٴϱ�
var isDOM = (document.getElementById ? true : false); 
var isIE4 = ((document.all && !isDOM) ? true : false);
var isNS4 = (document.layers ? true : false);

function getRef(id)
{
	if (isDOM) return document.getElementById(id);
	if (isIE4) return document.all[id];
	if (isNS4) return document.layers[id];
}

var isNS = navigator.appName == "Netscape";

function moveRightEdge()
{
	var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
	if (isNS4)
	{
		yMenuFrom   = divMenu.top;
		yMenuTo     = windows.pageYOffset + 100;   // ���� ��ġ
	}
	else if (isDOM)
	{
		yMenuFrom   = parseInt (divMenu.style.top, 0);
		yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop+123); // ������ ���̾���� ��ġ �̰� �ٲ��
	}

	timeoutNextCheck = 500;

	if (yMenuFrom != yMenuTo)
	{
		yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 20);
		if (yMenuTo < yMenuFrom)
			yOffset = -yOffset;
		if (isNS4)
			divMenu.top += yOffset;
		else if (isDOM)
			divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
			timeoutNextCheck = 10;
	}
	setTimeout ("moveRightEdge()", timeoutNextCheck);
}
--> 
</SCRIPT>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="146" valign="top" background="../images/top_back.gif"><a href="/"><img src="../images/top_logo.gif" width="146" height="84" border="0"></a></td>
    <td width="635" background="../images/top_back.gif" colspan="2"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="635" height="120">
        <param name=movie value="../images/flash/menu_m.swf">
        <param name=quality value=high>
        <embed src="../images/flash/menu_m.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="635" height="120">
        </embed> 
      </object></td>
    <td background="../images/top_back.gif" width="50%"></td>
  </tr>
  <tr>
    <td width="146" valign="top"><img src="images/main_image.gif" width="146" height="540"></td>
    <td background="../images/gra_back.gif" width="11" valign="top"><img src="../images/gra_back.gif" width="11" height="8"></td>
    <td height="60" valign="top"> 
      <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td rowspan="4" bgcolor="#8C8C8C" width="1"></td>
          <td><img src="images/title_4.gif" width="120" height="31"></td>
        </tr>
        <tr> 
          <td height="25"></td>
        </tr>
        <tr> 
          <td height="25"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="8%" height="25"> 
                  <div align="right"><img src="../images/point.gif" width="8" height="8"></div>
                </td>
                <td style="PADDING-LEFT: 10px" width="92%" height="25">��õ���ҽ� ��籸 
                  ����3�� 682-1</td>
              </tr>
              <tr> 
                <td width="8%" height="25"> 
                  <div align="right"><img src="../images/point.gif" width="8" height="8"></div>
                </td>
                <td style="PADDING-LEFT: 10px" width="92%" height="25">Tel : 032) 
                  542 - 2211/4, 543 - 4457/8</td>
              </tr>
              <tr> 
                <td width="8%" height="25"> 
                  <div align="right"><img src="../images/point.gif" width="8" height="8"></div>
                </td>
                <td style="PADDING-LEFT: 10px" width="92%" height="25">Fax : 032) 
                  545 - 7720</td>
              </tr>
              <tr> 
                <td width="8%" height="25"> 
                  <div align="right"><img src="../images/point.gif" width="8" height="8"></div>
                </td>
                <td style="PADDING-LEFT: 10px" width="92%" height="25">����/����ö 
                  - �������� �����̿����� ��ǳ��� �������� 582��(�� 2��) ��������Ʈ�տ��� ����</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td style="PADDING-LEFT: 50px" class="compa" height="375"><img src="images/map_image.gif" width="515" height="514"></td>
        </tr>
      </table>
    </td>
    <td rowspan="3" width="50%"> 
      <? include "../inc/banner.html"; ?>
    </td>
  </tr>
  <tr> 
    <td width="146"><img src="../images/side_bo.gif" width="146" height="12"></td>
    <td width="635" colspan="2"><img src="../images/side_bo_co.gif" width="18" height="12"></td>
  </tr>
  <tr> 
    <td width="146"></td>
    <td width="635" colspan="2" height="50"> 
      <div align="center"><img src="../images/copy_add.gif" width="313" height="47"></div>
    </td>
  </tr>
</table>
</body>
</html>
