<?php

  
 ## �ٷ�Ʈ
 Function jvAlert($alert_str, $add_commend=''){
  
  echo "<meta http-equiv='Content-Type' content='text/html; charset=euc-kr'>
  	<Script Language='JavaScript'>
  	alert(\"$alert_str\");
  	$add_commend;
  	</Script> \n";
 }
 
  if(empty($db)){
    jvAlert("������ �Է��� �ּ���.(../board/list.php?db=$db)", "history.go(-1);");
    exit;
  }

  /*if($FILE_UPLOAD != "Y") { 
    session_start();
    if (!(session_is_registered('SESSION_LOGIN') && $SESSION_LOGIN == md5($admin_pass))) {
   	 	$file_h_tag="<!-- ";
    	$file_e_tag="-->";
    }	
  }*/
  if($TABLE_WIDTH<=100) $TABLE_WIDTH="$TABLE_WIDTH%";

  $dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
  mysql_select_db($db_name, $dbconn) or die('��� ���� ����');
 
  
  ## ���Խù� �۹�ȣ ���ϱ�. 
  Function getThisId($db){
    
    global $dbconn;
    
    $qry1="select max(v_id) from $db";
    $rst1=mysql_query($qry1, $dbconn) or die('qry1:'.mysql_error());
    $v_id=mysql_result($rst1, 0,0);
    if($v_id) $v_id++; else $v_id=1;
    return($v_id);
  }
  
  
   Function getSafeSearchArgs(){
    global $dbconn, $db, $SEARCH, $scale, $this_page, $SAFE_SEARCH_MAX_ROWS, $s_start, $ef;
    
    if($this_page==1){
      $qry1="select max(v_id) from $db";
      $rst1=mysql_query($qry1, $dbconn);
      $max_v_id=mysql_result($rst1, 0, 0);
     }else{
              #### limit �� �������� - ��ü �������� ���� ������� �������� ���� fetch
      $total_rows=$SEARCH[COUNT];
      $total_page=ceil($total_rows/$scale);
      if(ceil($total_page/2) > $this_page) $ef="for";
        else $ef="rev";
    }
     
      if($ef=="rev"){	// �տ��� ���� �˻�
        $range="where v_id>$s_start-$SAFE_SEARCH_MAX_ROWS and v_id <=$s_start";
       }else{		// �ֱ� �Խù����� �˻�
        if(!$s_start) $s_start=$max_v_id;
        $t_start=-$s_start;
        $range="where m_v_id >= $t_start and m_v_id < $t_start + $SAFE_SEARCH_MAX_ROWS";
      }
    return $range;
  } 
  


 
 
 
 ## ���ڿ� �ڸ���
 Function shortLongString($str, $lenth, $dot=''){
   
   if(strlen($str) <= $lenth){
     return $str;
    }else{
     $k=0;
     for($i=0; $i<$lenth*2; $i++){
     
       if(ord(substr($str,$i,1))>127){		## �ѱ�����
        $i++;
         $k++;
        }else{
         $k++;
       }
       if($k>=$lenth)
         break;
     }
    if($dot=="NoDot")
       return substr($str, 0,$i+1);
     else 
      return substr($str, 0,$i+1)." ...";
   }
 }
 
 
 ## Ȩ������ üũ
 
 Function checkUrl($url){
    if (!eregi("[a-zA-Z0-9\-\.]+\.[a-zA-Z0-9\-\.]+.*", $url)) {
	return;
    }
    /* �ѱ��� ���ԵǾ����� üũ */
    for($i = 1; $i <= strlen($url); $i++) {
	if ((Ord(substr("$url", $i - 1, $i)) & 0x80)) {
	    return;
	}
    }
    $url = eregi_replace("^http.*://", "", $url);
    $url = eregi_replace("^", "http://", $url);

    return $url;
 }
  
 
 ## ���Ͼ��ε�
 
 Function uploadFile(){
   
   global $ATTACH_FILE_MAX_SIZE, $ATTACH_FILE_DIR, $attach_file, $attach_file_name, $attach_file_size;
      
     $save_file_name=$attach_file_name.".".date("YmdHis");
     $attc[size]=$attach_file_size;		//byte 
     $attc[name]=$save_file_name;		// ����Ǵ� ���� �̸�
     $attc[real_name]=$attach_file_name;	// ���ε�� ���ϳ���
     if($attc[size]>$ATTACH_FILE_MAX_SIZE*1024){
       jvAlert("���Ͼ��ε�� ".round($ATTACH_FILE_MAX_SIZE/1024, 2)."M �����Դϴ�.",'history.go(-1);');
       exit;
     }
     jvAlert($ATTACH_FILE_DIR,'');
     if(!is_dir($ATTACH_FILE_DIR)){	// ���� ������丮�� �������� ������
       mkdir($ATTACH_FILE_DIR,0755);
     }
 
      move_uploaded_file($attach_file, "$ATTACH_FILE_DIR/$save_file_name");
     return $attc;
 }  
  
 
 ## ���� ���� ������
 
 Function getPreNext($rst, $id, $v_id){
 
   global $dbconn, $db, $mode, $key, $value, $SEARCH, $SAFE_SEARCH_MAX_ROWS;
   
   $flag=false;
        
   if($mode=='search'){

     if($SEARCH[COUNT]==1) return ;	// �˻� ����� �ϳ��� ��� ���� ���� ����.
     
     $t_value=ereg_replace("_","\_", $value);
     $t_value=ereg_replace("%","\%", $t_value);
     $arr_value=split(" ",$t_value);
   
     for($i=0; $i<count($arr_value); $i++){
       if($i==0){
          if($key=="name" ||$key=="email") $where_str="and ($key like '$arr_value[$i]%'";
           else $where_str="and ($key like '%$arr_value[$i]%'";
        }else{ $where_str.=" or $key like '%$arr_value[$i]%'"; }
    
     }
     $where_str.=")";
   }
   
   while($row=mysql_fetch_array($rst)){
       if($row[id]==$id){		// ������� ���ĸ� ���� �����۷� ...
         $go[prev]=$prev;
         $flag=true;
        }else if($flag){
         $go[next]=$row[id];
         break;
       }
       $prev=$row[id];

   }
   if(!$go[prev] || !isset($go[prev])){
     $qry1="select id from $db where v_id>$v_id $where_str  and v_id<$v_id+$SAFE_SEARCH_MAX_ROWS order by v_id asc, r_id asc limit 1";
     $rst1=mysql_query($qry1, $dbconn);
     $go[prev]=@mysql_result($rst1, 0, 0);
   }



   if(!$go[next] || !isset($go[next])){
        $qry2="select id from $db where m_v_id>-$v_id $where_str and m_v_id<-$v_id+$SAFE_SEARCH_MAX_ROWS order by m_v_id asc, m_r_id asc limit 1";
        $rst2=mysql_query($qry2, $dbconn);
        $go[next]=@mysql_result($rst2, 0, 0);
   }
   
   return $go;
   
} 


// �������� �������� ...
 Function getNextId($nid){
     global $dbconn, $db, $mode, $key, $value;
       if($nid<1) return false;
       $qry1="select id from $db where v_id=$nid and r_id=0";
       $rst1=mysql_query($qry1, $dbconn);
       $id=@mysql_result($rst1, 0, 0);
       if($id) return $id;
         else return getNextId(--$nid);
 }
 
 
 ## ����Ʈ ���
 
 Function printList($row1,$c_dir, $id=0){ 
   
   global $dbconn, $BOARD_COMMENT, $key, $value, $mode,$quick_mode, $this_page, $db, $s_start, $cookie_email,$TITLE_LENGTH, $NAME_LENGTH, $SKIN;
   
      
   $title=shortLongString($row1[title],$TITLE_LENGTH-$row1[depth]); 
   $title=str_replace('"', "&quot;", str_replace("'","&#039;",$title));
   
   if($id==$row1[id]) $title="<b>$title</b>";
   $name=shortLongString($row1[name],$NAME_LENGTH,'NoDot');
   $depth=$row1[depth]*10;
   if($depth==0) $top_id=$row1[v_id];
     else $top_id="";
     
   if($row1[attach_file_size]!=0)
     $file="<a href='$c_dir"."download.php?db=$db&id=$row1[id]&file_name=$row1[attach_file_name]&real_file_name=$row1[real_attach_file_name]'><img src='$c_dir"."/skin/$SKIN/img/check.gif' border='0'></a>";
    else
     $file="<img src='$c_dir"."skin/$SKIN/img/dot.gif' width='24' border='0'>";
    
   $qry1="select count(*) from  $BOARD_COMMENT where t_table='$db' and t_id='{$row1[id]}'";
   $rst1=mysql_query($qry1, $dbconn);
   $comment_cnt=mysql_result($rst1, 0, 0);	//�޸𰹼�
   if($comment_cnt) $comment_str="<font size='1'> [$comment_cnt]</font>";
     else $comment_str="";
/*   if($row1[date]==date("Y.m.d")) $new="<img src='$c_dir"."img2/new.gif' width='36' height='19' border='0'>";
     else $new="<img src='$c_dir"."img2/nothing.gif' width='36' height='19' border='0'>";
*/
    include("./skin/$SKIN/html/list_tr.html");
 
 }
  
  ## ������ ��� 
 Function printPage(){
  global $total_page, $scale, $key, $value, $mode, $this_page, $PHP_SELF, $db, $ef, $s_start, $continue_search,$quick_mode, $new_start;
    
    $url_value=urlencode($value);
    
    $rt_str="<a href='$PHP_SELF?db=$db&key=$key&value=$url_value&mode=$mode&this_page=1&quick_mode=$quick_mode'>&lt;&lt;Pre&nbsp;</a>\n";
    
      if($quick_mode=="Y"){
          $ii=-10;
          $total_page=$this_page; 
        }else {$ii=-4;}
  
      for($i = $ii; $i <= 4; $i++) {
	  if($i){
	      $tmp = $this_page + $i;
	      if($tmp >= 1 && $tmp <= $total_page) {
          	$rt_str.="<a href=$PHP_SELF?db=$db&key=$key&value=$url_value&mode=$mode&this_page=$tmp&s_start=$s_start&quick_mode=$quick_mode>[$tmp]</a>\n";
	      }
	  } else {
	      $rt_str.="<b>$this_page</b>\n";
	      if($quick_mode=="Y" && !$continue_search && $new_start>0){
	          $n_page=$this_page+1;
	          $rt_str.="<a href=$PHP_SELF?db=$db&key=$key&value=$url_value&mode=$mode&this_page=$n_page&s_start=$s_start&quick_mode=$quick_mode>����������[$n_page]</a>  \n";
	          break;
	      }  
	      
	  }
      }
  
  
     if($continue_search && $new_start>0) $rt_str.=$continue_search;	// ���� xxx �ǿ��� �˻�
       else if($quick_mode !="Y") $rt_str.="<a href=$PHP_SELF?db=$db&key=$key&value=$url_value&mode=$mode&this_page=$total_page&s_start=$s_start&quick_mode=$quick_mode>&nbsp;Next&gt;&gt;</a>  \n";
    
    
  return $rt_str;   
     
 } 

#### ������ ���ؽ� ����
Function insertTitleIndex($table, $title){
  global $dbconn;
  
  $arr_trim=getTitleTrimmed($title);	// �����ܾ� �ߺ�����.

  for($i=0; $i<count($arr_trim); $i++){
    $word=$arr_trim[$i];
    $qry1="update {$table}_index set count=count+1 where word='$word'";	// �ܾ �ε����� ����
    mysql_query($qry1, $dbconn);
    if(!mysql_affected_rows($dbconn)){					// �ε����� �������� ������ �߰�
      $qry2="insert into {$table}_index(word,count) values('$word','1')";
      mysql_query($qry2, $dbconn);
    }
  }
  
}

### ������ �ε��� ����
Function deleteTitleIndex($table, $title){
  global $dbconn;
  
  $arr_trim=getTitleTrimmed($title);	// �����ܾ� �ߺ�����.

  for($i=0; $i<count($arr_trim); $i++){
    $word=$arr_trim[$i];
    $qry1="update {$table}_index set count=count-1 where word='$word'";	// �ε����� ����
    mysql_query($qry1, $dbconn);

  }
  
}

## �ε����� �ɱ����� ������ ���� ����. -- ������ ���� �� �״�� �ִ´�. -- ���߿� ���׷��̵�� ����� ���� �����Ƿ�..  
Function getTitleTrimmed($title){	
  $title=trim($title);
  $title=ereg_replace("[.,:;]", "", $title);
  $arr_title=split(" ",$title);

  $arr_trim=array(); // ������ ������

 // �����ܾ� ����.
  for($h=0; $h<count($arr_title); $h++){
    //if(in_array($arr_title[$h], $arr_trim)){
    if($arr_title[$h] == $arr_trim){
      continue;
     }else{
      $arr_trim[]=$arr_title[$h];
    } 
  }  
  return $arr_trim;

}

register_shutdown_function(noticeShutDown);

Function noticeShutDown(){
  global $dbconn;
  if(connection_aborted()) 
  mysql_close($dbconn);
  exit;
} 
?>