<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="637">
    <tr>
        <td width="175" height="637" rowspan="5">
            <table width="175" height="538" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="165" height="10">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>�� ǰ ��&nbsp;��</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="10">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="lldpe.php" target="_self"><b>LLDPE Film</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="pouch.php" target="_self"><b>Pouch &amp; Roll ��ǰ</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165">&nbsp;</td>
                </tr>
                <tr>
                    <td width="165" height="372">
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="55" rowspan="5" bgcolor="white" height="637">&nbsp;</td>
        <td width="680" height="15" colspan="2">&nbsp;</td>
        <td width="50" height="637" rowspan="5">&nbsp;</td>
    </tr>
    <tr>
        <td width="680" height="50" colspan="2">
            <p align="center"><b><font size="4">�� ǰ&nbsp;�� ��&nbsp;:&nbsp;LLDPE FILM</font></b></p>
        </td>
    </tr>
    <tr>
        <td width="680" height="21" colspan="2">            <hr>
</td>
    </tr>
    <tr>
        <td width="270" height="122">
            <p align="center"><img src="img/LLDPE_Film.gif" border="0" width="204" height="132"></p>
        </td>
        <td width="410" height="122">
            <p><font size="3"><b>��</b></font><b><font size="3"> LLDPE Film ( 3�� Film </font></b><font size="3"><b>�� 5</b></font><b><font size="3">�� Film )</font></b></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��ȭ����ȭ�� ��� ����� LLDPE�� ����� �پ��� ������</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ũ���� LLDPE������ ��ü ���� ��� �� �Ǹ�</font></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>�� </b></font><b><font size="3">���� LLDPE Film</font></b></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>��</b></font><b><font size="3"> EPE(����) Film</font></b></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>��</b></font><b><font size="3"> MT(��Ż�μ�) Film</font></b></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>��</b></font><b><font size="3"> Easy peel&nbsp;Film</font></b></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>��</b></font><b><font size="3"> EVOH&nbsp;Film</font></b></p>
            <p>&nbsp;</p>
            <p><font size="3"><b>��</b></font><b><font size="3"> EVA&nbsp;Film</font></b></p>
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td width="680" height="8" colspan="2">
            <p>&nbsp;</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="16">
    <tr>
        <td width="960" height="16">
            <p align="center"><?include("../public/bottom.inc")?>
        </td>
    </tr>
</table>
</body>

</html>