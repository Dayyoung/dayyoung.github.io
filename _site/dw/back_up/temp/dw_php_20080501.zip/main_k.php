<?php
	include("inc/common.inc.php");
	include("inc/db.inc.php");  

	$dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
	mysql_select_db($db_name, $dbconn) or die('��� ���� ����');
  
	$qry="select count(*) from tblNews " ;                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$total_rows=mysql_result($rst, 0 ,0);
	$start_rows=ceil($total_rows - 2 );  
	if ($start_rows < 0 ) {
		$start_rows = 0;
	}
	$qry="select *, date_format(reg_date, '%Y.%m.%d') as reg_date  from tblNews LIMIT $start_rows,$total_rows" ;
	                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$count_row = @mysql_num_rows($rst);
 
	
?>



<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.          </title>
<meta name="generator" content="Namo WebEditor">
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="images/Bg_Pint.GIF" bgproperties="fixed">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("public/menu.inc")?>
</p>
        </td>
    </tr>
</table>
<table border="0" width="960" align="center" bgcolor="white">
    <tr>
        <td width="362" rowspan="2" background="images/main_img/product_pack.jpg">
            <p>&nbsp;</p>
        </td>
        <td width="588">
            <p>&nbsp;</p>
            <table border="1" width="578" align="center" height="190" bgcolor="lime">
                <tr>
                    <td width="568" height="184">
                        <table border="0" width="569" align="center" bgcolor="white">
                            <tr>
                                <td width="2">&nbsp;</td>
                                <td width="555">
                                    <table cellpadding="0" cellspacing="0" width="555" height="177" align="center" bgcolor="white">
                                        <tr>
                                            <td width="95" height="88">
                                                <p align="center">&nbsp;</p>
                                            </td>
                                            <td width="460" height="88">
                                                <p><font size="2">&nbsp;�������ֽ�ȸ��� 1971�� ���� ���� ��ǰ�� �� ����ȭ�� ��ǰ���� </font></p>
                                                <p><font size="2">���������� ���� &nbsp;�������� �̷��� �������&nbsp;������ ����Դϴ�.</font></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="95" height="71">
                                                <p align="center"><a href="http://www.daewon-ind.co.kr/board/list.php?db=tblNews" target="_self"><img src="images/main_img/news_title.gif" width="95" height="66" border="0"></a></p>
                                            </td>
                                            <td width="460" height="71">
                                                <table width="62%" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td rowspan="2" valign="top" width="1">
                                                            <div align="center">
                                                                <p>&nbsp;</p>
                                                            </div>
                                                        </td>
                                                        <td width="308" class="compa" height="35">
                  &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td width="308">
                                                            <table width="309" border="0" cellspacing="0" cellpadding="0" align="center">
                                                                <tr>
                                                                    <td colspan="3" width="309"><img src="images/main_img/point_line.gif" width="454" height="1"></td>
                                                                </tr>
                                                                <?
	if($count_row!=0){
		for($i=$count_row-1; $i>=0; $i--){
			mysql_data_seek($rst, $i);
			$row=mysql_fetch_array($rst);
		#while($row = mysql_fetch_array($rst)) {
			echo("                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='images/main_img/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td width='325'><a href='board/read.php?db=tblNews&id=$row[id]' target='_self'>$row[title]</a></td>
                      <td width='100'> 
                        <div align='right'>[ $row[reg_date] ]</div>
                      </td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='img/point_line.gif' width='454' height='1'></td>
                    </tr>
	    	
			");
		
		}	//while�� �ݱ�    
	}	//if�� �ݱ�
	else{
		echo("	
                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='img/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td colspan='2' width='325'><div align='center'>�ڷᰡ �����ϴ�.</div></td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='img/point_line.gif' width='454' height='1'></td>
                    </tr>

		");
	}        		

?>
                                                                <tr>
                                                                    <td colspan="3" width="309"><img src="img/point_line.gif" width="454" height="1"></td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="555" height="18" colspan="2">
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="-2">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td width="588" height="232">
            <p>&nbsp;</p>

            <table border="1" width="576" align="center" bgcolor="lime" height="50">
                <tr>
                    <td width="137" height="44">
                        <p align="center"><img src="images/main_img/img1.gif" border="0" width="134" height="106"></p>
                    </td>
                    <td width="137" height="44">
                        <p align="center"><img src="images/main_img/img2.gif" border="0" width="134" height="106"></p>
                    </td>
                    <td width="137" height="44">
                        <p align="center"><img src="images/main_img/img3.gif" border="0" width="134" height="106"></p>
                    </td>
                    <td width="137" height="44">
                        <p align="center"><img src="images/main_img/img4.gif" border="0" width="134" height="106"></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="15">
    <tr>
        <td width="960" height="15">
            <p align="center"><?include("public/bottom.inc")?></p>
        </td>
    </tr>
</table>
</body>

</html>