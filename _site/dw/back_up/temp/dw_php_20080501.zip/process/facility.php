<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="279">
    <tr>
        <td width="175" height="279" rowspan="3">
            <table width="175" cellpadding="0" cellspacing="0" height="531">
                <tr>
                    <td width="165">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>�� �� �� ��</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="progress.php" target="_self"><b>����������</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="extrusion.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="printing.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="lamination.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="hardening.php" target="_self"><b>�� ȭ �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="slit.php" target="_self"><b>����Ÿ �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="pouch.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="facility.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="1">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="75">
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="55" rowspan="3" bgcolor="white" height="279">&nbsp;</td>
        <td width="340" height="15">&nbsp;</td>
        <td width="340" height="15">&nbsp;</td>
        <td width="50" height="279" rowspan="3">&nbsp;</td>
    </tr>
    <tr>
        <td width="680" colspan="2" height="243">
            <p align="center"><img src="img/mak1_eq.gif" border="0"></p>
            <p align="center"><img src="img/mak2_eq.gif" border="0"></p>
            <p align="center"><img src="img/mak3_eq.gif" border="0"></p>
            <p align="center"><img src="img/mak4_eq.gif" border="0"></p>
            <p align="center"><img src="img/makS_eq.gif" border="0"></p>
        </td>
    </tr>
    <tr>
        <td width="340" height="8">&nbsp;</td>
        <td width="340" height="8">&nbsp;</td>
    </tr>
</table>

<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="16">
    <tr>
        <td width="960" height="16">
            <p align="center"><?include("../public/bottom.inc")?>
        </td>
    </tr>
</table>
</body>

</html>