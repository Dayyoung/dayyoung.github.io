<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu_e.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="961">
    <tr>
        <td width="175" height="961" rowspan="7">
            <table width="175" cellpadding="0" cellspacing="0" height="167">
                <tr>
                    <td width="165" height="15">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>Manufacturing Process</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="7">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_extrusion.php" target="_self"><b>Extrusion Film</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_printing.php" target="_self"><b>Printing</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_lamination.php" target="_self"><b>T-Die &amp; Dry Lamination</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_slit.php" target="_self"><b>Slitter</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_pouch.php" target="_self"><b>Automatic Bag</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="../process/e_Equipment.php" target="_self"><b>Equipment</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="1">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="8">
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="49" rowspan="7" bgcolor="white" height="961">&nbsp;</td>
        <td width="687" height="4" colspan="2">&nbsp;</td>
        <td width="49" height="961" rowspan="7">&nbsp;</td>
    </tr>
    <tr>
        <td width="687" height="50" colspan="2">
            <p align="center"><font size="4"><b>Manufacturing Process</b></font><b><font size="4"> : Extrusion Film</font></b></p>
        </td>
    </tr>
    <tr>
        <td width="687" height="4" colspan="2">            <hr>
</td>
    </tr>
    <tr>
        <td width="270" height="4">
            <p align="center"><img src="img/extrusion_1.jpg" width="200" height="219" border="0"></p>
        </td>
        <td width="417" height="4">
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;When putting the resin to the hopper, it moves&nbsp;forwardby</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; the screw and is heated and melted. When&nbsp;the air isblown</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; to the&nbsp;resin that is melted and &nbsp;pushed, the film oftube</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; type is&nbsp;produced. This&nbsp;process cuts the bothsides of the</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; film of tube type&nbsp;to make it flat, winds it inthe roll type</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; and produces&nbsp;the&nbsp;biaxial orientation film. </font></p>
        </td>
    </tr>
    <tr>
        <td width="687" height="4" colspan="2">
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td width="687" colspan="2" height="243">
            <table border="1" width="687">
                <tr>
                    <td width="335">
                        <p align="center"><img src="img/extrusion_3.jpg" width="300" height="300" border="0"></p>
                    </td>
                    <td width="335">
                        <p align="center"><img src="img/extrusion_1.JPG" width="300" height="300" border="0"></p>
                    </td>
                </tr>
                <tr>
                    <td width="335">
                        <p align="center"><img src="img/extrusion_2.jpg" width="300" height="300" border="0"></p>
                    </td>
                    <td width="335">
                        <p align="center"><img src="img/extrusion_4.jpg" width="300" height="300" border="0"></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="270" height="9">
            <p>&nbsp;</p>
        </td>
        <td width="417" height="9">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="13">
    <tr>
        <td width="960" height="13">
            <p align="center"><?include("../public/bottom_e.inc")?>
        </td>
    </tr>
</table>
</body>

</html>