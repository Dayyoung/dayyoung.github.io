<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu_e.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="754">
    <tr>
        <td width="175" height="754" rowspan="3">
            <table width="175" cellpadding="0" cellspacing="0" height="167">
                <tr>
                    <td width="165" height="15">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>Manufacturing Process</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="7">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_extrusion.php" target="_self"><b>Extrusion Film</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_printing.php" target="_self"><b>Printing</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_lamination.php" target="_self"><b>T-Die &amp; Dry Lamination</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_slit.php" target="_self"><b>Slitter</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_pouch.php" target="_self"><b>Automatic Bag</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_Equipment.php" target="_self"><b>Equipment</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="1">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="8">
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="50" rowspan="3" bgcolor="white" height="754">&nbsp;</td>
        <td width="345" height="14">&nbsp;</td>
        <td width="340" height="14">&nbsp;</td>
        <td width="50" height="754" rowspan="3">&nbsp;</td>
    </tr>
    <tr>
        <td width="685" colspan="2" height="726">
            <table width="674" height="44" border="3" bordercolor="#666666" bordercolorlight="#CCCCCC" bordercolordark="#666666" frame="box" align="center">
                <tr align="center">
                    <td width="660" height="34" valign="middle">
                        <p><font size="4"><b>��</b></font><b><font size="4"> &nbsp;&nbsp;Equipment state &nbsp;</font></b><font size="4"><b>&nbsp;��</b></font></p>
                    </td>
                </tr>
            </table>
            <table width="674" height="677" border="3" bordercolor="#666666" bordercolorlight="#CCCCCC" bordercolordark="#666666" frame="box" align="center">
                <tr align="center">
                    <td width="100" height="33">
                        <p><font size="2"><b>Section</b></font></p>
                    </td>
                    <td width="253" height="33">
                        <p align="left"><font size="2"><b>&nbsp;Spec.</b></font></p>
                    </td>
                    <td width="35" height="33">
                        <p><b>Q'ty.</b></p>
                    </td>
                    <td width="254" height="33">
                        <p align="left"><b>&nbsp;&nbsp;Ref.</b></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="8" colspan="4" bgcolor="#CCCCCC">&nbsp;</td>
                </tr>
                <tr align="center">
                    <td width="100" height="73" rowspan="4"><font size="2">Extrusion film</font><font size="2"></font></td>
                    <td width="253" height="58" rowspan="3">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;3-Layer Co-Extrusion Film &nbsp;M/C</font></P>
                    </td>
                    <td width="35" height="13"><font size="2">1</font></td>
                    <td width="254" height="13">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,800(��), &nbsp;&nbsp;300(��/h)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="35" height="10"><font size="2">1</font></td>
                    <td width="254" height="10">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 2,400(��), &nbsp;&nbsp;400(��/h)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="35" height="14"><font size="2">1</font></td>
                    <td width="254" height="14">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 2,800(��), &nbsp;&nbsp;600(��/h)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="9">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;5-Layer Co-Extrusion Film &nbsp;M/C</font></P>
                    </td>
                    <td width="35" height="9"><font size="2">1</font></td>
                    <td width="254" height="9">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,800(��), &nbsp;&nbsp;300(��/h)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="14" colspan="4" bgcolor="#CCCCCC">&nbsp;</td>
                </tr>
                <tr align="center">
                    <td width="100" height="74" rowspan="3"><font size="2">Printing</font></td>
                    <td width="253" height="24">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Gravure Printing M/C 8&nbsp;Colors</font></P>
                    </td>
                    <td width="35" height="24"><font size="2">1</font></td>
                    <td width="254" height="24">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,150(��),&nbsp;&nbsp; 250(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="6">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Gravure Printing M/C 9&nbsp;Colors</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">1</font></td>
                    <td width="254" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,250(��),&nbsp;&nbsp; 280(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="6">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Gravure Printing M/C 10&nbsp;Colors</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">1</font></td>
                    <td width="254" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,420(��),&nbsp;&nbsp; 350(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="1" colspan="4" bgcolor="#CCCCCC">
                        <p>&nbsp;</p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="100" height="2">
                        <p><font size="2">Extrusion Lamination</font></p>
                    </td>
                    <td width="253" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Extrusion Lamination Coating &nbsp;M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">2</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;wide : 1,300(��)</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="2" colspan="4" bgcolor="#CCCCCC">&nbsp;</td>
                </tr>
                <tr align="center">
                    <td width="100" height="74" rowspan="3">
                        <p><font size="2">Dry &nbsp;Lamination </font></p>
                    </td>
                    <td width="253" height="24">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Solvent&nbsp;Free Dry-Lamination &nbsp;M/C</font></P>
                    </td>
                    <td width="35" height="24"><font size="2">1</font></td>
                    <td width="254" height="24">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,240(��),&nbsp;&nbsp; 300(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="42" rowspan="2">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Dry-Lamination M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">1</font></td>
                    <td width="254" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,240(��),&nbsp;&nbsp; 200(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="35" height="22"><font size="2">2</font></td>
                    <td width="254" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Wide : 1,420(��),&nbsp;&nbsp; 300(m/min)</font></P>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="2" colspan="4" bgcolor="#CCCCCC">&nbsp;</td>
                </tr>
                <tr align="center">
                    <td width="100" height="2"><font size="2">Slitting</font></td>
                    <td width="253" height="22">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Slitting M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">6</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="660" height="2" colspan="4" bgcolor="#CCCCCC">&nbsp;</td>
                </tr>
                <tr align="center">
                    <td width="100" height="195" rowspan="6"><font size="2">Pouching</font></td>
                    <td width="253" height="24">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;3Side Sealing M/C</font></P>
                    </td>
                    <td width="35" height="24"><font size="2">6</font></td>
                    <td width="254" height="24">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="2">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Zipper &amp; Standing Pouch M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">3</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="2">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Center Press Sealed Pouch M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">3</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="2">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Standing Pouch M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">2</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="2">
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Zipper &amp; 2Side Sealing Stand-UP</font></P>
                        <P CLASS=HStyle0 align="left"><font size="2">&nbsp;Pouch M/C</font></P>
                    </td>
                    <td width="35" height="22"><font size="2">1</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
                <tr align="center">
                    <td width="253" height="2">
                        <p align="left"><font size="2">&nbsp;Cap Punching M/C</font></p>
                    </td>
                    <td width="35" height="22"><font size="2">4</font></td>
                    <td width="254" height="22">
                        <p align="left"><font size="2">&nbsp;</font></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="345" height="8">
            <p>&nbsp;</p>
        </td>
        <td width="340" height="8">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="13">
    <tr>
        <td width="960" height="13">
            <p align="center"><?include("../public/bottom_e.inc")?>
        </td>
    </tr>
</table>
</body>

</html>