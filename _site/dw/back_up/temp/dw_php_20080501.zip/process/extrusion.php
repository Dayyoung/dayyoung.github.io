<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="1001">
    <tr>
        <td width="175" height="1001" rowspan="6">
            <table width="175" cellpadding="0" cellspacing="0" height="453">
                <tr>
                    <td width="165" height="8">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>�� �� �� ��</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="9">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="progress.php" target="_self"><b>����������</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="extrusion.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="printing.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="lamination.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="hardening.php" target="_self"><b>�� ȭ �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="slit.php" target="_self"><b>����Ÿ �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="pouch.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="facility.php" target="_self"><b>�� �� �� ��</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="1">
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="54" rowspan="6" bgcolor="white" height="1001">&nbsp;</td>
        <td width="270" height="15">&nbsp;</td>
        <td width="412" height="15">&nbsp;</td>
        <td width="49" height="1001" rowspan="6">&nbsp;</td>
    </tr>
    <tr>
        <td width="682" colspan="2" height="50">
            <p align="center"><b><font size="4">�� �� �� ��&nbsp;:&nbsp;�� �� �� �� ( LLDPE Film ������� )</font></b></p>
        </td>
    </tr>
    <tr>
        <td width="270" height="222">
            <p align="center"><img src="img/extrusion_5.jpg" width="220" height="223" border="0"></p>
        </td>
        <td width="412" height="222">
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����(Resin)�� ȣ��(Hopper)�� ������ ��ũ��(Screw)��</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����&nbsp;������ �����Ǹ�, �������� �ȴ�.</font></p>
            <p> <font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�̶� �����Ǿ� �з������� ������ ����(Air)�� �Ҿ� ������</font></p>
            <p> <font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ʃ��&nbsp;(Tube)������ �ʸ��� ����Ǹ�, �� Ʃ������ �ʸ�</font></p>
            <p> <font size="2">&nbsp;&nbsp;&nbsp;&nbsp; ���� ���̵�&nbsp;(Side)�� �߶󳻾�&nbsp;���� ������� ����� ��</font></p>
            <p> <font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Roll)���·� ���� ���� ���� �ʸ��� �����ϴ� ����</font></p>
        </td>
    </tr>
    <tr>
        <td width="682" height="44" colspan="2">
            <hr>
        </td>
    </tr>
    <tr>
        <td width="682" height="62" colspan="2">
            <table border="1" width="680">
                <tr>
                    <td width="332">
                        <p align="center"><img src="img/extrusion_3.jpg" width="300" height="300" border="0"></p>
                    </td>
                    <td width="332">
                        <p align="center"><img src="img/extrusion_1.JPG" width="300" height="300" border="0"></p>
                    </td>
                </tr>
                <tr>
                    <td width="332">
                        <p align="center"><img src="img/extrusion_2.jpg" width="300" height="300" border="0"></p>
                    </td>
                    <td width="332">
                        <p align="center"><img src="img/extrusion_4.jpg" width="300" height="300" border="0"></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="682" height="1" colspan="2">
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </td>
    </tr>
</table>

<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="16">
    <tr>
        <td width="960" height="16">
            <p align="center"><?include("../public/bottom.inc")?>
        </td>
    </tr>
</table>
</body>

</html>