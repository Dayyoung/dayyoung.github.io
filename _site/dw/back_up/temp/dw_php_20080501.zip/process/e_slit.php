<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.</title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu_e.inc")?>
</p>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="350">
    <tr>
        <td width="175" height="350" rowspan="5">
            <table width="175" cellpadding="0" cellspacing="0" height="167">
                <tr>
                    <td width="165" height="15">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center"><font size="3"><b>Manufacturing Process</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="7">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_extrusion.php" target="_self"><b>Extrusion Film</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_printing.php" target="_self"><b>Printing</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_lamination.php" target="_self"><b>T-Die &amp; Dry Lamination</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_slit.php" target="_self"><b>Slitter</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_pouch.php" target="_self"><b>Automatic Bag</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="35">
                        <p align="center">&nbsp;</p>
                        <p align="center"><font size="2" color="blue"><a href="e_Equipment.php" target="_self"><b>Equipment</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="1">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td width="165" height="8">
                        <p align="center">&nbsp;</p>
                    </td>
                </tr>
            </table>
        </td>
		
        <td width="49" rowspan="5" bgcolor="white" height="350">&nbsp;</td>
        <td width="687" height="11" colspan="2">&nbsp;</td>
        <td width="49" height="350" rowspan="5">&nbsp;</td>
    </tr>
    <tr>
        <td width="687" height="47" colspan="2">
            <p align="center"><font size="4"><b>Manufacturing Process&nbsp;: Slitter Section</b></font></p>
        </td>
    </tr>
    <tr>
        <td width="687" height="50" colspan="2">            <hr>
</td>
    </tr>
    <tr>
        <td width="270" height="176">
            <p align="center"><img src="img/slit_1.jpg" width="200" height="145" border="0"></p>
        </td>
        <td width="417" height="176">
            <p><font size="3"><b>��</b></font><b><font size="3"> Slitter Process</font></b><font size="3"><br>
                        </font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This process cuts the textile vertically by the&nbsp;size&nbsp;and</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the form so that it can be suitable for the&nbsp;requirements</font></p>
            <p><font size="2">&nbsp;&nbsp;&nbsp;&nbsp; of&nbsp;customers or post-process work.</font></p>
        </td>
    </tr>
    <tr>
        <td width="270" height="8">
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </td>
        <td width="417" height="8">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="13">
    <tr>
        <td width="960" height="13">
            <p align="center"><?include("../public/bottom_e.inc")?>
        </td>
    </tr>
</table>
</body>

</html>