<html>
<head>

<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ ��㹮�� ]          </title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="global.css">

<script language="JavaScript" src="global.js"></script>

<script language="JavaScript">
<!--
function send_check() {
	var form = document.mail;
	
	if(!form.sender.value){
		alert('������ ��� �̸��� �Է����� �ʾҽ��ϴ�.');
		form.sender.focus();
		return;
	}

	if(!form.sender_email.value){
		alert('������ ��� �̸����� �Է����� �ʾҽ��ϴ�.');
		form.sender_email.focus();
		return;
	}

	if(!form.subject.value){
		alert('���� ������ �Է����� �ʾҽ��ϴ�.');
		form.subject.focus();
		return;
	}

	if(!form.contents.value){
		alert('�߼� ������ �Է����� �ʾҽ��ϴ�.');
		form.contents.focus();
		return;
	}
	form.submit();
}
//-->
</script>
</head>



<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_green.GIF" bgproperties="fixed">
<form method='post' name='mail' action='mail_form_send.php' enctype="multipart/form-data">
<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/menu.inc")?></p>
        </td>
    </tr>
</table>
    <table border="0" width="966" align="center" bgcolor="white">
        <tr>
            <td width="960">
                <table border="0" width="950" align="center">
                    <tr>
                        <td width="100">&nbsp;</td>
                        <td width="736">
                            <p align="center">&nbsp;</p>
                            <p align="center"><font size="4"><b>�� </b></font><b><font size="4">&nbsp;�� &nbsp;&nbsp;�� &nbsp;&nbsp;�� &nbsp;&nbsp;�� &nbsp;</font></b>��</p>
                            <p align="center">&nbsp;</p>
                        </td>
                        <td width="100">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="100">&nbsp;</td>
                        <td width="736">
                            <table width="98%" border="1" cellspacing="0" cellpadding="3" bordercolordark="#FFFFFF" align="center">
                                <tr>
                                    <td align=center width="718">
                                        <table width="102%" border="0" cellspacing="0" cellpadding="0" height="102%" align="center">
                                            <tr>
                                                <td width="728" height="272">
                                                    <table width="94%" border="0" cellspacing="1" cellpadding="4" height="385" align="center">
                                                        <tr>
                                                            <td bgcolor="#ebe9f5" width="88"  align="center" height="18">
                                                                <p align="center"><span style="font-size:11pt;">������ ���</span></p>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" width="554"  align="left" height="18">
		 <input type='text' size="34" name="sender">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td bgcolor="#ebe9f5" width="88"  align="center" height="8">
                                                                <p align="center"><span style="font-size:11pt;">E - m a i l</span></p>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" width="554"  align="left" height="8">
		 <input type='text' size="79" name="sender_email">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td bgcolor="#ebe9f5" width="88"  align="center" height="33">
                                                                <p align="center"><span style="font-size:11pt;">÷ �� �� ��</span></p>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" width="554"  align="left" height="33">
		   <input type='file' size="65" name="userfile">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td bgcolor="#ebe9f5" width="88"  align="center">
                                                                <p align="center"><span style="font-size:11pt;">�� �� �� ��</span></p>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" width="554"  align="left">
		   <input type='text' size="79" name="subject">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td bgcolor="#ebe9f5" width="88"  align="center" height="187">
                                                                <p align="center"><span style="font-size:11pt;">�� �� �� ��</span></p>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" width="554"  align="left" height="187">
                                                                <p align="left">		  <textarea name="contents" cols="79" rows="12"></textarea>
</p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr bgcolor='#FFFFFF'>
                                    <td align='right' width="718">
                                        <p align="right">     <input type='button' value=" �� �� �� �� " onclick="javascript:send_check()">
&nbsp;&nbsp;&nbsp;	 <input type='reset' value=" �� �� �� �� ">
 &nbsp;</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        <td width="100">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="100">
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                        </td>
                        <td width="736">&nbsp;</td>
                        <td width="100">&nbsp;</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

<table cellpadding="0" cellspacing="0" width="960" bgcolor="white" align="center" height="10">
    <tr>
        <td width="960" height="10">
            <p align="center"><?include("../public/bottom.inc")?></p>
        </td>
    </tr>
</table>
</form>
</body>
</html>