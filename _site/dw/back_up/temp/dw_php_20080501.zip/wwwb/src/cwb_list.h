void cwb_list(Entry *sysp, SysConfig *sys, DB *db, DBConfig *conf);
int  findExtIcon(Entry *sysp, SysConfig *sys, char *filename, char *icon);
void highlightStr(int mode, char *orgstr, char *orgtok);

void findUPDNnum(char *dbpath, DB *db, DBConfig *conf, int *upNum, char *upSubject, int *dnNum, char *dnSubject);
