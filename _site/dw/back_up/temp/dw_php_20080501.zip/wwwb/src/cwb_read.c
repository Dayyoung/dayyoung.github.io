#include <stdio.h>
#include <stdlib.h>
#include "gdbm.h"
#include "qDecoder.h"
#include "cwb.h"
#include "cwb_db.h"
#include "cwb_list.h"
#include "cwb_read.h"

int  getArticle(char *dbpath, int num, DBArticle *article);
int previewFile(char *filename, int lines, int filter);

void cwb_read(Entry *sysp, SysConfig *sys, DB *db, DBConfig *conf){
  DBArticle article;
  char dbpath[0xFF];
  int  filter, replyPage, replyFtype;
  char *Name, *Email, *Subject;
  char status_msg[0xff]; /* ������ �ϴ� ���¹ٿ� ��Ÿ���� �޽��� */

  int  upNum, dnNum, i;                  /* ���� �Խù��� ���� ��,�Ʒ� �Խù� ��ȣ */
  char upSubject[0xff], dnSubject[0xff]; /* ���Ʒ� �Խù��� ���� */

  if(!strcmp(conf->Language, "korean")) {
    Name    = "�� ��";
    Email   = "���ڿ���";
    Subject = "�� ��";
  }
  else {
    Name    = "Name";
    Email   = "E-Mail";
    Subject = "Subject";
  }

  /* list�� date�̸� ���ñ� �ۼ��� 1�������� ���� */
  if(!strcmp(conf->ListOrder, "date")) {
    replyPage  = 1;
    replyFtype = 0;
  }
  else {
    replyPage  = db->page;
    replyFtype = db->ftype;
  }

  /* DB�� ����� ���� ���丮 ��θ� �����Ѵ� */
  sprintf(dbpath, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);

  /* �Խù��� �����´� */
  if(getArticle(dbpath, db->num, &article) == FALSE){
    qError("Brocken or Deleted Article : %d", db->num);
  }

  /* ���� �Խù���ȣ�� ���� �� �Ʒ� �Խù� ��ȣ�� ã�´�. */
  findUPDNnum(dbpath, db, conf, &upNum, upSubject, &dnNum, dnSubject);
  /* ���񿡼� ' �� �����Ѵ�, �ڹٽ�ũ��Ʈ '�� ���� ������ ���� ������ */
  for(i = 0; upSubject[i] != '\0'; i++) {
    if(upSubject[i] == '\'') upSubject[i] = '`';
  }
  for(i = 0; dnSubject[i] != '\0'; i++) {
    if(dnSubject[i] == '\'') dnSubject[i] = '`';
  }

  /* ���Ͱ��� ����� */
  if(!strcmp(conf->HtmlAccept, "true")) filter = 10;
  else if(!strcmp(conf->LinkTarget, "")) filter = 12;
  else filter = 13;

  /* �Ӹ��� ���� */
  headHtml(sys, conf);

    printf("\n<!-- HR Line -->\n");
    printf("<table border=0 width=80%%>\n");
    printf("  <tr><td><hr size=1 noshade></td></tr>\n");
    printf("</table>\n");

    printf("\n<!-- Article Information -->\n");
    printf("<table border=0 width=80%%>\n");
    printf("  <tr>\n");
    printf("    <td align=left>\n");
    printf("      <font color=darkgreen size=1 face='Arial'>\n");
    printf("      <font color=deeppink>%04d/%02d/%02d (%02d:%02d)</font>\n", article.Year, article.Mon, article.Day, article.Hour, article.Min);
    printf("      from\n");
    printf("      <font color=deeppink>%s</font>'\n", article.IP);
    printf("      of\n");
    printf("      <font color=deeppink>%s</font>'\n", article.Domain);
    printf("      </font>\n");
    printf("    </td>\n");
    printf("    <td align=right>\n");
    printf("      <font size=2 face='Arial'>Article Number : %d</font>\n", article.Num);
    printf("    </td>\n");
    printf("  </tr>\n");

    printf("  <tr>\n");
    printf("    <td align=left>\n");
    /* Icon Delete */
    strcpy(status_msg, "Delete this article");
    printf("      <a href='%s?db=%s&mode=delete&num=%d&page=%d&ftype=%d&fval=%s&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Delete'></a>\n", sys->ProgramName, db->db, article.Num, db->page, db->ftype, db->fencval, db->backdepth + 1, status_msg, sys->IconDelete);
    /* Icon Modify */
    strcpy(status_msg, "Modify this article");
    printf("      <a href='%s?db=%s&mode=modify&num=%d&page=%d&ftype=%d&fval=%s&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Modify'></a>\n", sys->ProgramName, db->db, article.Num, db->page, db->ftype, db->fencval, db->backdepth + 1, status_msg, sys->IconModify);
    /* Name */
    printf("      <font size=2 face='����'>"); highlightStr(1, article.Name, db->fval); printf("</font>\n");
    if(strcmp(article.Email, "") != 0){  /* Email �� �����ϸ� */
      sprintf(status_msg, "Send mail to %s (%s)", article.Name, article.Email);
      printf("      <font size=2 face='Arial'>(<a href='mailto:%s <%s>' onMouseOver=\"window.status=('%s'); return true;\">%s</a>)</font>\n", article.Name, article.Email, status_msg, article.Email);
    }
    printf("    </td>\n");
    printf("    <td align=right>\n");
    printf("      <font size=2 face='Arial'>\n");
    printf("      Access : %d\n", article.Access);
    printf("      ,\n");
    printf("      Lines : %d\n", article.Lines);
    printf("      </font>\n");
    printf("    </td>\n");
    printf("  </tr>\n");
    printf("</table>\n");

    printf("\n<!-- Subject -->\n");
    printf("<table border='%s' width=80%%><tr bgcolor='%s'><th>\n", conf->ReadTitleBorderSize, conf->ReadTitleBgColor);
    printf("  <font size=3 face='����' color='%s'>", conf->ReadTitleFontColor); highlightStr(11, article.Subject, db->fval); printf("</font>\n");
    printf("</th></tr></table>\n");

    if(strcmp(article.Filename, "") != 0) { /* ���ε�� ������ ���� */
      char fileicon[0xff], filepath[0xff];
      int  filetype;

      filetype = findExtIcon(sysp, sys, article.Filename, fileicon);
      sprintf(filepath, "%s/%s/%s", sys->DataDirectory, db->db, article.Filename);

      printf("\n<!-- Download -->\n");
      sprintf(status_msg, "Download %s (%d Kbytes)", article.Filename, atoi(article.Filesize) / 1024);
      printf("<table border='%s' width=80%%><tr bgcolor='%s'><td>\n", conf->ReadTextBorderSize, conf->ReadTextBgColor);
      printf("  <font size=2 face='����' color='%s'>\n", conf->ReadTextFontColor);
      printf("  <img src='%s' width=%s height=%s border=0> Download : <a href='%s' onMouseOver=\"window.status=('%s'); return true;\">%s</a>\n", fileicon, sys->IconWidth, sys->IconHeight, filepath, status_msg, article.Filename);
      printf("  (%d Kbytes)\n", atoi(article.Filesize) / 1024);
      printf("  </font><br>\n");

      /* ������ TEXT �̰ų� �׸��̸� �׳� �ѷ��� */
      switch(filetype) {
        case TYPE_TEXT : {
          printf("  <font size=2 face='%s' color='%s'>\n", conf->ReadTextFontType, conf->ReadTextFontColor);
          printf("  <hr size=1 noshade width=250 align=left>\n");

          printf("  <!-- Cut here -->\n");
          previewFile(filepath, atoi(sys->PreviewLines), filter);
          printf("  <!-- Cut here -->\n");

          printf("  </font>\n");
          break;
        }
        case TYPE_IMAGE : {
          printf("  <hr size=1 noshade width=250 align=left>\n");
          printf("  <img src='%s' border=0 alt='%s'>\n", filepath, article.Filename);
          break;
        }
        case TYPE_SOUND : {
          printf("  <hr size=1 noshade width=250 align=left>\n");
          printf("  <embed src='%s' width=146 height=60 autostart=true loop=false>\n", filepath);
          break;
        }
        case TYPE_MOVIE : {
          printf("  <hr size=1 noshade width=250 align=left>\n");
          printf("  <embed src='%s' width=200 height=150 autostart=true loop=false>\n", filepath);
          break;
        }
      }

      printf("</td></tr></table>\n");
    }

    if(strcmp(article.Text, "") != 0) {
      printf("\n<!-- Text -->\n");
      printf("<table border='%s' width=80%%>\n", conf->ReadTextBorderSize);
        printf("  <tr bgcolor='%s'><td><font size=2 face='%s' color='%s'>\n", conf->ReadTextBgColor, conf->ReadTextFontType, conf->ReadTextFontColor);

        printf("  <!-- Cut here -->\n");
        highlightStr(filter, article.Text, db->fval);
        printf("  <!-- Cut here -->\n");

        printf("  </font></td></tr>\n");
      printf("</table>\n");
    }

    printf("\n<!-- HR Line -->\n");
    printf("<table border=0 width=80%%>\n");
    printf("  <tr><td><hr size=1 noshade></td></tr>\n");
    printf("</table>\n");

    printf("\n<!-- ICON Link -->\n");
    printf("<table border=0 width=80%%>\n");
    printf("  <tr><td align=right>\n");

    /* Up */
    if(upNum != 0) {
      int q;
      sprintf(status_msg, "Previous article : %s", upSubject);
      for(q = 0; status_msg[q] != '\0'; q++) if(status_msg[q] == '\'' || status_msg[q] == '\"') status_msg[q] = '`';

      printf("    <a href='%s?db=%s&mode=read&num=%d&page=%d&ftype=%d&fval=%s&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Backward'></a>\n", sys->ProgramName, db->db, upNum, db->page-1, db->ftype, db->fencval, db->backdepth + 1, status_msg, sys->IconUp);
    }
    /* Down */
    if(dnNum != 0) {
      int q;
      sprintf(status_msg, "Next article : %s", dnSubject);
      for(q = 0; status_msg[q] != '\0'; q++) if(status_msg[q] == '\'' || status_msg[q] == '\"') status_msg[q] = '`';
      printf("    <a href='%s?db=%s&mode=read&num=%d&page=%d&ftype=%d&fval=%s&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Forward'></a>\n",  sys->ProgramName, db->db, dnNum, db->page-1, db->ftype, db->fencval, db->backdepth + 1, status_msg, sys->IconDown);
    }

    /* Write */
    strcpy(status_msg, "Write new message");
    printf("    <a href='%s?db=%s&mode=write&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Post'></a>\n", sys->ProgramName, db->db, db->backdepth + 1, status_msg, sys->IconWrite);
    /* Reply */
    strcpy(status_msg, "Reply to this article");
    printf("    <a href='%s?db=%s&mode=reply&num=%d&page=%d&ftype=%d&fval=%s&backdepth=%d' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='Reply'></a>\n", sys->ProgramName, db->db, article.Num, replyPage, replyFtype, db->fencval, db->backdepth + 1, status_msg, sys->IconReply);
    /* List */
    strcpy(status_msg, "Back to the list");
    if(db->backdepth == 0) { /* ����ڰ� ���������� ���Դ� */
      printf("    <a href='%s?db=%s' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='List'></a>\n", sys->ProgramName, db->db, status_msg, sys->IconList);
    }
    else printf("    <a href='javascript:history.go(-%d)' onMouseOver=\"window.status=('%s'); return true;\"><img src='%s' border=0 alt='List'></a>\n", db->backdepth, status_msg, sys->IconList);

    printf("  </td></tr>\n");
    printf("</table>\n");

  /* ������ ���� */
  tailHtml(sys, conf);
}

int getArticle(char *dbpath, int num, DBArticle *article) {
  char buf[20 + 1];

  DBOpen(dbpath, GDBM_REPLACE);

  article->Num  = num;

  if((article->Name    = qRemoveSpace(DBFetch("%d.Name", num))) == NULL) return FALSE;
  if((article->Email   = qRemoveSpace(DBFetch("%d.Email", num))) == NULL) return FALSE;
  if((article->Subject = qRemoveSpace(DBFetch("%d.Subject", num))) == NULL) return FALSE;
  if((article->Text    = DBFetch("%d.Text", num)) == NULL) return FALSE;

  if((article->Filename = DBFetch("%d.Filename", num)) == NULL) article->Filename = "";
  if((article->Filesize = DBFetch("%d.Filesize", num)) == NULL) article->Filesize = "";

  if((article->Date   = DBFetch("%d.Date", num)) == NULL) return FALSE;
  sscanf(article->Date, "%4d%2d%2d%2d%2d%2d", &article->Year, &article->Mon, &article->Day, &article->Hour, &article->Min, &article->Sec);
  if((article->IP     = DBFetch("%d.IP", num)) == NULL) return FALSE;
  if((article->Domain = DBFetch("%d.Domain", num)) == NULL) return FALSE;

  article->Lines  = DBiFetch("%d.Lines", num);
  article->Access = DBiFetch("%d.Access", num);
  article->Thread = DBiFetch("%d.Thread", num);

  /* Access Update */
  article->Access++;
  sprintf(buf, "%d.Access", num);
  DBiStore(buf, article->Access, GDBM_REPLACE);

  DBClose();

  return TRUE;
}

int previewFile(char *filename, int lines, int filter) {
  FILE *fp;
  char buf[1000 + 1];
  int i;

  fp = fopen(filename, "rt");
  if(fp == NULL) return FALSE;

  for(i = 1; (i <= lines) || (lines == 0); i++) {
    if(fgets(buf, 1000 + 1, fp) == NULL) break;
    qPuts(filter, buf);
  }

  return TRUE;
}
