void cwb_delete(SysConfig *sys, DB *db, DBConfig *conf);
