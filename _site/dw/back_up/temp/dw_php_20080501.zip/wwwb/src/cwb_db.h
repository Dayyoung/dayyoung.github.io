void DBError(void);

int  DBCreate(char *filename, int mode);

void DBOpen(char *filename, int flag);
void DBClose(void);

char *DBFetch(char *format, ...);
int  DBiFetch(char *format, ...);

void DBStore(char *key, char *str, int flag);
void DBiStore(char *key, int value, int flag);

int  DBDelete(char *format, ...);
