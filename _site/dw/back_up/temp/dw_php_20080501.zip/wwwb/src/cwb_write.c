#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "gdbm.h"
#include "qDecoder.h"
#include "cwb.h"
#include "cwb_db.h"
#include "cwb_admin.h"
#include "cwb_write.h"

typedef struct Reply {
  char *Name;
  char *Email;
  char Subject[0xff];
  char *Password;
  char *Text;
}Reply;

char *crypt(const char *, const char *);

void write_form(SysConfig *sys, DB *db, DBConfig *conf, Reply *reply);
char *replyMsg(SysConfig *sys, char *dbname, int num, char *replySubject);
char *joinText(char *txt1, char *txt2);
int  getlines(char *string);
int  sendmail(SysConfig *sys, char *To, DBArticle *article, DB *db, DBConfig *conf);

/* write & reply */
void cwb_write(SysConfig *sys, DB *db, DBConfig *conf){
  Reply reply;

  /* ���� �˻� */
  if(!strcmp(db->mode, "write") && db->num != 0) qError("Do not use manually.");
  if(!strcmp(db->mode, "reply") && db->num == 0) qError("Do not use manually.");

  /* �����ڸ� �Խù��� �ۼ��Ҽ� �ִٸ�, ��ȣ �˻� */
  if(!strcmp(conf->WriteMode, "admin")) {
    if(check_password(sys, db, conf) != PASS_ADMIN) qError("Only administrator(%s) can write", conf->AdminName);
  }

  /* ��Ű���� �̸��� E-mail�� ������ */
  if(!strcmp(sys->CookieEnable, "true")) {
    if((reply.Name  = qcValue("NAME"))  == NULL) reply.Name  = "";
    if((reply.Email = qcValue("EMAIL")) == NULL) reply.Email = "";
  }
  else {
    reply.Name  = "";
    reply.Email = "";
  }

  if(db->num != 0) {  /* ���ñ� ���� */
    reply.Text  = replyMsg(sys, db->db, db->num, reply.Subject);
  }
  else { /* �׳� ���� */
    strcpy(reply.Subject, "");
    reply.Text = conf->DefaultText;
  }

  reply.Password = "";

  write_form(sys, db, conf, &reply);
}

void cwb_modify(SysConfig *sys, DB *db, DBConfig *conf){
  Reply reply;
  char buf[0xff], *tmp;
  int  pass;

  if(db->num == 0) qError("Do not use manually.");

  pass = check_password(sys, db, conf);
  if(!(pass == PASS_ADMIN || pass == PASS_POSTER)) qError("Only administrator(%s) or Poster can modify.", conf->AdminName);

  sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
  DBOpen(buf, GDBM_READER);

  reply.Name     = DBFetch("%d.Name",     db->num);
  reply.Email    = DBFetch("%d.Email",    db->num);
  tmp = DBFetch("%d.Subject",  db->num);
  if(tmp == NULL) strcpy(reply.Subject, "");
  else {
    strcpy(reply.Subject, tmp);
    free(tmp);
  }
  reply.Text     = DBFetch("%d.Text",     db->num);

  DBClose(); 

  if(reply.Name     == NULL) qError("Original article(%d) not found.", db->num);
  if(reply.Email    == NULL) reply.Email    = "";
  if(reply.Text     == NULL) reply.Text     = "";

  reply.Password = "";

  write_form(sys, db, conf, &reply);
}

void write_form(SysConfig *sys, DB *db, DBConfig *conf, Reply *reply){
  char *Mode;
  char *Name, *Password, *Email, *Subject, *AttachText, *AttachFile, *Sign;

  /* ���� ���� ���� */
  if(!strcmp(db->mode, "modify")) Mode = "modifysave";
  else                            Mode = "writesave";     /* write or reply */

  /* ��� ��ȯ */
  if(!strcmp(conf->Language, "korean")) {
    Name         = "�� ��";
    Email        = "���ڿ���";
    Subject      = "�� ��";
    AttachText   = "����÷��";
    AttachFile   = "��������";
    if(!strcmp(db->mode, "modify")) {
      Sign     = "    ��  ��    ";
      Password = "����й�ȣ";
    }
    else {
      Sign     = "    ��  ��    ";
      Password = "��й�ȣ";
    }
  }
  else {
    Name         = "Name";
    Email        = "E-Mail";
    Subject      = "Subject";
    AttachText   = "Attach Text";
    AttachFile   = "Upload Binary";
    if(!strcmp(db->mode, "modify")) {
      Sign     = "    Modify    ";
      Password = "New Passwd";
    }
    else {
      Sign     = "    Submit    ";
      Password = "Password";
    }
  }

  headHtml(sys, conf);

  printf("\n<!-- Form -->\n");
  printf("<form method='post' action='%s' enctype='multipart/form-data'>\n", sys->ProgramName);

  printf("  <input type=hidden name='db'    value='%s'>\n", db->db);
  printf("  <input type=hidden name='mode'  value='%s'>\n", Mode);
  printf("  <input type=hidden name='num'   value='%d'>\n", db->num);
  printf("  <input type=hidden name='page'  value='%d'>\n", db->page);
  printf("  <input type=hidden name='ftype' value='%d'>\n", db->ftype);
  printf("  <input type=hidden name='fval'  value='%s'>\n", db->fval);
  if(db->password != NULL) printf("  <input type=hidden name='password' value='%s'>\n", crypt(db->password, sys->CryptSalt));


  printf("\n<!-- Table -->\n");
  printf("<table border=0>\n");

  printf("\n  <!-- HR -->\n");
  printf("  <tr><td colspan=3><hr size=1 noshade></td></tr>\n");

  /* Name */
  printf("\n  <!-- Name field -->\n");
  printf("  <tr><th bgcolor='%s'><font size=2 face='����' color='%s'>%s</font></th>\n", conf->WriteTitleBgColor, conf->WriteTitleFontColor, Name);
  printf("      <td><font size=3><input type='text' name='pName' size=20 maxlength=20 value='"); qPrintf(1, reply->Name); printf("'></font></td>\n");
  printf("      <td>&nbsp;</td>\n");
  printf("  </tr>\n");

  /* E-mail */
  printf("\n  <!-- Email field -->\n");
  printf("  <tr><th bgcolor='%s'><font size=2 face='����' color='%s'>%s</font></th>\n", conf->WriteTitleBgColor, conf->WriteTitleFontColor, Email);
  printf("      <td><font size=3><input type='text' name='pEmail' size=50 maxlength=40 value='"); qPrintf(1, reply->Email); printf("'></font></td>\n");
  printf("      <td>&nbsp;</td>\n");
  printf("  </tr>\n");

  /* Subject */
  printf("\n  <!-- Subject field -->\n");
  printf("  <tr><th bgcolor='%s'><font size=2 face='����' color='%s'>%s</font></th>\n", conf->WriteTitleBgColor, conf->WriteTitleFontColor, Subject);
  printf("      <td><font size=3'><input type='text' name='pSubject' size=50 maxlength=50 value='"); qPrintf(1, reply->Subject); printf("'></font></td>\n");
  printf("      <th><font size=2 face='����'>%s</font></th>\n", Password);
  printf("  </tr>\n");

  /* Attach Text File */
  printf("\n  <!-- Attachment field -->\n");
  printf("  <tr><th bgcolor='%s'><font size=2 face='����' color='%s'>%s</font></th>\n", conf->WriteTitleBgColor, conf->WriteTitleFontColor, AttachText);
  printf("      <td><font size=3><input type='file' name='pAttachText' size=32></font></td>\n");
  printf("      <th><font size=3><input type='password' name='pPassword' size=8  maxlength=8  value='%s'></font></th>\n", reply->Password);
  printf("  </tr>\n");

  /* Text File */
  printf("\n  <!-- Text field -->\n");
  printf("  <tr>\n");
  printf("    <td colspan=3 align=center><font size=3>\n");
  printf("<textarea name='pText' cols='%s' rows='15' wrap='virtual'>", sys->TextFieldLength);
  qPuts(1, reply->Text);
  printf("</textarea>\n");
  printf("    </font></td>\n");
  printf("  </tr>\n");

  /* Attach Binary File */
  if(!strcmp(conf->UploadEnable, "true") && strcmp(db->mode, "modify") && !strcmp(sys->AllowUpload, "true")) {
    printf("\n  <!-- Binary uploading field -->\n");
    printf("  <tr><th bgcolor='%s'><font size=2 face='����' color='%s'>%s</font></th>\n", conf->WriteTitleBgColor, conf->WriteTitleFontColor, AttachFile);
    printf("      <td colspan=2><font size=3><input type='file' name='pAttachFile' size=32></td></font>\n");
    printf("  </tr>\n");
  }

  printf("\n  <!-- HR -->\n");
  printf("  <tr><td colspan=3><hr size=1 noshade></td></tr>\n");

  printf("\n  <!-- Icon List Link -->\n");
  printf("  <tr>\n");
  printf("    <td align=left><font size=2 face='����'><input type=submit value='%s'></font></td>\n", Sign);
  printf("    <td align=right colspan=3>\n");

  if(db->backdepth == 0) { /* ����ڰ� ���������� ���Դ� */
    printf("    <a href='%s?db=%s' onMouseOver=\"window.status=('Back to the list'); return true;\"><img src='%s' border=0 alt='List'></a>\n", sys->ProgramName, db->db, sys->IconList);
  }
  else  printf("    <a href='javascript:history.go(-%d)' onMouseOver=\"window.status=('Back to the list'); return true;\"><img src='%s' border=0 alt='List'></a>\n", db->backdepth, sys->IconList);

  printf("    </td>\n");
  printf("  </tr>\n");

  printf("</form>\n");
  printf("</table>\n");

  tailHtml(sys, conf);
}

#define MAX_BUF		(1000)
#define DUMMY_LINES	(10)
char *replyMsg(SysConfig *sys, char *dbname, int num, char *replySubject){
  char *replyText;
  char *rName, *rSubject, *rText, buf[MAX_BUF+1];
  int  rLines, rTextSize;

  char rHeader[0xFF], *rTailer = "\n";

  int i, j;

  sprintf(buf, "%s/%s.%s", sys->DataDirectory, dbname, sys->DataExtension);
  DBOpen(buf, GDBM_READER);

  rName    = DBFetch ("%d.Name",    num);
  rSubject = DBFetch ("%d.Subject", num);
  rText    = DBFetch ("%d.Text",    num);
  rLines   = DBiFetch("%d.Lines",   num);

  DBClose(); 

  if(rName    == NULL) qError("Original article(%d) not found.", num);
  if(rSubject == NULL) rSubject = "";
  if(rText    == NULL) rText    = "";

  /* Subject */
  /* Re: �� �ȵ� ���� Re:�� �߰� �Ѵ� */
  if(strncmp(rSubject, sys->ReSubject, strlen(sys->ReSubject))) {
    sprintf(replySubject, "%s %s", sys->ReSubject, rSubject);
  }
  else strcpy(replySubject, rSubject);

  /* Text */
  sprintf(rHeader, "%s %s\n", rName, sys->ReText);

  rTextSize = strlen(rHeader) + strlen(rText) + (strlen(sys->ReLine) * (rLines + DUMMY_LINES)) + strlen(rTailer) + 1;

  replyText = (char *)malloc(rTextSize);
  if(replyText == NULL) qError("Memory allocation fail.");

  strcpy(replyText, rHeader);
  for(i = 0; rText[i] != '\0'; i += j){
    for(j = 0; j < MAX_BUF; j++){
      buf[j] = rText[i+j];
      if(buf[j] == '\n') {
        j++;
        break;
      }
      else if(rText[i+j] == '\0') break;
    }
    buf[j] = '\0';
    strcat(replyText, (const char *)sys->ReLine);
    strcat(replyText, (const char *)buf);
  }
  strcat(replyText, (const char *)rTailer);

  printf("<!-- Malloc Size : %d bytes , StrSize : %d bytes -->\n", rTextSize, strlen(replyText));

  free(rName);
  free(rSubject);
  free(rText);

  return replyText;
}

void cwb_writesave(SysConfig *sys, DB *db, DBConfig *conf){
  DBArticle article;
  Cgienv env;

  char buf[0xff], date[14+1];
  char *attachText, *o_poster;
  int  dataExist = FALSE;

  if(!strcmp(conf->WriteMode, "admin")) {
    if(check_password(sys, db, conf) != PASS_ADMIN) qError("Only administrator(%s) can write", conf->AdminName);
  }

  /* Fetch Query */
  qCgienv(&env);
  article.Name     = qRemoveSpace(qValue("pName"));
  article.Email    = qRemoveSpace(qValue("pEmail"));
  article.Subject  = qRemoveSpace(qValue("pSubject"));
  article.Password = qValue("pPassword");
  article.Text     = qValue("pText");

  attachText       = qValue("pAttachText");
  article.Filename = qValue("pAttachFile.filename");
  article.Filesize = qValue("pAttachFile.length");

  sprintf(date, "%04d%02d%02d%02d%02d%2d", env.year, env.mon, env.day, env.hour, env.min, env.sec);
  article.Date   = date;
  article.IP     = env.remote_addr;
  article.Domain = env.remote_host;
  if(article.Domain == NULL) article.Domain = article.IP;

  article.Lines  = getlines(article.Text);
  article.Access = 0;
  article.Thread = db->num;

  /* Fetch Test */
  if(article.Name     == NULL) qError("Only reserved query can be accepted.");
  if(article.Email    == NULL) qError("Only reserved query can be accepted.");
  if(article.Subject  == NULL) qError("Only reserved query can be accepted.");
  if(article.Text     == NULL) qError("Only reserved query can be accepted.");

  if(article.Password == NULL) qError("Only reserved query can be accepted.");

  /* Data �˻� */
  if(!strcmp(article.Name,     ""))     qError("The name field must be specified.");
  if(strcmp(article.Email,     "") != 0) {
    if(qCheckEmail(article.Email) == 0) qError("The E-mail address(%s) is incorrect.", article.Email);
  }
  if(!strcmp(article.Subject,  ""))     qError("The subject field must be specified.");
  if(strcmp(article.Password,  "") != 0) article.Password = crypt(article.Password, sys->CryptSalt);


  if(strlen(article.Text) > 0) dataExist = TRUE;

  /* Attach Text */
  if(attachText != NULL) {
    if(strcmp(attachText, "") != 0) {
      article.Text  = joinText(article.Text, attachText);
      article.Lines = getlines(article.Text);
      if(strlen(article.Text) > 0) dataExist = TRUE;
    }
  }

  /* Attach File */
  if(article.Filename != NULL) {
    int fileLength;

    fileLength = atoi(article.Filesize);

    if(fileLength == 0) {
      article.Filename = "";
      article.Filesize = "";
    }
    else { /* upload�� �Ǿ��� */
      FILE *fp;
      char *binaryp, binaryName[0xff], binaryPath[0xff];
      int  i;

      dataExist = TRUE;

      /* ���丮 ���� �˻� */
      sprintf(binaryPath, "%s/%s", sys->DataDirectory, db->db);
      if(qCheckFile(binaryPath) == 0) { /* ���ε�� ���丮 ���� */
        if(mkdir(binaryPath, (unsigned short)atoi(sys->DirectoryPermission)) != 0) {
          qError("Upload directory(%s) creation fail.", binaryPath);
        }
      }

      /* �������� �˻� */
      sprintf(binaryPath, "%s/%s/%s", sys->DataDirectory, db->db, article.Filename);
      if(qCheckFile(binaryPath) == 1) { /* ���������� �����ϸ� */
        for(i = 1; ; i++) {
          sprintf(binaryPath, "%s/%s/%d-%s", sys->DataDirectory, db->db, i, article.Filename);
          if(qCheckFile(binaryPath) == 0) { /* �������� ���� */
            /* ���ο� ���ϸ��� ���� */
            sprintf(binaryName, "%d-%s", i, article.Filename);
            article.Filename = binaryName;
            break;
          }
        }
      }

      /* ���� */
      binaryp = qValue("pAttachFile");
      fp = fopen(binaryPath, "wb");
      if(fp == NULL) qError("File creation(%s) fail.", binaryPath);
      for(i = 0; i < fileLength; i++) fprintf(fp, "%c", binaryp[i]);
      fclose(fp);

      /* �۹̼� ���� */
      chmod(binaryPath, (unsigned short)atoi(sys->FilePermission));
    }
  }
  else {
    article.Filename = "";
    article.Filesize = "";
  }

  if(dataExist == FALSE) qError("There is no data to post.");

  /* Insert into DB */
  sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
  DBOpen(buf, GDBM_WRITER);

  /* DB�� ���������� ����Ǿ���, ������ �Խù� ��ȣ�� �ٽ� �����´� */
  conf->LastNum = DBiFetch("conf.LastNum");
  conf->LastNum++;

  sprintf(buf, "%d.Name", conf->LastNum);
  DBStore(buf, article.Name, GDBM_REPLACE);

  sprintf(buf, "%d.Email", conf->LastNum);
  DBStore(buf, article.Email, GDBM_REPLACE);

  sprintf(buf, "%d.Subject", conf->LastNum);
  DBStore(buf, article.Subject, GDBM_REPLACE);

  sprintf(buf, "%d.Text", conf->LastNum);
  DBStore(buf, article.Text, GDBM_REPLACE);

  sprintf(buf, "%d.Filename", conf->LastNum);
  DBStore(buf, article.Filename, GDBM_REPLACE);

  sprintf(buf, "%d.Filesize", conf->LastNum);
  DBStore(buf, article.Filesize, GDBM_REPLACE);

  sprintf(buf, "%d.Date", conf->LastNum);
  DBStore(buf, article.Date, GDBM_REPLACE);

  sprintf(buf, "%d.IP", conf->LastNum);
  DBStore(buf, article.IP, GDBM_REPLACE);

  sprintf(buf, "%d.Domain", conf->LastNum);
  DBStore(buf, article.Domain, GDBM_REPLACE);

  sprintf(buf, "%d.Lines", conf->LastNum);
  DBiStore(buf, article.Lines, GDBM_REPLACE);

  sprintf(buf, "%d.Access", conf->LastNum);
  DBiStore(buf, article.Access, GDBM_REPLACE);

  sprintf(buf, "%d.Thread", conf->LastNum);
  DBiStore(buf, article.Thread, GDBM_REPLACE);

  sprintf(buf, "%d.Password", conf->LastNum);
  DBStore(buf, article.Password, GDBM_REPLACE);

  DBiStore("conf.LastNum", conf->LastNum, GDBM_REPLACE);

  /* ���ñ��� ��� �������α��� �ۼ��� E-mail�� ���� �´� */
  o_poster = DBFetch("%d.Email", article.Thread);

  DBClose();

  /* ���� ������ */
  if(!strcmp(conf->MailToAdmin, "true")) {
    sendmail(sys, conf->AdminEmail, &article, db, conf);
  }

  if(!strcmp(conf->MailToSender, "true")) {
    sendmail(sys, o_poster, &article, db, conf);
  }
}

void cwb_modifysave(SysConfig *sys, DB *db, DBConfig *conf){
  DBArticle article;
  char *attachText, buf[0xff];
  int  pass;
  int  dataExist = FALSE;

  if(db->num == 0) qError("Do not use manually.");

  pass = check_password(sys, db, conf);
  if(!(pass == PASS_ADMIN || pass == PASS_POSTER)) qError("Only administrator(%s) or Poster can modify.", conf->AdminName);

  /* Fetch Query */
  article.Name     = qRemoveSpace(qValue("pName"));
  article.Email    = qRemoveSpace(qValue("pEmail"));
  article.Subject  = qRemoveSpace(qValue("pSubject"));
  article.Text     = qValue("pText");
  article.Password = qValue("pPassword");
  article.Lines    = getlines(article.Text);

  attachText       = qValue("pAttachText");

  /* Fetch Test */
  if(article.Name     == NULL) qError("Only reserved query can be accepted.");
  if(article.Email    == NULL) qError("Only reserved query can be accepted.");
  if(article.Subject  == NULL) qError("Only reserved query can be accepted.");
  if(article.Text     == NULL) qError("Only reserved query can be accepted.");
  if(article.Password == NULL) qError("Only reserved query can be accepted.");

  /* Data �˻� */
  if(!strcmp(article.Name,     ""))     qError("The name field must be specified.");
  if(strcmp(article.Email,     "") != 0) {
    if(qCheckEmail(article.Email) == 0) qError("The E-mail address is incorrect.", article.Email);
  }
  if(!strcmp(article.Subject,  ""))     qError("The subject field must be specified.");

  if(strlen(article.Text) > 0) dataExist = TRUE;

  /* Attach Text */
  if(attachText != NULL) {
    if(strcmp(attachText, "") != 0) {
      article.Text  = joinText(article.Text, attachText);
      article.Lines = getlines(article.Text);
      if(strlen(article.Text) > 0) dataExist = TRUE;
    }
  }

  if(dataExist == FALSE) qError("There is no data to post.");

  /* Modify DB */
  sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
  DBOpen(buf, GDBM_WRITER);

  /* �Խù��� �����ϴ��� Ȯ���Ѵ� */
  if(DBFetch("%d.Name", db->num) == NULL) qError("There is no article to modify in the database.");

  sprintf(buf, "%d.Name", db->num);
  DBStore(buf, article.Name, GDBM_REPLACE);

  sprintf(buf, "%d.Email", db->num);
  DBStore(buf, article.Email, GDBM_REPLACE);

  sprintf(buf, "%d.Subject", db->num);
  DBStore(buf, article.Subject, GDBM_REPLACE);

  sprintf(buf, "%d.Text", db->num);
  DBStore(buf, article.Text, GDBM_REPLACE);

  sprintf(buf, "%d.Lines", db->num);
  DBiStore(buf, article.Lines, GDBM_REPLACE);

  if(strcmp(article.Password, "") != 0) {
    article.Password = crypt(article.Password, sys->CryptSalt);
    sprintf(buf, "%d.Password", db->num);
    DBStore(buf, article.Password, GDBM_REPLACE);
  }

  DBClose();
}

char *joinText(char *txt1, char *txt2) {
  char *joinText;
  int  joinTextLen, txt1Len, txt2Len;
  int  i, j;

  /* Here, we do not use realloc(). Because sometimes it is unstable. */
  txt1Len = strlen(txt1);
  txt2Len = strlen(txt2);

  joinTextLen = txt1Len + txt2Len + strlen("\n");
  joinText = (char *)malloc(sizeof(char) * (joinTextLen + 1));
  if(joinText == NULL) qError("Memory allocation fail.");


  for(i = 0; i < txt1Len; i++) joinText[i] = txt1[i];
  if(i > 0) joinText[i++] = '\n';
  for(j = 0; j < txt2Len; j++, i++) joinText[i] = txt2[j];
  joinText[i]   = '\0';

  return joinText;
}


int getlines(char *string){
  int i = 1, j = 0;

  if(!strcmp(string, "")) return 0;

  while(string[j]){
    if(string[j] == '\n')i++;
    j++;
  }
  return i;
}

int sendmail(SysConfig *sys, char *To, DBArticle *article, DB *db, DBConfig *conf) {
  Cgienv env;
  FILE *fp;
  char smail[0xFF], server_domain[0xFF];

  if(To == NULL)      return FALSE;
  if(!strcmp(To, "")) return FALSE;

  qCgienv(&env);

  sprintf(smail, "%s/%s %s", sys->SendmailDirectory, sys->SendmailFilename, sys->SendmailOptions);

  fp = popen(smail, "w");
  if(fp == NULL) qError("Sendmail(%s) not found.", smail);

  fprintf(fp, "From: \"%s\" <%s>\n",   sys->MailName, conf->AdminEmail);
  fprintf(fp, "Reply-To: \"%s\" <%s>\n", conf->AdminName, conf->AdminEmail);
  fprintf(fp, "Organization: %s\n",    sys->MailOrganization);
  fprintf(fp, "X-Mailer: %s %s (Unix)\n", sys->ProgramName, sys->ProgramVersion);
  fprintf(fp, "To: %s\n",              To);
  fprintf(fp, "Subject: %s\n",         article->Subject);

  /* HEADER */
  if(!strcmp(conf->UseSysDefMail, "true") || !strcmp(sys->AllowDBmail, "false")) {
    FILE *dp;
    dp = fopen(sys->MailHead, "rt");
    if(dp != NULL) {
      int c;
      while((c = fgetc(dp)) != EOF) fprintf(fp, "%c", c);
      fclose(dp);
    }
    fprintf(fp, "\n");
  }
  else {
    fprintf(fp, "%s\n", conf->MailHead);
  }

  if(!strcmp(env.server_port, "80")) sprintf(server_domain, "%s", env.server_name);
  else sprintf(server_domain, "%s:%s", env.server_name, env.server_port);

  /* TEXT*/
  fprintf(fp, "-- [ Server Information ] ----------------------------\n");
  fprintf(fp, "Software            : %s %s\n", sys->ProgramName, sys->ProgramVersion);
  fprintf(fp, "Server Name         : %s\n", env.server_name);
  fprintf(fp, "Administrator Name  : %s\n", conf->AdminName);
  fprintf(fp, "Administrator Email : mailto:%s\n", conf->AdminEmail);
  fprintf(fp, "HomePage Location   : %s\n", conf->HomeUrl);
  fprintf(fp, "DB Name             : %s\n", db->db);
  fprintf(fp, "DB Location         : http://%s%s?db=%s\n", server_domain, env.script_name, db->db);
  fprintf(fp, "Article Location    : http://%s%s?db=%s&mode=read&num=%d\n", server_domain, env.script_name, db->db, conf->LastNum);
  if(strcmp(article->Filename, "") != 0) {
    fprintf(fp, "Attached Filename   : %s (%d kbytes)\n", article->Filename, atoi(article->Filesize) / 1024);
  }

  fprintf(fp, "\n");
  fprintf(fp, "-- [ Article Information ] -----------------------\n");
  fprintf(fp, "@@ Name    : %s\n", article->Name);
  fprintf(fp, "## Email   : mailto:%s\n", article->Email);
  fprintf(fp, "## Date    : %s (yyyymmddhhmmss)\n", article->Date);
  fprintf(fp, "## Host    : %s of %s\n", article->IP, article->Domain);
  fprintf(fp, "@@ Subject : %s\n", article->Subject);

  /* ù������ ��Ʈ�� �޸��� �ٲ۴�. ��Ʈ���� �ߴܵ��� �ʱ����� */
  if(strcmp(article->Text, "") != 0) {
    int i;
    for(i = 0; article->Text[i] != '\0'; i++) {
      if(i == 0) {
        if(article->Text[i] == '.' && article->Text[i+1] == '\r') article->Text[i] = ',';
      }
      else {
        if(article->Text[i-1] == '\n' && article->Text[i] == '.' && article->Text[i+1] == '\r') article->Text[i] = ',';
        if(article->Text[i-1] == '\n' && article->Text[i] == '.' && article->Text[i+1] == '\0') article->Text[i] = ',';
      }
    }
  }

  fprintf(fp, "-- [ Text ] --------------------------------------\n");
  fprintf(fp, "%s\n", article->Text);
  fprintf(fp, "---[ End ] ---------------------------------------\n");

  /* TAILER */
  if(!strcmp(conf->UseSysDefMail, "true") || !strcmp(sys->AllowDBmail, "false")) {
    FILE *dp;
    dp = fopen(sys->MailTail, "rt");
    if(dp != NULL) {
      int c;
      while((c = fgetc(dp)) != EOF) fprintf(fp, "%c", c);
      fclose(dp);
    }
  }
  else {
    fprintf(fp, "%s", conf->MailTail);
  }


  fprintf(fp, "\n.\n");

  pclose(fp);
  return TRUE;
}
