#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "gdbm.h"
#include "qDecoder.h"
#include "cwb.h"
#include "cwb_db.h"
#include "cwb_admin.h"
#include "cwb_delete.h"

void cwb_delete(SysConfig *sys, DB *db, DBConfig *conf){
  int  pass, i;
  char buf[0xFF], *filename;

  int  newThread;
  
  if(db->num == 0) qError("Handling number must be specified.");

  pass = check_password(sys, db, conf);
  if(!(pass == PASS_ADMIN || pass == PASS_POSTER)) qError("Only administrator(%s) or Poster can delete.", conf->AdminName);

  sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
  DBOpen(buf, GDBM_REPLACE);
    /* �Խù��� ���� Ȯ�� */
    if(DBFetch("%d.Thread", db->num) == NULL) qError("Article not found.");

    /* �Խù��� Thread��ȣ ȹ�� */
    newThread = DBiFetch("%d.Thread", db->num);

    /* ���� �����Ͽ��� ������ ��ȣ�� �ٽ��ѹ� Ȯ���Ѵ� */
    conf->LastNum = DBiFetch("conf.LastNum");   

    /* �Խù��� ���õȱ��� �Խù��� Thread��ȣ�� �ٲ۴� */
    for(i = db->num + 1; i <= conf->LastNum; i++) {
      if(DBiFetch("%d.Thread", i) == db->num) {
        sprintf(buf, "%d.Thread", i);
        DBiStore(buf, newThread, GDBM_REPLACE);
      }
    }

    /* ���ε��� ���ϸ� ȹ�� */
    filename = DBFetch("%d.Filename", db->num);

    /* �Խù� ���� */
    DBDelete("%d.Name",    db->num);
    DBDelete("%d.Email",   db->num);
    DBDelete("%d.Subject", db->num);
    DBDelete("%d.Text",    db->num);

    DBDelete("%d.Filename",   db->num);
    DBDelete("%d.Filesize", db->num);

    DBDelete("%d.Date",   db->num);
    DBDelete("%d.IP",     db->num);
    DBDelete("%d.Domain", db->num);

    DBDelete("%d.Lines",  db->num);
    DBDelete("%d.Access", db->num);
    DBDelete("%d.Thread", db->num);

    DBDelete("%d.Password", db->num);

    /* ���ε� ���� ���� */
    if(filename != NULL) {
      if(strcmp(filename, "") != 0) {
        sprintf(buf, "%s/%s/%s", sys->DataDirectory, db->db, filename);
        unlink(buf);
      }
    }

  DBClose();
}
