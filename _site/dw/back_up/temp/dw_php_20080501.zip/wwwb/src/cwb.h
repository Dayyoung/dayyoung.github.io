#define TRUE		(1)
#define FALSE		(0)

#define FNAME		(1)
#define FSUBJECT	(2)
#define FTEXT		(4)

#define REALTIME_CONFIG_FILE	"CrazyWWWBoard.conf"

#define TYPE_UNLINK	(0)
#define TYPE_LINK		(1)
#define TYPE_TEXT		(2)
#define TYPE_IMAGE	(3)
#define TYPE_SOUND	(4)
#define TYPE_MOVIE	(5)


typedef struct {
  char *db;
  char *mode;
  int  page;
  int  num;
  char *password;

  int  ftype;   /* 3���� And ó�� �ȴ�, �̸�:00000001, ����:00000010, ����:00000100 */
  char *fval;
  char *fencval; /* Encoding�� fval, Link�� */

  int  backdepth; /* ������ back ���� ���ؼ� ����Ѵ�. ������ back�� ������ ����Ʈ�� �ü� �ֵ��� */
}DB;

typedef struct {
  char *ProgramName;
  char *ProgramVersion;

  char *FilePermission;
  char *DirectoryPermission;

  char *DataDirectory;
  char *DataExtension;

  char *AccessLog;
  char *ErrorLog;

  char *HtmlHead;
  char *HtmlTail;
  char *Help;

  char *IconAdmin;
  char *IconHome;
  char *IconBack;
  char *IconHelp;

  char *IconList;
  char *IconReload;
  char *IconWrite;
  char *IconModify;
  char *IconReply;
  char *IconDelete;

  char *IconUp;
  char *IconDown;

  char *IconWidth;
  char *IconHeight;
  char *IconOpen;
  char *IconClose;
  char *IconTypeDefault;
  char *IconTypeUnknown;

  char *CryptSalt;

  char *SendmailDirectory;
  char *SendmailFilename;
  char *SendmailOptions;

  char *MailHead;
  char *MailTail;

  char *MailName;
  char *MailOrganization;

  char *CookieEnable;
  char *CookieExpireDays;

  char *PageLinkNum;

  char *TextFieldLength;

  char *ReSubject;
  char *ReText;
  char *ReLine;

  char *PreviewLines;

  char *HiddenAdminLink;
  char *HiddenHelpLink;

  char *AllowDBhtml;
  char *AllowDBmail;
  char *AllowUpload;
}SysConfig;

typedef struct {
  int  LastNum;

  char *Password;
  char *Message;

  char *HomeUrl;
  char *HomeTarget;
  char *BackUrl;
  char *BackTarget;

  char *AdminName;
  char *AdminEmail;
  char *MailToAdmin;
  char *MailToSender;

  char *ListOrder;
  char *NameFirst;
  char *ArticleNumber;
  char *VirtualNumber;
  char *FolderIcon;
  char *UploadEnable;
  char *TypeIcon;
  char *LinkTarget;
  char *Language;
  char *WriteMode;
  char *HtmlAccept;
  char *HideSearch;
  int  ArticlesPerPage;

  char *UseSysDefHtml;
  char *HtmlHead;
  char *HtmlTail;
  char *DefaultText;

  char *ListBorderSize;
  char *ListFontSize;
  char *ListTitleFontColor;
  char *ListTitleBgColor;
  char *ListArticleFontColor;
  char *ListArticleBgColor;

  char *ReadTitleBorderSize;
  char *ReadTextBorderSize;
  char *ReadFontSize;
  char *ReadTitleFontColor;
  char *ReadTitleBgColor;
  char *ReadTextFontColor;
  char *ReadTextBgColor;
  char *ReadTextFontType;

  char *WriteTitleFontColor;
  char *WriteTitleBgColor;

  char *UseSysDefMail;
  char *MailHead;
  char *MailTail;
}DBConfig;

typedef struct {
  /* Article Info or �ӽ� */  
  int  Num;
  int  Year, Mon, Day, Hour, Min, Sec;

  /* ���� DB�� ����Ǵ� Article Skeleton Full Field */
  char *Name;
  char *Email;
  char *Subject;
  char *Text;

  char *Filename;
  char *Filesize;

  char *Date;
  char *IP;
  char *Domain;

  int  Lines;
  int  Access;
  int  Thread;

  char *Password;
}DBArticle;

/*** ��Ϻ��� ��⿡�� ����ϴ� ���� Article Skeleton ***/
typedef struct {
  int  Num;
  int  Year, Mon, Day;

  /* DB���� ���� */
  char *Name;
  char *Email;
  char *Subject;

  char *Filename;
  char *Filesize;

  char *Date;
  int  Lines;
  int  Access;
}DBList;

/* common functions */
void headHtml(SysConfig *sys, DBConfig *conf);
void tailHtml(SysConfig *sys, DBConfig *conf);
