#include <stdio.h>
#include <stdlib.h>
#include "gdbm.h"
#include "qDecoder.h"
#include "cwb.h"
#include "cwb_db.h"
#include "cwb_admin.h"

char *crypt(const char *, const char *);

void password_form(SysConfig *sys, DB *db, DBConfig *conf);
void admin_form(SysConfig *sys, DB *db, DBConfig *conf);


int check_password(SysConfig *sys, DB *db, DBConfig *conf){
  /* DB�� ��й�ȣ�� ����, �ʱ� ��й�ȣ ������ ���� 2�� ���� */
  if(conf->Password == NULL) return PASS_NOT_DEFINE;

  /* ��й�ȣ feedback(password_form()���κ���)�� �����Ƿ� Ȯ��ȭ�� ��� */
  if(db->password == NULL) password_form(sys, db, conf);

  /* feedback�Ǿ���, ��ȣȭ�� ������ ��й�ȣ�� ���Ѵ� */
  /* �Էµ� ��й�ȣ�� ��ȣȭ �Ǿ��������� �ְ�, ����ڰ� �Է��� �״���ϼ��� �ִ� */
  /* ������ ���α׷� ���ο����� ��ȣȭ�� ��й�ȣ�� ���������ϱ� �����̴� */
  if(!strcmp(conf->Password, db->password)) return PASS_ADMIN;
  if(!strcmp(conf->Password, crypt(db->password, sys->CryptSalt))) return PASS_ADMIN;

  if(db->num != 0) {
    int passflag = FALSE;
    if(!strcmp(db->mode, "modify"))     passflag = TRUE;
    if(!strcmp(db->mode, "delete"))     passflag = TRUE;
    if(!strcmp(db->mode, "modifysave")) passflag = TRUE;
    if(passflag == TRUE) {
      char *aPassword, buf[0xFF];

      sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
      DBOpen(buf, GDBM_READER);
      if((aPassword = DBFetch("%d.Password", db->num)) == NULL) return PASS_FAIL;
      DBClose();

      if(!strcmp(aPassword, "")) return PASS_FAIL;

      if(!strcmp(aPassword, db->password)) return PASS_POSTER;
      if(!strcmp(aPassword, crypt(db->password, sys->CryptSalt))) return PASS_POSTER;
    }
  }
  return PASS_FAIL;
}

void password_form(SysConfig *sys, DB *db, DBConfig *conf){
  char button_msg[0xff], handle_num[10 + 1];

  if(strcmp(db->mode, "admin") && db->num != 0) sprintf(handle_num, "(%d)", db->num);
  else strcpy(handle_num, "");
  sprintf(button_msg, "Execute '%s%s' operation", db->mode, handle_num);

  headHtml(sys, conf);

  printf("<table border=0>\n");

  printf("<form method='post' action='%s'>\n", sys->ProgramName);
  printf("  <input type='hidden' name='db'         value='%s'>\n", db->db);
  printf("  <input type='hidden' name='mode'       value='%s'>\n", db->mode);
  printf("  <input type='hidden' name='num'        value='%d'>\n", db->num);
  printf("  <input type='hidden' name='page'       value='%d'>\n", db->page);
  printf("  <input type='hidden' name='ftype'      value='%d'>\n", db->ftype);
  printf("  <input type='hidden' name='fval'       value='%s'>\n", db->fval);
  printf("  <input type='hidden' name='backdepth'  value='%d'>\n", db->backdepth + 1);

  printf("  <tr><td colspan=2>&nbsp;</td></tr>\n");

  printf("  <tr>\n");
  printf("    <td align=right><font size=2 face='arial'><B>P a s s w o r d</B></font></td>\n");
  printf("    <td align=left><font size=3><input type='password' name='password' size=20 maxlength=8></font></td>\n");
  printf("  </tr>\n");

  printf("  <tr><td colspan=2>&nbsp;</td></tr>\n");

  printf("  <tr>\n");
  printf("    <td align=center colspan=2><font size=2 face='����'><input type='submit' value=\"%s\"); return true;\"></font></td>\n", button_msg);
  printf("  </tr>\n");

  printf("  <tr><td colspan=2>&nbsp;</td></tr>\n");

  printf("  <tr>\n");
  printf("    <td align=center colspan=2><a href='javascript:history.back()' onMouseOver=\"window.status=('Go back'); return true;\"><img src='%s' border=0 alt='Back'></a></td>\n", sys->IconBack);
  printf("  </tr>\n");
  printf("</form>\n");
  printf("</table>\n");

  tailHtml(sys, conf);
  exit(0);
}

void cwb_admin(SysConfig *sys, DB *db, DBConfig *conf){
  int pass;
  pass = check_password(sys, db, conf);
  if(pass == PASS_ADMIN || pass == PASS_NOT_DEFINE) admin_form(sys, db, conf);
  else qError("Only administrator(%s) can access.", conf->AdminName);
}

void admin_form(SysConfig *sys, DB *db, DBConfig *conf){
  char *flag;
  char *submit_msg;

  /* �޽��� ���� */
  if(!strcmp(conf->Language, "korean")) submit_msg = "���δ� �ȳ��� ���ʽÿ�.";
  else                                  submit_msg = "Good bye my master.";

  headHtml(sys, conf);

  printf("\n<!-- Table -->\n");
  printf("<table border=0 width=80%%>\n");

  printf("\n<!-- Form -->\n");
  printf("<form method='post' action='%s' onSubmit=\"alert('%s');\">\n", sys->ProgramName, submit_msg);
    printf("  <input type='hidden' name='db' value='%s'>\n", db->db);
    printf("  <input type='hidden' name='mode' value='adminsave'>\n");
    if(db->password != NULL)printf("  <input type='hidden' name='password' value='%s'>\n", crypt(db->password, sys->CryptSalt));

  printf("\n<!-- Configuration -->\n");
    printf("  <tr><td colspan=2><hr size=1 noshade></td></tr>\n");

    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=2><font size=3 face='arial' color=black><b>Web Board Information</b></font></td></tr>\n");

    /* Password */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>New Password</b></font></td><td><input type='password' name='cPassword' size=8 maxlength=8> <font size=2 face='arial'><b>Re-enter Password</b></font> <input type='password' name='cPassword2' size=8 maxlength=8></td></tr>\n");

    /* Messsage */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Title Message</b></font></td><td><input type='text' name='cMessage' size=60 maxlength=800 value=\""); qPrintf(1, "%s", conf->Message); printf("\"></td></tr>\n");

    /* HomePage */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HomePage URL</b></font></td><td><input type='text' name='cHomeUrl' value='%s' size=40 maxlength=100> <font size=2 face='arial'><b>Target Frame</b></font> <input type='text' name='cHomeTarget' value='%s'size=10 maxlength=20></td></tr>\n", conf->HomeUrl, conf->HomeTarget);
    /* BackPage */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Back URL</b></font></td><td><input type='text' name='cBackUrl' value='%s' size=40 maxlength=100> <font size=2 face='arial'><b>Target Frame</b></font> <input type='text' name='cBackTarget' value='%s'size=10 maxlength=20></td></tr>\n", conf->BackUrl, conf->BackTarget);

    printf("  <tr><td colspan=2><hr size=1 noshade></td></tr>\n");

    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=2><font size=3 face='arial' color=black><b>Administrator Contact Information</b></font></td></tr>\n");

    /* Admin Name */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Administrator Name</b></font></td><td><input type='text' name='cAdminName' value='%s' size=60 maxlength=30></td></tr>\n", conf->AdminName);

    /* Admin Email */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Administrator E-mail</b></font></td><td><input type='text' name='cAdminEmail' value='%s' size=60 maxlength=60></td></tr>\n", conf->AdminEmail);

    /* MailToAdmin */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail to Administrator</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->MailToAdmin, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToAdmin' value='true' %s> Yes, I want to get a posting article by e-mail , ", flag);
    if(!strcmp(conf->MailToAdmin, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToAdmin' value='false' %s> No, don't do that", flag);
    printf("</font></td></tr>\n");

    /* MailToPoster */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail to Poster</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->MailToSender, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToSender' value='true' %s> Yes, post reply article to original poster by e-mail , ", flag);
    if(!strcmp(conf->MailToSender, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cMailToSender' value='false' %s> No, don't do that", flag);
    printf("</font></td></tr>\n");

    printf("  <tr><td colspan=2><hr size=1 noshade></td></tr>\n");

    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=2><font size=3 face='arial' color=black><b>Article Configuration</b></font></td></tr>\n");

    /* ListOrder */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>List Order</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->ListOrder, "date"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListOrder' value='date' %s> By date , ", flag);
    if(!strcmp(conf->ListOrder, "thread"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListOrder' value='thread' %s> By thread", flag);
    printf("</font></td></tr>\n");

    /* Name First */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Name First</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->NameFirst, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cNameFirst' value='true' %s> Locate name field before subject , ", flag);
    if(!strcmp(conf->NameFirst, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cNameFirst' value='false' %s> Locate name field after subject", flag);
    printf("</font></td></tr>\n");

    /* Article Number */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Article Number</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->ArticleNumber, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cArticleNumber' value='true' %s> Show article number , ", flag);
    if(!strcmp(conf->ArticleNumber, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cArticleNumber' value='false' %s> Hide article number", flag);
    printf("</font></td></tr>\n");

    /* Virtual Number */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Virtual Number</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->VirtualNumber, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cVirtualNumber' value='true' %s> I want to see relative virtual number , ", flag);
    if(!strcmp(conf->VirtualNumber, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cVirtualNumber' value='false' %s> I want to see physical number", flag);
    printf("</font></td></tr>\n");

    /* Folder Icon */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Folder Icon</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->FolderIcon, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cFolderIcon' value='true' %s> Show folder icon , ", flag);
    if(!strcmp(conf->FolderIcon, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cFolderIcon' value='false' %s> Hide folder icon", flag);
    printf("</font></td></tr>\n");

    /* Upload Enable */
    if(!strcmp(sys->AllowUpload, "true")) {
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>File Upload</b></font></td><td><font size=2 face='arial'>");
      if(!strcmp(conf->UploadEnable, "true"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUploadEnable' value='true' %s> Enable , ", flag);
      if(!strcmp(conf->UploadEnable, "false"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUploadEnable' value='false' %s> Disable", flag);
      printf("</font></td></tr>\n");
    }
    else {
      printf("  <input type='hidden' name='cUploadEnable' value='false'>\n");
    }    

    /* Type Icon */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>File type Icon</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->TypeIcon, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cTypeIcon' value='true' %s> Show file type icon , ", flag);
    if(!strcmp(conf->TypeIcon, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cTypeIcon' value='false' %s> Hide file type icon", flag);
    printf("</font></td></tr>\n");

    /* LinkTarget */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Link Target</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->LinkTarget, ""))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLinkTarget' value='' %s> Current Frame , ", flag);
    if(!strcmp(conf->LinkTarget, "_top"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLinkTarget' value='_top' %s> Full Screen", flag);
    printf("</font></td></tr>\n");

    /* Language */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>View Language</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->Language, "korean"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLanguage' value='korean' %s> Korean , ", flag);
    if(!strcmp(conf->Language, "english"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cLanguage' value='english' %s> English", flag);
    printf("</font></td></tr>\n");

    /* WriteMode */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Post Permission</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->WriteMode, "admin"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cWriteMode' value='admin' %s> Only administrator can write , ", flag);
    if(!strcmp(conf->WriteMode, "anybody"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cWriteMode' value='anybody' %s> Anybody can write", flag);
    printf("</font></td></tr>\n");

    /* HtmlAccept */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HTML Mode</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->HtmlAccept, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHtmlAccept' value='true' %s> Accept HTML , ", flag);
    if(!strcmp(conf->HtmlAccept, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHtmlAccept' value='false' %s> Ignore HTML & Auto Link", flag);
    printf("</font></td></tr>\n");

    /* Hide Search */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Hide Search</b></font></td><td><font size=2 face='arial'>");
    if(!strcmp(conf->HideSearch, "true"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHideSearch' value='true' %s> I want to disable search , ", flag);
    if(!strcmp(conf->HideSearch, "false"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cHideSearch' value='false' %s> I want to enable search", flag);
    printf("</font></td></tr>\n");

    /* Articles Per Page */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Articles / Page</b></font></td><td><input type='text' name='cArticlesPerPage' value='%d' size=10 maxlength=3></td></tr>\n", conf->ArticlesPerPage);
    printf("</table>\n");


    /****** User Interface ******/

    printf("<table border=0 width=80%%>\n");
    printf("  <tr><td colspan=4><hr size=1 noshade></td></tr>\n");

    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=4><font size=2 face='arial' color=black><b>User Interface / Common</b></font></td></tr>\n");

    if(!strcmp(sys->AllowDBhtml, "true")) {
      /* UseSysDefHtml, Head, Tail HTML */
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HTML Header, Tailer</b></font></td><td colspan=3><font size=2 face='arial'>");
      if(!strcmp(conf->UseSysDefHtml, "true"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUseSysDefHtml' value='true' %s>I want to use system default , ", flag);
      if(!strcmp(conf->UseSysDefHtml, "false"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUseSysDefHtml' value='false' %s> I want to use my own html below", flag);
      printf("</font></td></tr>\n");

      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HTML Header</b></font></td>\n");
      printf("      <td colspan=3><textarea name='cHtmlHead' cols=60 rows=4>"); qPuts(1, conf->HtmlHead); printf("</textarea></td></tr>\n");
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>HTML Tailer</b></font></td>\n");
      printf("      <td colspan=3><textarea name='cHtmlTail' cols=60 rows=4>"); qPuts(1, conf->HtmlTail); printf("</textarea></td></tr>\n");
    }
    else {
      printf("  <input type='hidden' name='cUseSysDefHtml' value='true'>\n");
      printf("  <input type='hidden' name='cHtmlHead' value=''>\n");
      printf("  <input type='hidden' name='cHtmlTail' value=''>\n");
    }    

    /* Default Text */
    printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Default Text</b></font></td>\n");
    printf("      <td colspan=3><textarea name='cDefaultText' cols=60 rows=4>"); qPuts(1, conf->DefaultText); printf("</textarea></td></tr>\n");

    /***************** List Modele *********************/
    /* hr line */
    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=4><font size=2 face='arial' color=black><b>User Interface / List Module</b></font></td></tr>\n");

    /* Border Size */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Border Size</b></font></td><td colspan=3><font size=2 face='arial'>");
    if(!strcmp(conf->ListBorderSize, "0"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='0' %s> None , ", flag);
    if(!strcmp(conf->ListBorderSize, "1"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='1' %s> Thin , ", flag);
    if(!strcmp(conf->ListBorderSize, "2"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='2' %s> Light medium , ", flag);
    if(!strcmp(conf->ListBorderSize, "3"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='3' %s> Medium , ", flag);
    if(!strcmp(conf->ListBorderSize, "4"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='4' %s> Heavy , ", flag);
    if(!strcmp(conf->ListBorderSize, "5"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListBorderSize' value='5' %s> Very heavy", flag);
    printf("</font></td></tr>\n");

    /* Font Size */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Font Size</b></font></td><td colspan=3><font size=2 face='arial'>");
    if(!strcmp(conf->ListFontSize, "2"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListFontSize' value='2' %s> General , ", flag);
    if(!strcmp(conf->ListFontSize, "3"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListFontSize' value='3' %s> Big , ", flag);
    if(!strcmp(conf->ListFontSize, "4"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cListFontSize' value='4' %s> Huge", flag);
    printf("</font></td></tr>\n");

    /* Title Font Color, Bg Color */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Title Font Color</b></font></td><td><input type='text' name='cListTitleFontColor' value='%s' size=16 maxlength=10></td>\n", conf->ListTitleFontColor);
    printf("      <td align=center><font size=2 face='arial'><b>Title Bg Color</b></font></td><td><input type='text' name='cListTitleBgColor' value='%s' size=16 maxlength=10></td></tr>\n", conf->ListTitleBgColor);

    /* Article Font Color, Bg Color */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Article Font Color</b></font></td><td><input type='text' name='cListArticleFontColor' value='%s' size=16 maxlength=10></td>\n", conf->ListArticleFontColor);
    printf("      <td align=center><font size=2 face='arial'><b>Article Bg Color</b></font></td><td><input type='text' name='cListArticleBgColor' value='%s' size=16 maxlength=10></td></tr>\n", conf->ListArticleBgColor);

    /***************** Read Modele *********************/
    /* hr line */
    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=4><font size=2 face='arial' color=black><b>User Interface / Read Module</b></font></td></tr>\n");

    /* TitleBorder Size */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Title Border Size</b></font></td><td colspan=3><font size=2 face='arial'>");
    if(!strcmp(conf->ReadTitleBorderSize, "0"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='0' %s> None , ", flag);
    if(!strcmp(conf->ReadTitleBorderSize, "1"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='1' %s> Thin , ", flag);
    if(!strcmp(conf->ReadTitleBorderSize, "2"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='2' %s> Light medium , ", flag);
    if(!strcmp(conf->ReadTitleBorderSize, "3"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='3' %s> Medium , ", flag);
    if(!strcmp(conf->ReadTitleBorderSize, "4"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='4' %s> Heavy , ", flag);
    if(!strcmp(conf->ReadTitleBorderSize, "5"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTitleBorderSize' value='5' %s> Very heavy", flag);
    printf("</font></td></tr>\n");

    /* TextBorder Size */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Text Border Size</b></font></td><td colspan=3><font size=2 face='arial'>");
    if(!strcmp(conf->ReadTextBorderSize, "0"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='0' %s> None , ", flag);
    if(!strcmp(conf->ReadTextBorderSize, "1"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='1' %s> Thin , ", flag);
    if(!strcmp(conf->ReadTextBorderSize, "2"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='2' %s> Light medium , ", flag);
    if(!strcmp(conf->ReadTextBorderSize, "3"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='3' %s> Medium , ", flag);
    if(!strcmp(conf->ReadTextBorderSize, "4"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='4' %s> Heavy , ", flag);
    if(!strcmp(conf->ReadTextBorderSize, "5"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadTextBorderSize' value='5' %s> Very heavy", flag);
    printf("</font></td></tr>\n");

    /* Font Size */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Font Size</b></font></td><td colspan=3><font size=2 face='arial'>");
    if(!strcmp(conf->ReadFontSize, "2"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadFontSize' value='2' %s> General , ", flag);
    if(!strcmp(conf->ReadFontSize, "3"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadFontSize' value='3' %s> Big , ", flag );
    if(!strcmp(conf->ReadFontSize, "4"))flag = "checked"; else flag = "";
    printf("<input type='radio' name='cReadFontSize' value='4' %s> Huge", flag);
    printf("</font></td></tr>\n");

    /* Read Title Font Color, Bg Color */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Title Font Color</b></font></td><td><input type='text' name='cReadTitleFontColor' value='%s' size=16 maxlength=10></td>\n", conf->ReadTitleFontColor);
    printf("      <td align=center><font size=2 face='arial'><b>Title Bg Color</b></font></td><td><input type='text' name='cReadTitleBgColor' value='%s' size=16 maxlength=10></td></tr>\n", conf->ReadTitleBgColor);

    /* Read Text Font, Bg Color */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Text Font Color</b></font></td><td><input type='text' name='cReadTextFontColor' value='%s' size=16 maxlength=10></td>\n", conf->ReadTextFontColor);
    printf("      <td align=center><font size=2 face='arial'><b>Text Bg Color</b></font></td><td><input type='text' name='cReadTextBgColor' value='%s' size=16 maxlength=10></td></tr>\n", conf->ReadTextBgColor);

    /* Read Text Font Type */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Text Font Type</b></font></td><td><input type='text' name='cReadTextFontType' value='%s' size=16 maxlength=16></td>\n", conf->ReadTextFontType);

    /***************** Write Modele *********************/
    /* hr line */
    printf("  <tr><td bgcolor=f0f0f0 align=center colspan=4><font size=2 face='arial' color=black><b>User Interface / Write Module</b></font></td></tr>\n");

    /* Title Font Color, Bg Color */
    printf("  <tr><td align=center><font size=2 face='arial'><b>Title Font Color</b></font></td><td><input type='text' name='cWriteTitleFontColor' value='%s' size=16 maxlength=10></td>\n", conf->WriteTitleFontColor);
    printf("      <td align=center><font size=2 face='arial'><b>Title Bg Color</b></font></td><td><input type='text' name='cWriteTitleBgColor' value='%s' size=16 maxlength=10></td></tr>\n", conf->WriteTitleBgColor);


    if(!strcmp(sys->AllowDBmail, "true")) {
      /***************** Mail Modele *********************/
      /* hr line */
      printf("  <tr><td bgcolor=f0f0f0 align=center colspan=4><font size=2 face='arial' color=black><b>User Interface / Mail Module</b></font></td></tr>\n");

      /* UseSysDefMail */
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail Header, Tailer</b></font></td><td colspan=3><font size=2 face='arial'>");
      if(!strcmp(conf->UseSysDefMail, "true"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUseSysDefMail' value='true' %s>I want to use system default , ", flag);
      if(!strcmp(conf->UseSysDefMail, "false"))flag = "checked"; else flag = "";
      printf("<input type='radio' name='cUseSysDefMail' value='false' %s> I want to use my own signature below", flag);
      printf("</font></td></tr>\n");

      /* Head, Tail Textarea*/
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail Header</b></font></td>\n");
      printf("      <td colspan=3><textarea name='cMailHead' cols=60 rows=4>"); qPuts(1, conf->MailHead); printf("</textarea></td></tr>\n");
      printf("  <tr><td bgcolor=f0f0f0 align=center><font size=2 face='arial'><b>Mail Tailer</b></font></td>\n");
      printf("      <td colspan=3><textarea name='cMailTail' cols=60 rows=4>"); qPuts(1, conf->MailTail); printf("</textarea></td></tr>\n");
    }
    else {
      printf("  <input type='hidden' name='cUseSysDefMail' value='true'>\n");
      printf("  <input type='hidden' name='cMailHead' value=''>\n");
      printf("  <input type='hidden' name='cMailTail' value=''>\n");
    }    

    printf("  <tr><td colspan=4><hr size=1 noshade></td></tr>\n");

    printf("</table>\n");

    printf("<table border=0 width=80%%>\n");
    printf("  <tr><td align=left>");
    printf("      <font size=2 face='����'>\n");
    printf("      <input type='reset' value='  Reset  '>\n");
    printf("      </font>\n");
    printf("      </td>\n");

    printf("      <td align=center>\n");
    printf("      <font size=2 face='����'>\n");
    printf("      <input type='submit' value='                    S a v e                    '>\n");
    printf("      </font>\n");
    printf("      </td>\n");

    printf("      <td align=right>\n");
    printf("      <a href='javascript:history.go(-%d)'  onMouseOver=\"window.status=('Back to the list'); return true;\"><img src='%s' border=0 alt='List'></a>\n", db->backdepth, sys->IconList);
    printf("      </td>\n");
    printf("  </tr>\n");

  printf("</form>\n");
  printf("</table>\n");

  printf("\n<!-- alert -->\n");
  printf("<script language='JavaScript'>\n");
  if(db->password == NULL) { /* ó�� ���� */
    printf("  alert('Welcome my NEW MASTER. This is our first meeting, so please tell me your NAME and your E-MAIL, then I will send new articles to you by email. Please remember I am your forever slave.');\n");
  }
  else { /* ������ */
    if(!strcmp(conf->Language, "korean"))
      printf("  alert('%s ���δ� �ٽú˰ԵǾ� �ݰ����ϴ�. ������ ���� �帱���?');\n", conf->AdminName);
    else
      printf("  alert('Thank you for your visiting my forever master %s. How about your condition.');\n", conf->AdminName);
  }
  printf("</script>\n");

  tailHtml(sys, conf);
}


void cwb_adminsave(SysConfig *sys, DB *db, DBConfig *conf){
  int pass;
  char buf[0xFF];

  pass = check_password(sys, db, conf);  

  if(pass == PASS_NOT_DEFINE && !strcmp("", qRemoveSpace(qValue("cPassword"))))qError("You must specify the password, when you configure a db at first time.");

  if(strcmp(qValue("cPassword"), qRemoveSpace(qValue("cPassword2"))))qError("Two passwords must be same.");

  if(!strcmp(qRemoveSpace(qValue("cAdminName")), ""))  qError("The field for the administrator's name must be specify.");

  if(!strcmp(qRemoveSpace(qValue("cAdminEmail")), "")) qError("The field for the administrator's e-mail must be specify.");

  if(qCheckEmail(qRemoveSpace(qValue("cAdminEmail"))) == 0) qError("Administrator's e-mail address is incorrect.");
  
  sprintf(buf, "%s/%s.%s", sys->DataDirectory, db->db, sys->DataExtension);
  DBOpen(buf, GDBM_WRITER);

  if(strcmp(qValue("cPassword"), ""))DBStore("conf.Password", crypt(qValue("cPassword"), sys->CryptSalt), GDBM_REPLACE);
  DBStore("conf.Message", qValue("cMessage"), GDBM_REPLACE);

  DBStore("conf.HomeUrl",    qValue("cHomeUrl"), GDBM_REPLACE);
  DBStore("conf.HomeTarget", qValue("cHomeTarget"), GDBM_REPLACE);
  DBStore("conf.BackUrl",    qValue("cBackUrl"), GDBM_REPLACE);
  DBStore("conf.BackTarget", qValue("cBackTarget"), GDBM_REPLACE);

  DBStore("conf.AdminName",    qValue("cAdminName"), GDBM_REPLACE);
  DBStore("conf.AdminEmail",   qValue("cAdminEmail"), GDBM_REPLACE);
  DBStore("conf.MailToAdmin",  qValue("cMailToAdmin"), GDBM_REPLACE);
  DBStore("conf.MailToSender", qValue("cMailToSender"), GDBM_REPLACE);

  DBStore("conf.ListOrder",       qValue("cListOrder"), GDBM_REPLACE);
  DBStore("conf.NameFirst",       qValue("cNameFirst"), GDBM_REPLACE);
  DBStore("conf.ArticleNumber",   qValue("cArticleNumber"), GDBM_REPLACE);
  DBStore("conf.VirtualNumber",   qValue("cVirtualNumber"), GDBM_REPLACE);
  DBStore("conf.FolderIcon",      qValue("cFolderIcon"), GDBM_REPLACE);
  DBStore("conf.UploadEnable",    qValue("cUploadEnable"), GDBM_REPLACE);
  DBStore("conf.TypeIcon",        qValue("cTypeIcon"), GDBM_REPLACE);
  DBStore("conf.LinkTarget",      qValue("cLinkTarget"), GDBM_REPLACE);
  DBStore("conf.Language",        qValue("cLanguage"), GDBM_REPLACE);
  DBStore("conf.WriteMode",       qValue("cWriteMode"), GDBM_REPLACE);
  DBStore("conf.HtmlAccept",      qValue("cHtmlAccept"), GDBM_REPLACE);
  DBStore("conf.HideSearch",      qValue("cHideSearch"), GDBM_REPLACE);
  DBStore("conf.ArticlesPerPage", qValue("cArticlesPerPage"), GDBM_REPLACE);

  DBStore("conf.UseSysDefHtml",   qValue("cUseSysDefHtml"), GDBM_REPLACE);
  DBStore("conf.HtmlHead",        qValue("cHtmlHead"), GDBM_REPLACE);
  DBStore("conf.HtmlTail",        qValue("cHtmlTail"), GDBM_REPLACE);
  DBStore("conf.DefaultText",     qValue("cDefaultText"), GDBM_REPLACE);

  DBStore("conf.ListBorderSize",       qValue("cListBorderSize"), GDBM_REPLACE);
  DBStore("conf.ListFontSize",         qValue("cListFontSize"), GDBM_REPLACE);
  DBStore("conf.ListTitleFontColor",   qValue("cListTitleFontColor"), GDBM_REPLACE);
  DBStore("conf.ListTitleBgColor",     qValue("cListTitleBgColor"), GDBM_REPLACE);
  DBStore("conf.ListArticleFontColor", qValue("cListArticleFontColor"), GDBM_REPLACE);
  DBStore("conf.ListArticleBgColor",   qValue("cListArticleBgColor"), GDBM_REPLACE);

  DBStore("conf.ReadTitleBorderSize",  qValue("cReadTitleBorderSize"), GDBM_REPLACE);
  DBStore("conf.ReadTextBorderSize",   qValue("cReadTextBorderSize"), GDBM_REPLACE);
  DBStore("conf.ReadFontSize",         qValue("cReadFontSize"), GDBM_REPLACE);
  DBStore("conf.ReadTitleFontColor",   qValue("cReadTitleFontColor"), GDBM_REPLACE);
  DBStore("conf.ReadTitleBgColor",     qValue("cReadTitleBgColor"), GDBM_REPLACE);
  DBStore("conf.ReadTextFontColor",    qValue("cReadTextFontColor"), GDBM_REPLACE);
  DBStore("conf.ReadTextBgColor",      qValue("cReadTextBgColor"), GDBM_REPLACE);
  DBStore("conf.ReadTextFontType",     qValue("cReadTextFontType"), GDBM_REPLACE);

  DBStore("conf.WriteTitleFontColor",   qValue("cWriteTitleFontColor"), GDBM_REPLACE);
  DBStore("conf.WriteTitleBgColor",     qValue("cWriteTitleBgColor"), GDBM_REPLACE);

  DBStore("conf.UseSysDefMail",   qValue("cUseSysDefMail"), GDBM_REPLACE);
  DBStore("conf.MailHead",        qValue("cMailHead"), GDBM_REPLACE);
  DBStore("conf.MailTail",        qValue("cMailTail"), GDBM_REPLACE);

  DBClose();
}

