#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "gdbm.h"
#include "qDecoder.h"
#include "cwb.h"
#include "cwb_db.h"

void main(int argc, char *argv[]) {
  Entry *real;
  char filename[0xff];
  char *dataDirectory, *dataExtension;
  int  flag;

  real = qfDecoder(REALTIME_CONFIG_FILE);
  if(real == NULL) {
    printf("Realtime configuration file(%s) not found.\n", filename);
    exit(1);
  }
  else {
    dataDirectory = qfValue(real, "DataDirectory");
    dataExtension = qfValue(real, "DataExtension");
    if(dataDirectory == NULL) {
      printf("There is no 'DataDirectory' entry in the %s file.\n", REALTIME_CONFIG_FILE);
      exit(1);
    }
    if(dataExtension == NULL) {
      printf("There is no 'DataExtension' entry in the %s file.\n", REALTIME_CONFIG_FILE);
      exit(1);
    }
  }
  if(argc != 2) {
    printf("Usages : createDB DB-NAME\n");
    exit(1);
  }

  if(qStr09AZaz(argv[1]) == 0 ) {
    printf("Only regular expression is allowed for the database name\n");
    exit(1);
  }

  sprintf(filename, "%s/%s.%s", dataDirectory, argv[1], dataExtension);

  flag = DBCreate(filename, 0644);

  chmod(filename, (unsigned short)atoi(qfValue(real, "FilePermission")));

  if(flag == TRUE) printf("DB(%s) created.\n", filename);
  else printf("DB(%s) creation failed\n", filename);

}

