<html>
<head>

<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ ��㹮�� ]          </title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="global.css">

<script language="JavaScript" src="global.js"></script>

<script language="JavaScript">
<!--
function send_check() {
	var form = document.mail;
	
	if(!form.sender.value){
		alert('������ ��� �̸��� �Է����� �ʾҽ��ϴ�.');
		form.sender.focus();
		return;
	}

	if(!form.sender_email.value){
		alert('������ ��� �̸����� �Է����� �ʾҽ��ϴ�.');
		form.sender_email.focus();
		return;
	}

	if(!form.subject.value){
		alert('���� ������ �Է����� �ʾҽ��ϴ�.');
		form.subject.focus();
		return;
	}

	if(!form.contents.value){
		alert('�߼� ������ �Է����� �ʾҽ��ϴ�.');
		form.contents.focus();
		return;
	}
	form.submit();
}
//-->
</script>
</head>



<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<form method='post' name='mail' action='mail_form_send.php' enctype="multipart/form-data">


<table border="0" width="756" align="center" bgcolor="white">
        <tr>
            <td width="750">
                <table border="0" width="750" height="178">
                    <tr>
                        <td width="744" height="174">
                            <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                            <param name="movie" value="../swf/k_menu.swf">
                            <param name="play" value="true">
                            <param name="loop" value="true">
                            <param name="quality" value="high">
                            <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/k_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                        </td>
                    </tr>
                </table>
                <p>&nbsp;</p>
                <table border="0" width="750">
                    <tr>
                        <td width="50">&nbsp;</td>
                        <td width="50">
                            <p align="center"><img src="../images/Title_Point.GIF" width="28" height="27" border="0"></p>
                        </td>
                        <td width="582"><b><font size="4">�� �� �� ��</font></b></td>
                        <td width="50">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="50">&nbsp;</td>
                        <td width="636" colspan="2">
                            <hr>
                        </td>
                        <td width="50">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="50">&nbsp;</td>
                        <td width="636" colspan="2">&nbsp;</td>
                        <td width="50">&nbsp;</td>
                    </tr>
                </table>
                <table border="0" width="750">
                    <tr>
                        <td width="50">&nbsp;</td>
                        <td width="636">
                            <table width="95%" border="1" cellspacing="0" cellpadding="3" bordercolordark="#FFFFFF" align="center">
                                <tr>
                                    <td align=center width="600">
                                        <table width="97%" border="0" cellspacing="0" cellpadding="0" height="102%" align="center">
                                            <tr>
                                                <td width="580" height="272">
                                                    <div align="left">
                                                        <table width="98%" border="0" cellspacing="1" cellpadding="4" height="385">
                                                            <tr>
                                                                <td bgcolor="#ebe9f5" width="100"  align="center" height="18">
                                                                    <p align="center"><span style="font-size:11pt;">������ ���</span></p>
                                                                </td>
                                                                <td bgcolor="#FFFFFF" width="445"  align="left" height="18">
		 <input type='text' size="34" name="sender">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td bgcolor="#ebe9f5" width="100"  align="center" height="8">
                                                                    <p align="center"><span style="font-size:11pt;">E - m a i l</span></p>
                                                                </td>
                                                                <td bgcolor="#FFFFFF" width="445"  align="left" height="8">
		 <input type='text' size="63" name="sender_email">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td bgcolor="#ebe9f5" width="100"  align="center" height="33">
                                                                    <p align="center"><span style="font-size:11pt;">÷ �� �� ��</span></p>
                                                                </td>
                                                                <td bgcolor="#FFFFFF" width="445"  align="left" height="33">
		   <input type='file' size="49" name="userfile">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td bgcolor="#ebe9f5" width="100"  align="center">
                                                                    <p align="center"><span style="font-size:11pt;">�� �� �� ��</span></p>
                                                                </td>
                                                                <td bgcolor="#FFFFFF" width="445"  align="left">
		   <input type='text' size="63" name="subject">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td bgcolor="#ebe9f5" width="100"  align="center" height="187">
                                                                    <p align="center"><span style="font-size:11pt;">�� �� �� ��</span></p>
                                                                </td>
                                                                <td bgcolor="#FFFFFF" width="445"  align="left" height="187">
                                                                    <p align="left">		  <textarea name="contents" cols="63" rows="12"></textarea>
</p>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr bgcolor='#FFFFFF'>
                                    <td align='right' width="600">
                                        <p align="right">     <input type='button' value=" �� �� �� �� " onclick="javascript:send_check()">
&nbsp;&nbsp;&nbsp;	 <input type='reset' value=" �� �� �� �� ">
 &nbsp;</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        <td width="50">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="50">&nbsp;</td>
                        <td width="636">&nbsp;</td>
                        <td width="50">&nbsp;</td>
                    </tr>
                </table>
                <p>&nbsp;</p>
                <table border="0" width="750" height="100">
                    <tr>
                        <td width="744" colspan="2">
                            <hr>
                        </td>
                    </tr>
                    <tr>
                        <td width="636" height="22">
                            <p align="center">&nbsp;</p>
                        </td>
                        <td width="103" height="22">
                            <p align="center"><font size="2" color="blue"><a href="#" target="_self"><b>~ T o p&nbsp;~</b></a></font></p>
                        </td>
                    </tr>
                    <tr>
                        <td width="744" height="52" bgcolor="#F0F1F8" colspan="2">
                            <address align="center"><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��õ������ ���� ûõ�� 412-1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tel : (032) 516-2211 &nbsp;&nbsp;&nbsp;&nbsp;Fax : (032) 516-2246</font></b></address>
                            <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
</table>

</form>
</body>
</html>