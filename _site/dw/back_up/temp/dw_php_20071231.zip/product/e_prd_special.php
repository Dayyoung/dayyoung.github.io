<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ ��ǰ�Ұ� ]          </title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


<STYLE>
<!--
A.ssmItems:link	{color:black;text-decoration:none;}
A.ssmItems:hover	{color:black;text-decoration:none;}
A.ssmItems:active	{color:black;text-decoration:none;}
A.ssmItems:visited	{color:black;text-decoration:none;}
//-->
</STYLE>


<SCRIPT language="JavaScript1.2">
NS6 = (document.getElementById&&!document.all)
IE = (document.all)
NS = (navigator.appName=="Netscape" && navigator.appVersion.charAt(0)=="4")

tempBar='';barBuilt=0;ssmItems=new Array();

moving=setTimeout('null',1)
function moveOut() {
if ((NS6||NS)&&parseInt(ssm.left)<0 || IE && ssm.pixelLeft<0) {
clearTimeout(moving);moving = setTimeout('moveOut()', slideSpeed);slideMenu(10)}
else {clearTimeout(moving);moving=setTimeout('null',1)}};
function moveBack() {clearTimeout(moving);moving = setTimeout('moveBack1()', waitTime)}
function moveBack1() {
if ((NS6||NS) && parseInt(ssm.left)>(-menuWidth) || IE && ssm.pixelLeft>(-menuWidth)) {
clearTimeout(moving);moving = setTimeout('moveBack1()', slideSpeed);slideMenu(-10)}
else {clearTimeout(moving);moving=setTimeout('null',1)}}
function slideMenu(num){
if (IE) {ssm.pixelLeft += num;}
if (NS||NS6) {ssm.left = parseInt(ssm.left)+num;}
if (NS) {bssm.clip.right+=num;bssm2.clip.right+=num;}}

function makeStatic() {
if (NS||NS6) {winY = window.pageYOffset;}
if (IE) {winY = document.body.scrollTop;}
if (NS6||IE||NS) {
if (winY!=lastY&&winY>YOffset-staticYOffset) {
smooth = .2 * (winY - lastY - YOffset + staticYOffset);}
else if (YOffset-staticYOffset+lastY>YOffset-staticYOffset) {
smooth = .2 * (winY - lastY - (YOffset-(YOffset-winY)));}
else {smooth=0}
if(smooth > 0) smooth = Math.ceil(smooth);
else smooth = Math.floor(smooth);
if (IE) bssm.pixelTop+=smooth;
if (NS6||NS) bssm.top=parseInt(bssm.top)+smooth
lastY = lastY+smooth;
setTimeout('makeStatic()', 1)}}

function buildBar() {
if(barText.indexOf('<IMG')>-1) {tempBar=barText}
else{for (b=0;b<barText.length;b++) {tempBar+=barText.charAt(b)+"<BR>"}}
document.write('<td align="center" rowspan="100" width="'+barWidth+'" bgcolor="'+barBGColor+'" valign="'+barVAlign+'"><p align="center"><font face="'+barFontFamily+'" Size="'+barFontSize+'" COLOR="'+barFontColor+'"><B>'+tempBar+'</B></font></p></TD>')}

function initSlide() {
if (NS6){ssm=document.getElementById("thessm").style;bssm=document.getElementById("basessm").style;
bssm.clip="rect(0 "+document.getElementById("thessm").offsetWidth+" "+document.getElementById("thessm").offsetHeight+" 0)";ssm.visibility="visible";}
else if (IE) {ssm=document.all("thessm").style;bssm=document.all("basessm").style
bssm.clip="rect(0 "+thessm.offsetWidth+" "+thessm.offsetHeight+" 0)";bssm.visibility = "visible";}
else if (NS) {bssm=document.layers["basessm1"];
bssm2=bssm.document.layers["basessm2"];ssm=bssm2.document.layers["thessm"];
bssm2.clip.left=0;ssm.visibility = "show";}
if (menuIsStatic=="yes") makeStatic();}

function buildMenu() {
if (IE||NS6) {document.write('<DIV ID="basessm" style="visibility:hidden;Position : Absolute ;Left : '+XOffset+' ;Top : '+YOffset+' ;Z-Index : 20;width:'+(menuWidth+barWidth+10)+'"><DIV ID="thessm" style="Position : Absolute ;Left : '+(-menuWidth)+' ;Top : 0 ;Z-Index : 20;" onmouseover="moveOut()" onmouseout="moveBack()">')}
if (NS) {document.write('<LAYER name="basessm1" top="'+YOffset+'" LEFT='+XOffset+' visibility="show"><ILAYER name="basessm2"><LAYER visibility="hide" name="thessm" bgcolor="'+menuBGColor+'" left="'+(-menuWidth)+'" onmouseover="moveOut()" onmouseout="moveBack()">')}
if (NS6){document.write('<table border="0" cellpadding="0" cellspacing="0" width="'+(menuWidth+barWidth+2)+'" bgcolor="'+menuBGColor+'"><TR><TD>')}
document.write('<table border="0" cellpadding="0" cellspacing="1" width="'+(menuWidth+barWidth+2)+'" bgcolor="'+menuBGColor+'">');
for(i=0;i<ssmItems.length;i++) {
if(!ssmItems[i][3]){ssmItems[i][3]=menuCols;ssmItems[i][5]=menuWidth-1}
else if(ssmItems[i][3]!=menuCols)ssmItems[i][5]=Math.round(menuWidth*(ssmItems[i][3]/menuCols)-1);
if(ssmItems[i-1]&&ssmItems[i-1][4]!="no"){document.write('<TR>')}
if(!ssmItems[i][1]){
document.write('<td bgcolor="'+hdrBGColor+'" HEIGHT="'+hdrHeight+'" ALIGN="'+hdrAlign+'" VALIGN="'+hdrVAlign+'" WIDTH="'+ssmItems[i][5]+'" COLSPAN="'+ssmItems[i][3]+'"> <font face="'+hdrFontFamily+'" Size="'+hdrFontSize+'" COLOR="'+hdrFontColor+'"><b>'+ssmItems[i][0]+'</b></font></td>')}
else {if(!ssmItems[i][2])ssmItems[i][2]=linkTarget;
document.write('<TD BGCOLOR="'+linkBGColor+'" onmouseover="bgColor=\''+linkOverBGColor+'\'" onmouseout="bgColor=\''+linkBGColor+'\'" WIDTH="'+ssmItems[i][5]+'" COLSPAN="'+ssmItems[i][3]+'"><ILAYER><LAYER onmouseover="bgColor=\''+linkOverBGColor+'\'" onmouseout="bgColor=\''+linkBGColor+'\'" WIDTH="100%" ALIGN="'+linkAlign+'"><DIV  ALIGN="'+linkAlign+'"><FONT face="'+linkFontFamily+'" Size="'+linkFontSize+'"> <A HREF="'+ssmItems[i][1]+'" target="'+ssmItems[i][2]+'" CLASS="ssmItems">'+ssmItems[i][0]+'</DIV></LAYER></ILAYER></TD>')}
if(ssmItems[i][4]!="no"&&barBuilt==0){buildBar();barBuilt=1}
if(ssmItems[i][4]!="no"){document.write('</TR>')}}
document.write('</table>')
if (NS6){document.write('</TD></TR></TABLE>')}
if (IE||NS6) {document.write('</DIV></DIV>')}
if (NS) {document.write('</LAYER></ILAYER></LAYER>')}
theleft=-menuWidth;lastY=0;setTimeout('initSlide();', 1)}
</SCRIPT>


<SCRIPT language="JavaScript1.2">
<!--
/*
Configure menu styles below
NOTE: To edit the link colors, go to the STYLE tags and edit the ssm2Items colors
*/
YOffset=200; // no quotes!!
XOffset=0;
staticYOffset=30; // no quotes!!
slideSpeed=20 // no quotes!!
waitTime=100; // no quotes!! 
menuBGColor="black";
menuIsStatic="yes"; 
menuWidth=120; // Must be a multiple of 10! no quotes!!
menuCols=2;
hdrFontFamily="verdana";
hdrFontSize="2";
hdrFontColor="#000099";
hdrBGColor="#00CCFF";
hdrAlign="center";
hdrVAlign="center";
hdrHeight="15";
linkFontFamily="Verdana";
linkFontSize="2";
linkBGColor="white";
linkOverBGColor="#CCFFFF";
linkTarget="_top";
linkAlign="center";
barBGColor="#00CCFF";  
barFontFamily="Verdana";
barFontSize="2";
barFontColor="#000099";
barVAlign="center";
barWidth=20; // no quotes!!
barText=" M   E   N   U "; 

///////////////////////////

// ssmItems[...]=[name, link, target, colspan, endrow?] 
ssmItems[0]=["Product Information"] //create header
ssmItems[1]=["Bag Product", "http://www.daewon-ind.co.kr/product/e_prd_bag.php", "_self"]
ssmItems[2]=["Pouch Product", "http://www.daewon-ind.co.kr/product/e_prd_pouch.php","_self"]
ssmItems[3]=["Roll Procuct", "http://www.daewon-ind.co.kr/product/e_prd_roll.php", "_self"]
ssmItems[4]=["LLDPE Film", "http://www.daewon-ind.co.kr/product/e_prd_lldpe.php", "_self"]
ssmItems[5]=["Characteristic of Material", "http://www.daewon-ind.co.kr/product/e_prd_special.php", "_self"]
buildMenu();
//-->
</SCRIPT>

</head>



<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="754" height="178">
                <tr>
                    <td width="748" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/e_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/e_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="1" width="714" height="858" align="center">
                <tr>
                    <td width="704" colspan="5" height="54">
                        <p align="center"><b><span style="font-size:16pt;">Table or Comparison of Strengths and Weakness by Material</span></b></p>
                    </td>
                </tr>
                <tr>
                    <td width="80" height="54">
                        <p align="center"><b><font size="3">&nbsp;</font></b></p>
                    </td>
                    <td width="120" bgcolor="#CCCCCC" height="54">
                        <p align=center><b><font size="2" color="black">Manufacturing Methods</font></b></p>
                    </td>
                    <td width="160" bgcolor="#CCCCCC" height="54">
                        <p align=center><b><font size="2" color="black">Features</font></b></p>
                    </td>
                    <td width="160" bgcolor="#CCCCCC" height="54">
                        <p align=center><b><font size="2" color="black">Weakness</font></b></p>
                    </td>
                    <td width="160" bgcolor="#CCCCCC" height="54">
                        <p align=center><b><font size="2" color="black">Usage</font></b></p>
                    </td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">LDPE</font></b></p>
                    </td>
                    <td width="120">
                        <p align="center"><span style="font-size:10pt;">Inflation</span></p>
                    </td>
                    <td width="160"><font size="2">&nbsp;1) Cheap<br>
                  &nbsp;2) Low specific gravity<br>
                  &nbsp;3) Flexibility<br>
                  &nbsp;4) Low brittleness &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;temperature <br>
                  &nbsp;5) Waterproof, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;moisture-proof<br>
                  &nbsp;6) chemistry- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance<br>
                  &nbsp;7) No smell, poison<br>
                  &nbsp;8) Excellent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;processability <br>
                  &nbsp;9) Excellent heat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;welding</font></td>
                    <td width="160"><font size="2">&nbsp;1) Low softening point <br>
                  &nbsp;2) High gas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;transmission<br>
                  &nbsp;3) Low transparency <br>
                  &nbsp;4) Low tensile strength <br>
                  &nbsp;5) Low oil resistance <br>
                  &nbsp;6) Low adhesion effect<br>
                  &nbsp;7) Corona processing &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;required</font></td>
                    <td width="160"><font size="2">&nbsp;1) Food package <br>
                  &nbsp;2) Frozen food &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;package<br>
                  &nbsp;3) Vegetable, meat<br>
                  &nbsp;4) Shrinkage package</font></td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">HDPE</font></b></p>
                    </td>
                    <td width="120">
                        <p align="center"><span style="font-size:10pt;">Inflation</span></p>
                    </td>
                    <td width="160">
                        <p><font size="2">&nbsp;1) Cheap<br>
                  &nbsp;2) Paper feel<br>
                  &nbsp;3) High tensile &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;strength </font></p>
                        <p><font size="2">&nbsp;4) High openness <br>
                  &nbsp;5) Vigorous<br>
                  &nbsp;6) Heat resistance &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(120~135'C)<br>
                  &nbsp;7) Excellent moisture- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;proof<br>
                  &nbsp;8) Excellent chemistry- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance<br>
                  &nbsp;9) Good oil resistance</font></p>
                    </td>
                    <td width="160">
                        <p><font size="2">&nbsp;1) Milky, semi- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;transparency<br>
                    &nbsp;2) High processing &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;temperature (than &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LDPE)<br>
                    &nbsp;3) Low adhesion effect<br>
                    &nbsp;4) Metallic sound when &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;holding</font></p>
                    </td>
                    <td width="160"><font size="2">&nbsp;1) Handy shopping bag<br>
                  &nbsp;2) Fruit bag<br>
                  &nbsp;3) Frozen food package<br>
                  &nbsp;4) Snack and fried &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;foods package</font></td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">PP</font></b></p>
                    </td>
                    <td width="120">
                        <p align="center"><span style="font-size:10pt;">Inflation(IPP),</span></p>
                        <p align="center"><span style="font-size:10pt;">                  T-die(CPP)<br>
                  ������, ����</span></p>
                    </td>
                    <td width="160"><font size="2">&nbsp;1) Cheap<br>
                  &nbsp;2) Transparency <br>
                  &nbsp;3) Glossy<br>
                  &nbsp;4) Excellent heat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance (120'C)<br>
                  &nbsp;5) Excellent moisture- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;proof<br>
                  &nbsp;6) Excellent chemistry- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance<br>
                  &nbsp;7) Excellent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;processabiity<br>
                  &nbsp;8) Bending resistance</font></td>
                    <td width="160"><font size="2">&nbsp;1) Big molding &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;shrinkage<br>
                  &nbsp;2) Weak acid &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance <br>
                  &nbsp;3) Weak ultraviolet rays<br>
                  &nbsp;4) Big gas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;transmission <br>
                  &nbsp;5) High brittleness &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;temperature</font></td>
                    <td width="160"><font size="2">&nbsp;1) Food package<br>
                  &nbsp;2) Fruit, vegetable and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;meat package <br>
                  &nbsp;3) Shrinkage package <br>
                  &nbsp;4) Complex film</font></td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">PET</font></b></p>
                    </td>
                    <td width="120">
                        <p align="center"><span style="font-size:10pt;">biaxial extrusion</span></p>
                    </td>
                    <td width="160">
<font size="2">&nbsp;1) Excellent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mechanical strength &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(tension, impact) <br>
                  &nbsp;2) Excellent cold and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;heat resistance <br>
                  3) Excellent &nbsp;&nbsp;&nbsp;&nbsp;transparency<br>
                  &nbsp;4) Excellent gloss<br>
                  &nbsp;5) Excellent gas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;transmission &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;isolation <br>
                  &nbsp;6) Oil resistance<br>
                  &nbsp;7) Chemistry- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance <br>
                  &nbsp;8) Good for food &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;hygiene</font></td>
                    <td width="160"><font size="2">&nbsp;1) Difficult to recycle<br>
                  &nbsp;2) Expensive</font></td>
                    <td width="160"><font size="2">&nbsp;1) Package for foods to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;be boiled <br>
                  &nbsp;2) Sterilized package &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;materials(120'C, 30 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;min.)<br>
                  &nbsp;3) Films for various &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;kinds of laminate</font></td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">NYLON</font></b></p>
                    </td>
                    <td width="120">
                        <p align="center"><span style="font-size:10pt;">T-die,</span></p>
                        <p align="center"><span style="font-size:10pt;">biaxial</span></p>
                    </td>
                    <td width="160"><font size="2">&nbsp;1) Excellent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mechanical strength                   &nbsp;2) Excellent abrasion &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance<br>
                  &nbsp;3) Excellent heat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;resistance <br>
                  &nbsp;4) Flexible at room &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;temperature <br>
                  &nbsp;5) Low gas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;transmission<br>
                  &nbsp;6) Excellent printability <br>
                  &nbsp;7) Hygienic food &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;package <br>
                  &nbsp;8) Package for retort</font></td>
                    <td width="160"><font size="2">&nbsp;1) Hygroscopic &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;property <br>
                  &nbsp;2) Discoloration at the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;temperature over &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;60'C <br>
                  &nbsp;3) Weak to inorganic &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;acid</font></td>
                    <td width="160"><font size="2">&nbsp;1) Vacuum package<br>
                  &nbsp;2) Package for inactive &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;gas filling <br>
                  &nbsp;3) Sterilized package &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;materials<br>
                  &nbsp;4) Package for frozen &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;foods(Up to -60'C)</font></td>
                </tr>
                <tr>
                    <td width="80" bgcolor="#0000CC">
                        <p align="center"><b><font size="3" color="white">&nbsp;</font></b></p>
                    </td>
                    <td width="120"><span style="font-size:10pt;">&nbsp;</span></td>
                    <td width="160"><font size="2">&nbsp;</font></td>
                    <td width="160"><font size="2">&nbsp;</font></td>
                    <td width="160"><font size="2">&nbsp;</font></td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="103">
                <tr>
                    <td width="744" colspan="7">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b><a href="http://www.daewon-ind.co.kr/product/e_prd_special.php" target="_self">Bag Product</a></b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b><a href="http://www.daewon-ind.co.kr/product/e_prd_pouch.php" target="_self">Pouch Product</a></b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b><a href="http://www.daewon-ind.co.kr/product/e_prd_roll.php" target="_self">Roll Procuct</a></b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b><a href="http://www.daewon-ind.co.kr/product/e_prd_lldpe.php" target="_self">LLDPE Film</a></b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b><a href="http://www.daewon-ind.co.kr/product/e_prd_special.php" target="_self">Characteristic of Material</a></b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><b>&nbsp;</b></font></p>
                    </td>
                    <td width="103" height="22" valign="middle">
                        <p align="center"><font size="2" color="blue"><a href="#" target="_self"><b>~ T o p&nbsp;~</b></a></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8" colspan="7">
                        <address CLASS=HStyle0><b><span style="font-family:����;"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#412-1, Cheong Cheon-Dong, Bupyeong-Gu, Inchon Korea.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tel : (032) 516-2211&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fax : (032) 516-2246</font></span></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>