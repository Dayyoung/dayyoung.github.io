<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.          </title>
<meta name="generator" content="Namo WebEditor">
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="750" height="178">
                <tr>
                    <td width="744" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/e_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/e_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="214">
                <tr>
                    <td width="744" height="138">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="640" height="202">
                        <param name="movie" value="../swf/e_index.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="640" height="202" src="../swf/e_index.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="636">                        
                        <p><font size="3">Daewon Industry is the leader opening the future of package industry through customer</font></p>
                        <p><font size="3">satisfaction. Since its foundation in 1971, Daewon Industry has pursued customer</font></p>
                        <p><font size="3">satisfaction with high quality and differentiated products.</font></p>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="636">                        
                        <hr>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="156">
                        <p align="center">Automatic Rolls<img src="img/img1.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center">Vacuum Pouches<img src="img/img2.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center">Top &amp; Botton Film<img src="img/img3.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center">Variety of Pouches<img src="img/img4.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="64" align="center">
                <tr>
                    <td width="744" height="6">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8">
                        <address CLASS=HStyle0><b><span style="font-family:����;"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#412-1, Cheong Cheon-Dong, Bupyeong-Gu, Inchon Korea.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tel : (032) 516-2211&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fax : (032) 516-2246</font></span></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>