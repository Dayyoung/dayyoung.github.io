<?php
	include("../inc/common.inc.php");
	include("../inc/db.inc.php");  

	$dbconn = mysql_connect($db_server, $db_user, $db_pass) or die('��񿬰����');
	mysql_select_db($db_name, $dbconn) or die('��� ���� ����');
  
	$qry="select count(*) from tblNews " ;                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$total_rows=mysql_result($rst, 0 ,0);
	$start_rows=ceil($total_rows - 2 );  
	if ($start_rows < 0 ) {
		$start_rows = 0;
	}
	$qry="select *, date_format(reg_date, '%Y.%m.%d') as reg_date  from tblNews LIMIT $start_rows,$total_rows" ;
	                          
	$rst=mysql_query($qry, $dbconn) or die('qry:'.mysql_error());
	$count_row = @mysql_num_rows($rst);
 
	
?>



<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.          </title>
<meta name="generator" content="Namo WebEditor">
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="750" height="178">
                <tr>
                    <td width="744" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/k_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/k_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="214">
                <tr>
                    <td width="744" height="138">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="640" height="202">
                        <param name="movie" value="../swf/k_index.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="640" height="202" src="../swf/k_index.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="1" width="650" align="center">
                <tr>
                    <td width="640">
                        <table border="0" width="610" align="center">
                            <tr>
                                <td width="2">&nbsp;</td>
                                <td width="593">
                                    <table cellpadding="0" cellspacing="0" width="593" height="154" align="center">
                                        <tr>
                                            <td width="593" colspan="2" height="65">
                                                <p align="center"><font size="2">&nbsp;�������ֽ�ȸ��� 1971�� ���� ���� ��ǰ�� �� ����ȭ�� ��ǰ���� </font></p>
                                                <p align="center"><font size="2">���������� ���� &nbsp;�������� �̷��� �������&nbsp;������ ����Դϴ�.</font></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="135" height="71">
                                                <p align="center"><a href="http://www.daewon-ind.co.kr/board/list.php?db=tblNews" target="_self"><img src="img/news_title.gif" width="100" height="70" border="0"></a></p>
                                            </td>
                                            <td width="458" height="71">
                                                <table width="97%" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td rowspan="2" valign="top" width="1">
                                                            <div align="center">
                                                                <p>&nbsp;</p>
                                                            </div>
                                                        </td>
                                                        <td width="473" class="compa" height="35">
                  &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td width="473">
                                                            <table width="309" border="0" cellspacing="0" cellpadding="0" align="center">
                                                                <tr>
                                                                    <td colspan="3" width="309"><img src="img/point_line.gif" width="454" height="1"></td>
                                                                </tr>
                                                                <?
	if($count_row!=0){
		for($i=$count_row-1; $i>=0; $i--){
			mysql_data_seek($rst, $i);
			$row=mysql_fetch_array($rst);
		#while($row = mysql_fetch_array($rst)) {
			echo("                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='img/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td width='325'><a href='../board/read.php?db=tblNews&id=$row[id]' target='_self'>$row[title]</a></td>
                      <td width='100'> 
                        <div align='right'>[ $row[reg_date] ]</div>
                      </td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='img/point_line.gif' width='454' height='1'></td>
                    </tr>
	    	
			");
		
		}	//while�� �ݱ�    
	}	//if�� �ݱ�
	else{
		echo("	
                    <tr> 
                      <td width='25' height='25'> 
                        <div align='right'><img src='img/news_point.gif' width='16' height='19'></div>
                      </td>
                      <td colspan='2' width='325'><div align='center'>�ڷᰡ �����ϴ�.</div></td>
                    </tr>
                    <tr> 
                      <td colspan='3'><img src='img/point_line.gif' width='454' height='1'></td>
                    </tr>

		");
	}        		

?>
                                                                <tr>
                                                                    <td colspan="3" width="309"><img src="img/point_line.gif" width="454" height="1"></td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="593" height="18" colspan="2">
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="1">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="156">
                        <p align="center"><img src="img/img1.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center"><img src="img/img2.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center"><img src="img/img3.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="156">
                        <p align="center"><img src="img/img4.gif" border="0" width="145" height="120"></p>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="74">
                <tr>
                    <td width="744" height="16">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8">
                        <address align="center"><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��õ������ ���� ûõ�� 412-1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tel : (032) 516-2211 &nbsp;&nbsp;&nbsp;&nbsp;Fax : (032) 516-2246</font></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>