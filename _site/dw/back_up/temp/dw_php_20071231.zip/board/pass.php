<html>
<head>
<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ �Խ��� ]          </title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<link rel="stylesheet" href="../style/style_1.css" type="text/css">

</head>

<SCRIPT language=javascript>
<!--
  function sendIt(tf){
    if(!tf.password.value){
	  alert("�н����带 �Է��� �ּ���.");
	  tf.password.focus();
	  return false;
	 }else{
	  return true;
	}
	if(!tf.user_id.value) {
		alert("ID�� �Է��� �ֽʽÿ�.");
		tf.user_id.focus();
		return false;
	} else {
		return true;
	}
  }
--> 
</SCRIPT>



<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="750" height="178">
                <tr>
                    <td width="744" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/k_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/k_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="740">
                        <table width="64%" border="0" cellspacing="0" cellpadding="0" height="368" align="center">
                            <tr>
                                <td width="36" valign="top" height="368"></td>
                                <td height="368" valign="top" width="598">
                                    <? if($db == "tblUrl" || $db == "tblBox" || $db == "tblNews" || $db == "tblPds" ){     	
    	echo("<form name='write' method='post' action='./action_url.php'>");
    } else {
    	echo("<form name='write' method='post' action='./action.php'>");
    }
    ?>
			<input type="hidden" name='act' value='<? echo $act; ?>'>
			<input type='hidden' name='db' value='<? echo $db; ?>'>
			<input type='hidden' name='key' value='<? echo $key; ?>'>
			<input type='hidden' name='value' value='<? echo $value; ?>'>
			<input type='hidden' name='this_page' value='<? echo $this_page; ?>'>
	      	<input type='hidden' name='id' value='<? echo $id; ?>'>
	      	<input type='hidden' name='v_id' value='<? echo $v_id; ?>'>
	      	<input type='hidden' name='r_id' value='<? echo $r_id; ?>'>	    
                                    <table width="561" border="0" cellspacing="0" cellpadding="0" align="center">
                                        <tr>
                                            <td width="561" height="80">
                                                <div align="center">
<img src="images/admin_title.gif" width="544" height="52">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="187" width="561">
                                                <table width="300" border="0" align="center" cellpadding="0" cellspacing="0" height="52">
                                                    
<!--<tr> 
                <td height="30"><div align="right"><strong>I D</strong></div></td>
                <td></td>
                <td><input type="text" name="user_id" style="background-color:#ECECEC; border-style:1; font-size: 11;                     color: #000000; font-family: arial, verdana, geneva, ����" size="15" maxlength="12"></td>
                </tr>-->
                                                    <tr>
                                                        <td width="100" height="3">
                                                            <div align="right">
<img src="images/point.gif" width="80" height="3">
                                                            </div>
                                                        </td>
                                                        <td width="18" height="3"></td>
                                                        <td width="182" height="3"></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td height="27">
                                                            <div align="right"><strong>Pass</strong></div>
                                                        </td>
                                                        <td height="27"></td>
                                                        <td height="27">
                                                            <form name="form1">
<input type="password" name="password" style="background-color:#ECECEC; border-style:1; font-size: 11; color: #000000; font-family: arial, verdana, geneva, ����" size="15" maxlength="12">
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td height="11">
                                                            <div align="right">
<img src="images/point.gif" width="80" height="3">
                                                            </div>
                                                        </td>
                                                        <td height="11"></td>
                                                        <td height="11"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="60" width="561">
                                                <div align="center">
<input type="image" src="images/bu_ok.gif" width="67" height="20" border="0">
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
			
                                    </form>        
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td width="740">
                        <p>&nbsp;</p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="103">
                <tr>
                    <td width="744" colspan="2">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="636" height="22">
                        <p align="center">&nbsp;</p>
                    </td>
                    <td width="103" height="22">
                        <p align="center"><b><a href="#" target="_self"><font size="2" color="blue">~ T o p&nbsp;~</font></a></b></p>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8" colspan="2">
                        <address align="center"><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��õ������ ���� ûõ�� 412-1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tel : (032) 516-2211 &nbsp;&nbsp;&nbsp;&nbsp;Fax : (032) 516-2246</font></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>
