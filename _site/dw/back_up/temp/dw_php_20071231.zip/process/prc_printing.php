<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ �������� ]          </title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->


<!-- ���� : �׻� �����ڸ��� ��ġ�ϴ� �����̵� ���̾�޴�-->
<STYLE>
<!--
A.ssmItems:link	{color:black;text-decoration:none;}
A.ssmItems:hover	{color:black;text-decoration:none;}
A.ssmItems:active	{color:black;text-decoration:none;}
A.ssmItems:visited	{color:black;text-decoration:none;}
//-->
</STYLE>

<SCRIPT language="JavaScript1.2">
NS6 = (document.getElementById&&!document.all)
IE = (document.all)
NS = (navigator.appName=="Netscape" && navigator.appVersion.charAt(0)=="4")

tempBar='';barBuilt=0;ssmItems=new Array();

moving=setTimeout('null',1)
function moveOut() {
if ((NS6||NS)&&parseInt(ssm.left)<0 || IE && ssm.pixelLeft<0) {
clearTimeout(moving);moving = setTimeout('moveOut()', slideSpeed);slideMenu(10)}
else {clearTimeout(moving);moving=setTimeout('null',1)}};
function moveBack() {clearTimeout(moving);moving = setTimeout('moveBack1()', waitTime)}
function moveBack1() {
if ((NS6||NS) && parseInt(ssm.left)>(-menuWidth) || IE && ssm.pixelLeft>(-menuWidth)) {
clearTimeout(moving);moving = setTimeout('moveBack1()', slideSpeed);slideMenu(-10)}
else {clearTimeout(moving);moving=setTimeout('null',1)}}
function slideMenu(num){
if (IE) {ssm.pixelLeft += num;}
if (NS||NS6) {ssm.left = parseInt(ssm.left)+num;}
if (NS) {bssm.clip.right+=num;bssm2.clip.right+=num;}}

function makeStatic() {
if (NS||NS6) {winY = window.pageYOffset;}
if (IE) {winY = document.body.scrollTop;}
if (NS6||IE||NS) {
if (winY!=lastY&&winY>YOffset-staticYOffset) {
smooth = .2 * (winY - lastY - YOffset + staticYOffset);}
else if (YOffset-staticYOffset+lastY>YOffset-staticYOffset) {
smooth = .2 * (winY - lastY - (YOffset-(YOffset-winY)));}
else {smooth=0}
if(smooth > 0) smooth = Math.ceil(smooth);
else smooth = Math.floor(smooth);
if (IE) bssm.pixelTop+=smooth;
if (NS6||NS) bssm.top=parseInt(bssm.top)+smooth
lastY = lastY+smooth;
setTimeout('makeStatic()', 1)}}

function buildBar() {
if(barText.indexOf('<IMG')>-1) {tempBar=barText}
else{for (b=0;b<barText.length;b++) {tempBar+=barText.charAt(b)+"<BR>"}}
document.write('<td align="center" rowspan="100" width="'+barWidth+'" bgcolor="'+barBGColor+'" valign="'+barVAlign+'"><p align="center"><font face="'+barFontFamily+'" Size="'+barFontSize+'" COLOR="'+barFontColor+'"><B>'+tempBar+'</B></font></p></TD>')}

function initSlide() {
if (NS6){ssm=document.getElementById("thessm").style;bssm=document.getElementById("basessm").style;
bssm.clip="rect(0 "+document.getElementById("thessm").offsetWidth+" "+document.getElementById("thessm").offsetHeight+" 0)";ssm.visibility="visible";}
else if (IE) {ssm=document.all("thessm").style;bssm=document.all("basessm").style
bssm.clip="rect(0 "+thessm.offsetWidth+" "+thessm.offsetHeight+" 0)";bssm.visibility = "visible";}
else if (NS) {bssm=document.layers["basessm1"];
bssm2=bssm.document.layers["basessm2"];ssm=bssm2.document.layers["thessm"];
bssm2.clip.left=0;ssm.visibility = "show";}
if (menuIsStatic=="yes") makeStatic();}

function buildMenu() {
if (IE||NS6) {document.write('<DIV ID="basessm" style="visibility:hidden;Position : Absolute ;Left : '+XOffset+' ;Top : '+YOffset+' ;Z-Index : 20;width:'+(menuWidth+barWidth+10)+'"><DIV ID="thessm" style="Position : Absolute ;Left : '+(-menuWidth)+' ;Top : 0 ;Z-Index : 20;" onmouseover="moveOut()" onmouseout="moveBack()">')}
if (NS) {document.write('<LAYER name="basessm1" top="'+YOffset+'" LEFT='+XOffset+' visibility="show"><ILAYER name="basessm2"><LAYER visibility="hide" name="thessm" bgcolor="'+menuBGColor+'" left="'+(-menuWidth)+'" onmouseover="moveOut()" onmouseout="moveBack()">')}
if (NS6){document.write('<table border="0" cellpadding="0" cellspacing="0" width="'+(menuWidth+barWidth+2)+'" bgcolor="'+menuBGColor+'"><TR><TD>')}
document.write('<table border="0" cellpadding="0" cellspacing="1" width="'+(menuWidth+barWidth+2)+'" bgcolor="'+menuBGColor+'">');
for(i=0;i<ssmItems.length;i++) {
if(!ssmItems[i][3]){ssmItems[i][3]=menuCols;ssmItems[i][5]=menuWidth-1}
else if(ssmItems[i][3]!=menuCols)ssmItems[i][5]=Math.round(menuWidth*(ssmItems[i][3]/menuCols)-1);
if(ssmItems[i-1]&&ssmItems[i-1][4]!="no"){document.write('<TR>')}
if(!ssmItems[i][1]){
document.write('<td bgcolor="'+hdrBGColor+'" HEIGHT="'+hdrHeight+'" ALIGN="'+hdrAlign+'" VALIGN="'+hdrVAlign+'" WIDTH="'+ssmItems[i][5]+'" COLSPAN="'+ssmItems[i][3]+'"> <font face="'+hdrFontFamily+'" Size="'+hdrFontSize+'" COLOR="'+hdrFontColor+'"><b>'+ssmItems[i][0]+'</b></font></td>')}
else {if(!ssmItems[i][2])ssmItems[i][2]=linkTarget;
document.write('<TD BGCOLOR="'+linkBGColor+'" onmouseover="bgColor=\''+linkOverBGColor+'\'" onmouseout="bgColor=\''+linkBGColor+'\'" WIDTH="'+ssmItems[i][5]+'" COLSPAN="'+ssmItems[i][3]+'"><ILAYER><LAYER onmouseover="bgColor=\''+linkOverBGColor+'\'" onmouseout="bgColor=\''+linkBGColor+'\'" WIDTH="100%" ALIGN="'+linkAlign+'"><DIV  ALIGN="'+linkAlign+'"><FONT face="'+linkFontFamily+'" Size="'+linkFontSize+'"> <A HREF="'+ssmItems[i][1]+'" target="'+ssmItems[i][2]+'" CLASS="ssmItems">'+ssmItems[i][0]+'</DIV></LAYER></ILAYER></TD>')}
if(ssmItems[i][4]!="no"&&barBuilt==0){buildBar();barBuilt=1}
if(ssmItems[i][4]!="no"){document.write('</TR>')}}
document.write('</table>')
if (NS6){document.write('</TD></TR></TABLE>')}
if (IE||NS6) {document.write('</DIV></DIV>')}
if (NS) {document.write('</LAYER></ILAYER></LAYER>')}
theleft=-menuWidth;lastY=0;setTimeout('initSlide();', 1)}
</SCRIPT>


<SCRIPT language="JavaScript1.2">
<!--
/*
Configure menu styles below
NOTE: To edit the link colors, go to the STYLE tags and edit the ssm2Items colors
*/
YOffset=200; // no quotes!!
XOffset=0;
staticYOffset=30; // no quotes!!
slideSpeed=20 // no quotes!!
waitTime=100; // no quotes!! 
menuBGColor="black";
menuIsStatic="yes"; 
menuWidth=120; // Must be a multiple of 10! no quotes!!
menuCols=2;
hdrFontFamily="verdana";
hdrFontSize="2";
hdrFontColor="#000099";
hdrBGColor="#00CCFF";
hdrAlign="center";
hdrVAlign="center";
hdrHeight="15";
linkFontFamily="Verdana";
linkFontSize="2";
linkBGColor="white";
linkOverBGColor="#CCFFFF";
linkTarget="_top";
linkAlign="center";
barBGColor="#00CCFF";  
barFontFamily="Verdana";
barFontSize="2";
barFontColor="#000099";
barVAlign="center";
barWidth=20; // no quotes!!
barText=" �������� MENU "; 

///////////////////////////

// ssmItems[...]=[name, link, target, colspan, endrow?] 
ssmItems[0]=["�� �� �� ��"] //create header
ssmItems[1]=["�� �� �� ��", "http://www.daewon-ind.co.kr/process/prc_progress.php", "_self"]
ssmItems[2]=["�� �� �� ��", "http://www.daewon-ind.co.kr/process/prc_extrusion.php","_self"]
ssmItems[3]=["�� �� �� ��", "http://www.daewon-ind.co.kr/process/prc_printing.php", "_self"]
ssmItems[4]=["�� �� �� ��", "http://www.daewon-ind.co.kr/process/prc_lamination.php", "_self"]
ssmItems[5]=["����Ÿ ����", "http://www.daewon-ind.co.kr/process/prc_slit.php", "_self"]
ssmItems[6]=["�� �� �� ��", "http://www.daewon-ind.co.kr/process/prc_pouch_bag.php", "_self"]
buildMenu();
//-->
</SCRIPT>
<!-- �� : �׻� �����ڸ��� ��ġ�ϴ� �����̵� ���̾�޴�-->

</head>



<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="754" height="178">
                <tr>
                    <td width="748" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/k_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/k_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="50">
                        <p align="center"><img src="../images/Title_Point.GIF" width="28" height="27" border="0"></p>
                    </td>
                    <td width="582"><b><font size="4">�� �� �� ��&nbsp;:&nbsp;�� �� �� ��</font></b></td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="636" colspan="2">
                        <hr>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <table border="0" width="750">
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="230">&nbsp;</td>
                    <td width="404">&nbsp;</td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="230">
                        <p align="center"><img src="img/printing_1.jpg" width="200" height="148" border="0"></p>
                    </td>
                    <td width="404">
                        <p><b><font size="3">1. �������۰���.</font></b></p>
                        <p><font size="2">&nbsp;������ ö �Ǹ��� ���� ����(��)������ �� �� ������ �䱸�� ������</font></p>
                        <p><font size="2"> ���·� �ν��� �ְų� �츮�� ������ �� ���� ũ�ҵ����� �Ͽ� ����</font></p>
                        <p><font size="2">&nbsp;���� ������Ű�� ����</font></p>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="638" colspan="2">
                        <hr>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="230">
                        <p align="center"><img src="img/printing_2.jpg" width="200" height="143" border="0"></p>
                    </td>
                    <td width="404">
                        <p><b><font size="3">2. �μ� �����۾�.</font></b></p>
                        <p><font size="2">&nbsp;���������� �Ϸ�Ǹ� ���μ⿡ ������ �����⿡�� ���� �μ�</font></p>
                        <p><font size="2">&nbsp;�Ͽ� ����, Ż��, ���� �� ������ �䱸���׿� ���������� Ȯ���ϰ�</font></p>
                        <p><font size="2"> �������� ���ιޱ� ���� �����μ⸦ ����.</font></p>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="638" colspan="2">
                        <hr>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="230">
                        <p align="center"><img src="img/printing_3.jpg" width="200" height="143" border="0"></p>
                    </td>
                    <td width="404">
                        <p><b><font size="3">3. Gravure �μ����.</font></b></p>
                        <p><font size="2">&nbsp;������ �μ��� ������ �׶���(Gravure) �μ����� ���ϴ� ����</font></p>
                        <p><font size="2">&nbsp;�ν�, ���� ���·� ����(�ν�)��Ų �μ�� ���ǿ� ��ũ�� ������, </font></p>
                        <p><font size="2">&nbsp;����ǥ���� ��ũ�� �����ϸ� �νĵ� �κп� ���ԵǴ� ��ũ�� �з���</font></p>
                        <p><font size="2">&nbsp;���Ͽ� ����(�ʸ�, ���� ��)�� ���� �ǵ����Ͽ� �μ��ϴ� ����</font></p>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="638" colspan="2">
                        <hr>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="638" colspan="2">&nbsp;</td>
                    <td width="49">&nbsp;</td>
                </tr>
                <tr>
                    <td width="49">&nbsp;</td>
                    <td width="638" colspan="2">
                        <p align="center"><img src="img/mak2_printcap.gif" border="0"></p>
                        <p align="center">&nbsp;</p>
                        <p align="center"><img src="img/mak2_eq.gif" border="0"></p>
                    </td>
                    <td width="49">&nbsp;</td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="103" align="center">
                <tr>
                    <td width="744" colspan="8">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_progress.php" target="_self">����������</a></font></b></p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_extrusion.php" target="_self">�������</a></font></b><font size="2"></font></p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_printing.php" target="_self">�μ����</a></font></b><font size="2"></font></p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_lamination.php" target="_self">��������</a></font></b><font size="2"></font></p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_slit.php" target="_self">����Ÿ����</a></font></b><font size="2"></font></p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/prc_pouch_bag.php" target="_parent">��������</a></font></b><font size="2"></font></p>
                    </td>
                    <td width="58" height="22" valign="middle">
                        <p align="center">&nbsp;</p>
                    </td>
                    <td width="94" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="#" target="_self">~ T o &nbsp;p ~</a></font></b><font size="2"></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8" colspan="8">
                        <address align="center"><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��õ������ ���� ûõ�� 412-1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tel : (032) 516-2211 &nbsp;&nbsp;&nbsp;&nbsp;Fax : (032) 516-2246</font></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>