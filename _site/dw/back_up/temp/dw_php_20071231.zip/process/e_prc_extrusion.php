<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title> ������(��)�� ���Ű� ȯ���մϴ�.     [ �������� ]          </title>
<meta name="generator" content="Namo WebEditor">


<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� ���� -->
<style type="text/css">
p,br,body,td,select,input,form,textarea,option { font-size:8pt;font-family:verdana ; }
A:link    {color:#5A5B74; text-decoration:none}
A:visited {color:#5A5B74; text-decoration:none}
A:active  {color:#5A5B74; text-decoration:none}
A:hover   {color:#A5A6C1; background-image: url(http://www.daewon-ind.co.kr/images/Link_Bar.GIF); background-position:bottom; background-repeat:repeat-x; text-decoration:none}
    body {
        scrollbar-face-color:#ffffff;
        scrollbar-shadow-color:#8788A9;
        scrollbar-highlight-color:#f3f3f3;
        scrollbar-3dlight-color:#ffffff;
        scrollbar-darkshadow-color:#ffffff;
        scrollbar-track-color:#ffffff;
        scrollbar-arrow-color:#8788A9
}
</style>
<!-- ��Ÿ�Ͻ�Ʈ�� �̿��� ��ũ�� �������ε� ���λ���� �ҽ� �� -->

</head>




<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" background="../images/Bg_Pint.GIF" bgproperties="fixed">
<table border="0" width="756" align="center" bgcolor="white">
    <tr>
        <td width="750">
            <table border="0" width="754" height="178">
                <tr>
                    <td width="748" height="174">
                        <p align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" namo_flashbutton width="740" height="172">
                        <param name="movie" value="../swf/e_menu.swf">
                        <param name="play" value="true">
                        <param name="loop" value="true">
                        <param name="quality" value="high">
                        <param name="WMode" value="Window">
<embed width="740" height="172" src="../swf/e_menu.swf" play="true" loop="true" quality="high" WMode="Window" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></object></p>
                    </td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="50">
                        <p align="center"><img src="../images/Title_Point.GIF" width="28" height="27" border="0"></p>
                    </td>
                    <td width="582">
                        <p><font size="4"><b>Manufacturing Process</b></font><b><font size="4"> : Extrusion Film</font></b></p>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="636" colspan="2">
                        <hr>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <table border="0" width="750">
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="230">&nbsp;</td>
                    <td width="402">&nbsp;</td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="230">
                        <p align="center"><img src="img/extrusion_1.jpg" width="200" height="219" border="0"></p>
                    </td>
                    <td width="402">
                        <p><font size="2">&nbsp;When putting the resin to the hopper, it moves&nbsp;forwardby the</font></p>
                        <p><font size="2"> screw and is heated and melted. When&nbsp;the air isblown to the</font></p>
                        <p><font size="2">&nbsp;resin that is melted and &nbsp;pushed, the film oftube type is</font></p>
                        <p><font size="2">&nbsp;produced. This&nbsp;process cuts the bothsides of the film of tube</font></p>
                        <p><font size="2"> type&nbsp;to make it flat, winds it inthe roll type and produces&nbsp;the</font></p>
                        <p><font size="2">
&nbsp;biaxial orientation film. </font></p>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="636" colspan="2">
                        <hr>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <table border="0" width="750" height="103" align="center">
                <tr>
                    <td width="744" colspan="7">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_extrusion.php" target="_self">Extrusion Film</a></font></b></p>
                    </td>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_printing.php" target="_self">Printing</a></font></b></p>
                    </td>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_lamination.php" target="_self">T-Die &amp; Dry Lamination</a></font></b></p>
                    </td>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_slit.php" target="_self">Slitter</a></font></b></p>
                    </td>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_pouch_bag.php" target="_parent">Automatic Bag</a></font></b></p>
                    </td>
                    <td width="102" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="http://www.daewon-ind.co.kr/process/e_prc_equipment.php" target="_self">Equipment</a></font></b></p>
                    </td>
                    <td width="108" height="22" valign="middle">
                        <p align="center"><b><font size="2" color="blue"><a href="#" target="_self">~ T o &nbsp;p ~</a></font></b><font size="2"></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="744" height="52" bgcolor="#F0F1F8" colspan="7">
                        <address CLASS=HStyle0><b><span style="font-family:����;"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#412-1, Cheong Cheon-Dong, Bupyeong-Gu, Inchon Korea.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tel : (032) 516-2211&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fax : (032) 516-2246</font></span></b></address>
                        <address><b><font size="2" face="����">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright(c) &nbsp;&nbsp;&nbsp;&nbsp;2002 ~ 2006 &nbsp;&nbsp;DAEWON INDUSTRIAL CO., LTD. &nbsp;&nbsp;&nbsp;&nbsp;All rights Reserved.</font></b></address>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>